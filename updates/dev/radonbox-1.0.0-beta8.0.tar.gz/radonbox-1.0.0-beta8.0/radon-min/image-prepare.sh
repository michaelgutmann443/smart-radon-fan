#!/bin/bash
set -e

echo "[image-prepare] Starting golden image prep..."

echo "[image-prepare] Running radon-reset.sh..."
sudo /opt/radonbox/current/radon-min/radon-reset.sh

echo "[image-prepare] Removing device identity..."
sudo rm -f /etc/radonbox/device-identity.json

echo "[image-prepare] Removing install-date.txt..."
sudo rm -f /etc/radonbox/install-date.txt

echo "[image-prepare] Cleaning logs..."
sudo rm -rf /var/log/radonbox/*
sudo rm -rf /var/log/srf-site-report/*

echo "[image-prepare] Clearing temp/state files..."
sudo rm -f /var/lock/run-radon.lock
sudo rm -f /tmp/*radon*

echo "[image-prepare] Done. Powering down..."
sudo shutdown -h now