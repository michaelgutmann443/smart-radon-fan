#!/usr/bin/env python3
"""
radon-automation.py

Reads Airthings radon via BLE (Bleak), controls a Shelly switch via HTTP RPC,
logs human-readable lines + a single structured CSV line per run.

Key design rule:
- Do NOT write directly to radon-log.txt from inside this script.
  run-radon.sh captu
# Best-effort battery life (OK/LOW). Not required for operation.
b_pct = await try_read_battery_percent(client)
batt_obj = battery_life_obj(b_pct)
                    status_patch({
                        "airthings": {
                                    "battery": batt_obj,
                            "battery": batt_obj
                        }
                    })
res STDOUT/STDERR via tee into radon-log.txt.
"""

import os
import sys
import time
import json
import socket
import traceback
import subprocess
import asyncio
from dataclasses import dataclass
from datetime import datetime, date, timedelta
from typing import Optional
import shutil
import ipaddress
import requests
from bleak import BleakClient, BleakScanner


# ---------------------------
# Status (Beta3)
# ---------------------------

STATUS_UPDATER = "/usr/local/bin/radon-status-update.py"

def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")



def _bytes_to_hex(b):
    try:
        if b is None:
            return None
        if isinstance(b, (bytes, bytearray)):
            return b.hex()
        if isinstance(b, list):
            return bytes(b).hex()
        return str(b)
    except Exception:
        return None

def status_patch(patch: dict) -> None:
    try:
        if os.path.exists(STATUS_UPDATER):
            subprocess.run([STATUS_UPDATER, json.dumps(patch)], timeout=5)
    except Exception:
        pass


# ---------------------------
# Paths / config
# ---------------------------

INSTALL_DATE_PATH = "/etc/radonbox/install-date.txt"
RADON_CONFIG_PATH = "/etc/radonbox/radon-config.conf"

# These are expected to be exported by run-radon.sh after sourcing /etc/radonbox/radon-config.conf
SHELLY_HOST = os.getenv("SHELLY_HOST", "").strip().rstrip("/")
SHELLY_SWITCH_ID = os.getenv("SHELLY_SWITCH_ID", "").strip()
SHELLY_MAC = os.getenv("SHELLY_MAC", "").strip()
AIR_MAC = os.getenv("AIR_MAC", "").strip()
AIR_MFG_ID_RAW = os.getenv("AIR_MFG_ID", "0x0334").strip()
INSTALL_TS_RAW = os.getenv("INSTALL_TS", "").strip()
RADON_SETTLE_SECONDS_RAW = os.getenv("RADON_SETTLE_SECONDS", "86400").strip()
RADON_VALID_AFTER_TS_RAW = os.getenv("RADON_VALID_AFTER_TS", "").strip()

# Fail fast if we don't have required cached config
# If AIR_MAC is empty, we will discover the current BLE address at runtime.
# BLE privacy addressing can rotate the device address, so treating it as a stable identity is brittle.
def _parse_mfg_id(s: str) -> Optional[int]:
    try:
        s = (s or "").strip().lower()
        if not s:
            return None
        return int(s, 16) if s.startswith("0x") else int(s)
    except Exception:
        return None


def _parse_int(s: str) -> Optional[int]:
    try:
        s = (s or "").strip()
        if not s:
            return None
        return int(s)
    except Exception:
        return None

AIR_MFG_ID = _parse_mfg_id(AIR_MFG_ID_RAW)

async def resolve_airthings_addr_by_mfg_id(mfg_id: int) -> Optional[str]:
    """Resolve the current Airthings BLE address by scanning for manufacturer_data[mfg_id]."""
    best_addr = None
    best_rssi = -9999

    try:
        found_map = await BleakScanner.discover(timeout=SCAN_SECONDS, return_adv=True)
        for addr, (dev, adv) in found_map.items():
            md = getattr(adv, "manufacturer_data", None) or {}
            if mfg_id in md:
                rssi = getattr(adv, "rssi", None)
                if rssi is None:
                    rssi = getattr(dev, "rssi", None)
                if rssi is None:
                    rssi = -9999
                if rssi > best_rssi:
                    best_rssi = rssi
                    best_addr = addr
    except TypeError:
        # Older Bleak: collect adv via callback
        def _cb(dev, adv):
            nonlocal best_addr, best_rssi
            md = getattr(adv, "manufacturer_data", None) or {}
            if mfg_id in md:
                rssi = getattr(adv, "rssi", None)
                if rssi is None:
                    rssi = getattr(dev, "rssi", None)
                if rssi is None:
                    rssi = -9999
                if rssi > best_rssi:
                    best_rssi = rssi
                    best_addr = dev.address
        async with BleakScanner(detection_callback=_cb):
            await asyncio.sleep(SCAN_SECONDS)

    return best_addr

if not SHELLY_HOST or not SHELLY_SWITCH_ID:
    status_patch({
        "shelly": {"state": "ERROR", "level": "error", "host": SHELLY_HOST or None},
        "summary": {"state": "ERROR", "level": "error", "text": "Missing Shelly config in radon-config.conf"}
    })
    raise RuntimeError(
        "Missing SHELLY_HOST or SHELLY_SWITCH_ID. Expected /etc/radonbox/radon-config.conf "
        "to be populated and exported by run-radon.sh (or run radon-devices-init.sh on install)."
    )

# If SHELLY_HOST doesn't start with scheme, assume http
if not (SHELLY_HOST.startswith("http://") or SHELLY_HOST.startswith("https://")):
    SHELLY_HOST = "http://" + SHELLY_HOST

# Thresholds
ON_THRESHOLD = float(os.getenv("RADON_ON_THRESHOLD", "4.0"))
OFF_THRESHOLD = float(os.getenv("RADON_OFF_THRESHOLD", "2.0"))
IT_WINDOW_DAYS = int(os.getenv("IT_WINDOW_DAYS", "7"))

# IT is informational only and is not displayed until a full window of data exists.

# Clamp obviously-bogus radon readings (keeps charts/logs sane)
RADON_CLAMP_MAX = float(os.getenv("RADON_CLAMP_MAX", "50.0"))

# BLE behavior
SCAN_SECONDS = float(os.getenv("AIR_SCAN_SECONDS", "20"))
CONNECT_TIMEOUT = float(os.getenv("AIR_CONNECT_TIMEOUT", "25"))
CYCLES = int(os.getenv("AIR_CYCLES", "3"))
ATTEMPTS_PER_CYCLE = int(os.getenv("AIR_ATTEMPTS_PER_CYCLE", "2"))

# Retry cadence (status page)
RETRY_SECONDS = int(os.getenv("AIR_RETRY_SECONDS", "30"))

DBG_TO_STDOUT = os.getenv("DBG_TO_STDOUT", "1").strip() not in ("0", "false", "False", "no", "NO")

# Shelly RPC robustness (Wi‑Fi jitter can cause occasional connect delays).
# Use separate connect/read timeouts and a small retry loop to avoid false ERROR states.
SHELLY_CONNECT_TIMEOUT = float(os.getenv("SHELLY_CONNECT_TIMEOUT", "3.0"))
SHELLY_READ_TIMEOUT = float(os.getenv("SHELLY_READ_TIMEOUT", "5.0"))
# Number of retries AFTER the first attempt (so 1 means up to 2 total tries).
SHELLY_RPC_RETRIES = int(os.getenv("SHELLY_RPC_RETRIES", "1"))
# Base sleep seconds between retries (will backoff linearly: base*(attempt_index+1)).
SHELLY_RPC_RETRY_SLEEP_BASE = float(os.getenv("SHELLY_RPC_RETRY_SLEEP_BASE", "0.3"))


# Airthings Wave radon characteristic UUID used by your current system
CHAR_UUID = "b42e4dcc-ade7-11e4-89d3-123b93f75cba"
# Standard BLE Battery Level characteristic (0–100). Not all Airthings models expose this;
# we treat it as best-effort and map it to Battery Life OK/LOW.
BATTERY_CHAR_UUID = "00002a19-0000-1000-8000-00805f9b34fb"


# ---------------------------
# Logging helpers
# ---------------------------

def dbg_write(msg: str) -> None:
    """One place to write human-readable log lines."""
    if not DBG_TO_STDOUT:
        return
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
    sys.stdout.write(f"{ts}: {msg}\n")
    sys.stdout.flush()


def log_exception(prefix: str, e: Exception) -> None:
    dbg_write(f"{prefix}: [{type(e).__name__}] {e}")
    tb = traceback.format_exc().strip()
    if tb:
        dbg_write(f"Trace: {tb.splitlines()[-1]}")


# ---------------------------
# Utilities
# ---------------------------

def normalize_mac(mac: str) -> str:
    return (mac or "").strip().lower().replace("-", ":")


def _strip_host_scheme(host: str) -> str:
    s = (host or "").strip()
    if s.startswith("http://"):
        s = s[len("http://"):]
    elif s.startswith("https://"):
        s = s[len("https://"):]
    return s.rstrip("/")


def _is_shelly_network_error(e: Exception) -> bool:
    if isinstance(e, requests.exceptions.RequestException):
        return True
    if isinstance(e, socket.error):
        return True
    return False


def _get_managed_ipv4_and_prefix() -> tuple[Optional[str], Optional[int]]:
    """
    Return the IPv4/prefix for the interface used by the default route.
    On SRF dual-radio systems, this selects the Managed/home-LAN interface
    (for example wlan1), not the AP-side interface (for example wlan0).
    """
    try:
        out = subprocess.check_output(["ip", "route", "show", "default"], text=True)
        for line in out.splitlines():
            parts = line.split()
            if "dev" not in parts:
                continue
            dev = parts[parts.index("dev") + 1]

            addr_out = subprocess.check_output(
                ["ip", "-4", "-o", "addr", "show", "dev", dev, "scope", "global"],
                text=True
            )
            for addr_line in addr_out.splitlines():
                addr_parts = addr_line.split()
                if "inet" not in addr_parts:
                    continue
                addr = addr_parts[addr_parts.index("inet") + 1]
                ip_s, prefix_s = addr.split("/", 1)
                dbg_write(f"[shelly] Using managed interface {dev} with source IP {ip_s}/{prefix_s}")
                return ip_s, int(prefix_s)
    except Exception as e:
        dbg_write(f"[shelly] Could not determine managed IPv4 from default route: {e}")
    return None, None


def _warm_arp_for_host(host: str) -> None:
    try:
        subprocess.run(["ping", "-c", "1", "-W", "1", host], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2)
    except Exception:
        pass


def get_mac_for_ip(ip: str) -> Optional[str]:
    try:
        out = subprocess.check_output(["ip", "neigh", "show", ip], text=True)
        for line in out.splitlines():
            parts = line.split()
            if "lladdr" in parts:
                idx = parts.index("lladdr")
                if idx + 1 < len(parts):
                    return normalize_mac(parts[idx + 1])
    except Exception:
        pass
    return None


def update_config_key(path: str, key: str, value: str):
    try:
        lines = []
        found = False
        inserted = False

        with open(path, "r") as f:
            for line in f:
                stripped = line.strip()

                # Replace existing key
                if stripped.startswith(f"{key}="):
                    lines.append(f"{key}={value}\n")
                    found = True
                    continue

                lines.append(line)

                # Insert SHELLY_MAC after SHELLY_SWITCH_ID if not already present
                if (
                    not found
                    and not inserted
                    and key == "SHELLY_MAC"
                    and stripped.startswith("SHELLY_SWITCH_ID=")
                ):
                    lines.append(f"{key}={value}\n")
                    inserted = True

        # If key never found and not inserted, append at end
        if not found and not inserted:
            lines.append(f"{key}={value}\n")

        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            f.writelines(lines)

        os.replace(tmp, path)

    except Exception as e:
        dbg_write(f"[config] Failed to update {key}: {e}")


def learn_shelly_mac_from_current_host() -> Optional[str]:
    global SHELLY_MAC

    if normalize_mac(SHELLY_MAC):
        return normalize_mac(SHELLY_MAC)

    host_only = _strip_host_scheme(SHELLY_HOST)
    if not host_only:
        return None

    _warm_arp_for_host(host_only)
    mac = get_mac_for_ip(host_only)
    if mac:
        SHELLY_MAC = normalize_mac(mac)
        dbg_write(f"[shelly] Learned bound MAC {SHELLY_MAC} from current host {host_only}")
        update_config_key(RADON_CONFIG_PATH, "SHELLY_MAC", SHELLY_MAC)
        return SHELLY_MAC

    dbg_write(f"[shelly] Could not learn MAC from current host {host_only}")
    return None


def scan_lan_for_shelly(target_mac: str) -> Optional[str]:
    target_mac = normalize_mac(target_mac)
    if not target_mac:
        return None

    local_ip, prefix = _get_managed_ipv4_and_prefix()
    if not local_ip or prefix is None:
        dbg_write("[shelly] Could not determine local IPv4 subnet for rediscovery")
        return None

    try:
        network = ipaddress.ip_network(f"{local_ip}/{prefix}", strict=False)
    except Exception as e:
        dbg_write(f"[shelly] Failed to derive subnet from {local_ip}/{prefix}: {e}")
        return None

    dbg_write(f"[shelly] Starting LAN scan on {network} for MAC {target_mac}")

    for host_ip in network.hosts():
        host = str(host_ip)
        if host == local_ip:
            continue

        _warm_arp_for_host(host)
        mac = get_mac_for_ip(host)
        if not mac:
            continue

        if normalize_mac(mac) == target_mac:
            dbg_write(f"[shelly] Rediscovered bound Shelly MAC {target_mac} at {host}")
            return host

    dbg_write(f"[shelly] No host with MAC {target_mac} found on {network}")
    return None


def is_installation_day() -> bool:
    """True if INSTALL_DATE_PATH exists and matches today's date."""
    try:
        with open(INSTALL_DATE_PATH, "r", encoding="utf-8") as f:
            s = f.read().strip()
        if not s:
            return False
        return s == date.today().isoformat()
    except Exception:
        return False


def shelly_rpc(path: str, payload: Optional[dict] = None, timeout: Optional[float] = None) -> dict:
    """
    Call Shelly RPC endpoint with robust timeouts + retries.

    Beta 8.0 addition:
    - If the cached Shelly host fails with a network/reachability error and SHELLY_MAC is
      known, attempt Managed-mode LAN rediscovery by MAC, update SHELLY_HOST in config,
      and retry the RPC once against the rediscovered host.
    """
    global SHELLY_HOST, SHELLY_MAC

    # Allow a single float override for both connect+read (backwards compatible).
    if timeout is None:
        timeout_obj = (SHELLY_CONNECT_TIMEOUT, SHELLY_READ_TIMEOUT)
    else:
        timeout_obj = (float(timeout), float(timeout))

    total_attempts = max(1, 1 + int(SHELLY_RPC_RETRIES))

    def _do_request() -> dict:
        url = f"{SHELLY_HOST}{path}"
        if payload is None:
            r = requests.get(url, timeout=timeout_obj)
        else:
            r = requests.post(url, json=payload, timeout=timeout_obj)
        r.raise_for_status()
        return r.json()

    last_exc: Exception | None = None

    for attempt_idx in range(total_attempts):
        try:
            j = _do_request()
            if not normalize_mac(SHELLY_MAC):
                learn_shelly_mac_from_current_host()
            return j
        except Exception as e:
            last_exc = e
            if attempt_idx < total_attempts - 1:
                time.sleep(SHELLY_RPC_RETRY_SLEEP_BASE * (attempt_idx + 1))
                continue

    if last_exc is not None and _is_shelly_network_error(last_exc):
        dbg_write(f"[shelly] RPC failed at cached host {SHELLY_HOST}: {type(last_exc).__name__}: {last_exc}")

        if not normalize_mac(SHELLY_MAC):
            dbg_write("[shelly] SHELLY_MAC not configured; automatic rediscovery unavailable")
            raise last_exc

        dbg_write(f"[shelly] Attempting rediscovery for bound MAC {normalize_mac(SHELLY_MAC)}")
        new_ip = scan_lan_for_shelly(SHELLY_MAC)
        if new_ip:
            SHELLY_HOST = "http://" + new_ip
            update_config_key(RADON_CONFIG_PATH, "SHELLY_HOST", new_ip)
            dbg_write(f"[shelly] Updated cached SHELLY_HOST to {new_ip}; retrying RPC once")
            try:
                j = _do_request()
                return j
            except Exception as e2:
                dbg_write(f"[shelly] Retry after rediscovery failed: {type(e2).__name__}: {e2}")
                raise e2

        dbg_write(f"[shelly] Rediscovery failed: no matching host found for MAC {normalize_mac(SHELLY_MAC)}")

    if last_exc is not None:
        raise last_exc
    raise RuntimeError("Shelly RPC failed without a captured exception")


def shelly_get_state() -> bool:
    try:
        j = shelly_rpc(f"/rpc/Switch.GetStatus?id={SHELLY_SWITCH_ID}")
        status_patch({
            "shelly": {
                "state": "VALIDATED", "level": "ok",
                "host": SHELLY_HOST, "switch_id": int(SHELLY_SWITCH_ID),
                "last_ok_local": _now_iso(), "last_error": None
            }
        })
        return bool(j.get("output", False))
    except Exception as e:
        log_exception("Shelly.GetStatus failed", e)
        status_patch({
            "shelly": {
                "state": "ERROR", "level": "warn",
                "host": SHELLY_HOST, "switch_id": int(SHELLY_SWITCH_ID or 0),
                "last_error": f"{type(e).__name__}: {e}"
            }
        })
        # Conservative fallback: treat as OFF
        return False


def shelly_set_state(on: bool) -> None:
    try:
        _ = shelly_rpc("/rpc/Switch.Set", {"id": int(SHELLY_SWITCH_ID), "on": bool(on)})
        dbg_write(f"Shelly set -> {'ON' if on else 'OFF'} @ {SHELLY_HOST}")
        status_patch({
            "shelly": {
                "state": "VALIDATED", "level": "ok",
                "host": SHELLY_HOST, "switch_id": int(SHELLY_SWITCH_ID),
                "last_ok_local": _now_iso(), "last_error": None
            }
        })
    except Exception as e:
        log_exception("Shelly.Set failed", e)
        status_patch({
            "shelly": {
                "state": "ERROR", "level": "warn",
                "host": SHELLY_HOST, "switch_id": int(SHELLY_SWITCH_ID or 0),
                "last_error": f"{type(e).__name__}: {e}"
            }
        })


@dataclass
class RadonReading:
    short_pci: float
    long_pci: float


def parse_wave_payload(data: bytes) -> Optional[RadonReading]:
    """
    Current SRF interpretation of the Airthings BLE payload:

    - ST is read from bytes [4:6] as little-endian unsigned Bq/m^3
      and converted to pCi/L using / 37.0
    - Airthings LT is currently disabled in SRF and set to 0.0 until
      we have definitive vendor documentation.
    """
    try:
        if not data or len(data) < 6:
            return None

        st_bq = int.from_bytes(data[4:6], byteorder="little", signed=False)
        short_pci = round(st_bq / 37.0, 2)
        long_pci = 0.0

        return RadonReading(short_pci=short_pci, long_pci=long_pci)
    except Exception:
        return None



async def try_read_battery_percent(client):
    """Best-effort read of standard BLE battery level (0..100). Returns int or None."""
    try:
        raw = await client.read_gatt_char(BATTERY_CHAR_UUID)
        if not raw:
            return None
        pct = int(raw[0])
        if 0 <= pct <= 100:
            return pct
        return None
    except Exception:
        return None

def battery_life_obj(pct):
    """Map pct to a simple OK/LOW/UNKNOWN object for the portal."""
    if pct is None:
        return {"state": "UNKNOWN", "level": "info", "text": "Battery Life UNKNOWN"}
    if pct <= 15:
        return {"state": "LOW", "level": "warn", "text": "Battery Life LOW", "percent": pct}
    return {"state": "OK", "level": "ok", "text": "Battery Life OK", "percent": pct}


def vendor_battery_obj_from_payload(raw: Optional[bytes]) -> dict:
    """
    Airthings Wave-series devices often do NOT expose the standard BLE Battery Level (0x2A19).
    We do not yet have a validated mapping from the vendor payload bits to battery state
    (fresh batteries still reported "LOW" under the prior heuristic).

    To avoid false warnings, report UNKNOWN until a reliable mapping is proven.
    """
    return {"state": "UNKNOWN", "level": "info", "text": "Battery Life UNKNOWN"}

async def read_radon_gatt(mac: str) -> RadonReading:
    """
    Connect to the Airthings MAC and read radon values, with retries.
    Writes status updates for installer status page.

    Current policy:
    - Use only Airthings ST (24h average) from the BLE payload.
    - Preserve payload hex logging for diagnosis/reverse-engineering.
    - Do not use Airthings LT for SRF at this time; LT is set to 0.0.
    """
    last_good: Optional[RadonReading] = None

    attempt_counter = 0
    attempt_max = CYCLES * ATTEMPTS_PER_CYCLE

    batt_obj = {"state": "UNKNOWN", "level": "info", "text": "Battery Life UNKNOWN"}
    status_patch({
        "airthings": {
            "state": "WAITING_FOR_READ",
            "level": "warn",
            "mac": mac,
            "battery": batt_obj,
            "read": {
                "attempt": 0,
                "attempt_max": attempt_max,
                "retry_seconds": RETRY_SECONDS,
                "last_attempt_local": None,
                "next_retry_local": None,
                "last_ok_local": None,
                "last_error": None
            },
            "tip": "Battery radon sensors often sleep. Pick up the meter or wave your hand near it to wake it. RadonBox will keep retrying automatically."
        },
        "summary": {
            "state": "READY_WAITING_FOR_FIRST_READ",
            "level": "warn",
            "text": "Installation complete — waiting for first radon reading"
        }
    })

    for cycle in range(1, CYCLES + 1):
        dbg_write(f"[cycle {cycle}/{CYCLES}] Scanning up to {SCAN_SECONDS:.0f}s for Airthings device {mac}...")
        try:
            found = False
            adv_by_addr = {}
            devices = []
            try:
                found_map = await BleakScanner.discover(timeout=SCAN_SECONDS, return_adv=True)
                for addr, (dev, adv) in found_map.items():
                    devices.append(dev)
                    adv_by_addr[addr] = adv
            except TypeError:
                devices_map = {}
                def _cb(dev, adv):
                    devices_map[dev.address] = dev
                    adv_by_addr[dev.address] = adv
                async with BleakScanner(detection_callback=_cb):
                    await asyncio.sleep(SCAN_SECONDS)
                devices = list(devices_map.values())

            dbg_write(f"[cycle {cycle}] Scan complete: saw {len(devices)} devices.")
            for d in devices:
                if (d.address or "").lower() == mac.lower():
                    found = True
                    rssi = getattr(adv_by_addr.get(d.address), "rssi", None)
                    name = getattr(d, "name", None)
                    dbg_write(f"[cycle {cycle}] Target device seen: {d.address} RSSI={rssi} Name={name}")
                    status_patch({
                        "airthings": {
                            "state": "FOUND",
                            "level": "ok",
                            "mac": mac,
                            "battery": batt_obj,
                            "name": name,
                            "rssi": rssi,
                            "adv": {
                                "manufacturer_data": {k: _bytes_to_hex(v) for k, v in (getattr(adv_by_addr.get(d.address), "manufacturer_data", {}) or {}).items()},
                                "service_data": {k: _bytes_to_hex(v) for k, v in (getattr(adv_by_addr.get(d.address), "service_data", {}) or {}).items()}
                            }
                        }
                    })
                    break

            if not found:
                dbg_write(f"[cycle {cycle}] Target device not seen in scan; retrying next cycle.")
                status_patch({
                    "airthings": {
                        "state": "WAITING_FOR_READ",
                        "level": "warn",
                        "mac": mac,
                        "read": {"last_error": "Device not seen in BLE scan"}
                    }
                })
                continue
        except Exception as e:
            log_exception(f"[cycle {cycle}] Scan error", e)
            status_patch({
                "airthings": {
                    "state": "WAITING_FOR_READ",
                    "level": "warn",
                    "mac": mac,
                    "battery": batt_obj,
                    "read": {"last_error": f"Scan error: {type(e).__name__}: {e}"}
                }
            })
            continue

        for attempt in range(1, ATTEMPTS_PER_CYCLE + 1):
            attempt_counter += 1
            last_attempt = _now_iso()
            next_retry = (datetime.now().astimezone() + __import__("datetime").timedelta(seconds=RETRY_SECONDS)).isoformat(timespec="seconds")

            status_patch({
                "airthings": {
                    "state": "WAITING_FOR_READ",
                    "level": "warn",
                    "mac": mac,
                    "battery": batt_obj,
                    "read": {
                        "attempt": attempt_counter,
                        "attempt_max": attempt_max,
                        "last_attempt_local": last_attempt,
                        "next_retry_local": next_retry,
                        "retry_seconds": RETRY_SECONDS
                    }
                }
            })

            try:
                wait_s = 4.0 + (cycle * 0.4) + (attempt * 0.4)
                dbg_write(f"[cycle {cycle}] Attempt {attempt}/{ATTEMPTS_PER_CYCLE}: wait {wait_s:.1f}s before connect...")
                time.sleep(wait_s)
                dbg_write(f"[cycle {cycle}] Connecting with timeout={CONNECT_TIMEOUT:.1f}s ...")
                client = BleakClient(mac, timeout=CONNECT_TIMEOUT)
                try:
                    await client.connect()
                    dbg_write("[connect] Connected. Reading radon GATT...")

                    try:
                        await client.get_services()
                    except Exception:
                        pass

                    for vtry in range(1, 4):
                        raw = await client.read_gatt_char(CHAR_UUID)
                        batt_obj = vendor_battery_obj_from_payload(raw)

                        try:
                            status_patch({
                                "airthings": {
                                    "vendor_payload_len": len(raw) if raw is not None else None,
                                    "vendor_payload_hex": raw.hex() if isinstance(raw, (bytes, bytearray)) else None
                                }
                            })
                        except Exception:
                            pass

                        dbg_write(f"[payload] hex={raw.hex() if isinstance(raw, (bytes, bytearray)) else None}")

                        reading = parse_wave_payload(raw)
                        if reading is None:
                            dbg_write(f"[validation] Try {vtry}: could not parse payload; retrying read...")
                            time.sleep(0.3)
                            continue

                        short_pci = reading.short_pci
                        long_pci = 0.0

                        if short_pci < 0:
                            short_pci = 0.0
                        if short_pci > RADON_CLAMP_MAX:
                            dbg_write(f"[validation] Clamping short from {short_pci} -> {RADON_CLAMP_MAX}")
                            short_pci = RADON_CLAMP_MAX

                        dbg_write(f"[validation] Accepted ST={short_pci} pCi/L, LT disabled -> 0.0 pCi/L")
                        last_good = RadonReading(short_pci=short_pci, long_pci=long_pci)

                        status_patch({
                            "airthings": {
                                "state": "READ_OK",
                                "level": "ok",
                                "mac": mac,
                                "battery": batt_obj,
                                "read": {"last_ok_local": _now_iso(), "last_error": None}
                            }
                        })

                        return last_good
                finally:
                    try:
                        await client.disconnect()
                    except Exception:
                        pass

            except EOFError:
                if last_good is not None:
                    dbg_write(f"[cycle {cycle}] EOFError after successful validation; ignoring and returning last_good.")
                    status_patch({
                        "airthings": {
                            "state": "READ_OK",
                            "level": "ok",
                            "mac": mac,
                            "read": {"last_ok_local": _now_iso(), "last_error": None}
                        }
                    })
                    return last_good

                dbg_write(f"[cycle {cycle}] EOFError before validation; retrying...")
                status_patch({
                    "airthings": {
                        "state": "WAITING_FOR_READ",
                        "level": "warn",
                        "mac": mac,
                        "read": {"last_error": "EOFError during GATT read"}
                    }
                })
                time.sleep(float(RETRY_SECONDS))
            except Exception as e:
                log_exception(f"[cycle {cycle}] Connect/read error (attempt {attempt})", e)
                status_patch({
                    "airthings": {
                        "state": "WAITING_FOR_READ",
                        "level": "warn",
                        "mac": mac,
                        "battery": batt_obj,
                        "read": {"last_error": f"{type(e).__name__}: {e}"}
                    }
                })
                dbg_write(f"[cycle {cycle}] Waiting 12.0s before next attempt...")
                time.sleep(12.0)

    raise RuntimeError("Failed to read radon from Airthings after retries.")



# ---------------------------
# Fan control algorithm (extracted)
# ---------------------------

FAN_ALGO_STATE_PATH = os.getenv("RADON_FAN_ALGO_STATE_PATH", "/var/lib/radonbox/fan-algo-state.json").strip()
ST_ON_CONSECUTIVE_SAMPLES = int(os.getenv("RADON_ST_ON_SAMPLES", "2"))
ST_OFF_CONSECUTIVE_SAMPLES = int(os.getenv("RADON_ST_OFF_SAMPLES", "2"))

FAN_ALGO_VERSION = "st-only-v2"


def _load_fan_algo_state() -> dict:
    try:
        with open(FAN_ALGO_STATE_PATH, "r", encoding="utf-8") as f:
            j = json.load(f)
        if not isinstance(j, dict):
            return {}
        return j
    except Exception:
        return {}


def _save_fan_algo_state(j: dict) -> None:
    try:
        d = os.path.dirname(FAN_ALGO_STATE_PATH)
        if d and not os.path.exists(d):
            os.makedirs(d, exist_ok=True)
        tmp = FAN_ALGO_STATE_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(j, f, sort_keys=True)
        os.replace(tmp, FAN_ALGO_STATE_PATH)
    except Exception:
        # Non-fatal; algorithm will still work, just without persistence.
        pass


def _backup_fan_algo_state() -> str | None:
    """Best-effort backup of the algo state file; returns backup path or None."""
    try:
        if not os.path.exists(FAN_ALGO_STATE_PATH):
            return None
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        bak = FAN_ALGO_STATE_PATH + f".bak.{ts}"
        shutil.copy2(FAN_ALGO_STATE_PATH, bak)
        return bak
    except Exception:
        return None

def decide_fan_state(
    st_pci: float,
    it_pci: float | None,
    it_ready: bool,
    current_state: bool,
    on_threshold: float,
    off_threshold: float,
    *,
    installation_day: bool,
) -> tuple[bool, str, dict]:
    """
    ST-only fan control.

    Control rules:
    - Installation day: force ON.
    - Fan ON requires ST >= ON threshold for N consecutive samples.
      A single high ST reading is treated as an unconfirmed spike and does not turn the fan ON.
    - Fan OFF requires ST <= OFF threshold for M consecutive samples.
    - IT and Airthings LT are informational only and are not used for control.
    """
    state = _load_fan_algo_state()

    total = int(state.get("total_samples", 0) or 0)
    st_on_streak = int(state.get("st_on_streak", 0) or 0)
    st_off_streak = int(state.get("st_off_streak", 0) or 0)
    last_desired = state.get("last_desired_state", None)

    if state.get("algo_version") != FAN_ALGO_VERSION or not isinstance(last_desired, bool):
        last_desired_state = bool(current_state)
        state["last_desired_bootstrapped_from_shelly"] = True
    else:
        last_desired_state = bool(last_desired)

    desired = last_desired_state
    reason = "HOLD_STATE"

    if installation_day:
        desired = True
        reason = "INSTALLATION_DAY_FORCE_ON"
        st_on_streak = 0
        st_off_streak = 0
    else:
        total += 1

        if st_pci >= on_threshold:
            st_on_streak += 1
            st_off_streak = 0
        elif st_pci <= off_threshold:
            st_off_streak += 1
            st_on_streak = 0
        else:
            st_on_streak = 0
            st_off_streak = 0

        if st_on_streak >= ST_ON_CONSECUTIVE_SAMPLES:
            desired = True
            reason = f"ST_ON_STREAK_{ST_ON_CONSECUTIVE_SAMPLES}"
        elif st_pci >= on_threshold:
            desired = last_desired_state
            reason = "ST_SPIKE_WAIT_CONFIRM"
        elif st_off_streak >= ST_OFF_CONSECUTIVE_SAMPLES:
            desired = False
            reason = f"ST_OFF_STREAK_{ST_OFF_CONSECUTIVE_SAMPLES}"
        else:
            desired = last_desired_state
            reason = "HOLD_STATE"

    state["total_samples"] = total
    state["st_on_streak"] = st_on_streak
    state["st_off_streak"] = st_off_streak
    state["algo_version"] = FAN_ALGO_VERSION
    state["last_desired_state"] = bool(desired)
    state["last_st_pci"] = st_pci
    state["last_it_pci"] = it_pci
    state["last_reason"] = reason
    state["it_ready"] = bool(it_ready)
    state["install_override"] = bool(installation_day)
    state["last_update_local"] = _now_iso()

    _save_fan_algo_state(state)

    return desired, reason, state


def _read_structured_samples(log_path: str) -> list[tuple[datetime, float]]:
    """
    Read prior structured sample rows from radon-log.txt.
    Supports both 6-column legacy rows and 7-column rows.
    Returns chronological [(timestamp_local_naive, st_value), ...].
    """
    samples: list[tuple[datetime, float]] = []
    try:
        with open(log_path, "r", encoding="utf-8") as f:
            for line in f:
                row = [x.strip() for x in line.strip().split(",")]
                if len(row) not in (6, 7):
                    continue
                try:
                    ts = _to_local_naive(datetime.fromisoformat(row[0]))
                    st_val = float(row[1])
                except Exception:
                    continue
                samples.append((ts, st_val))
    except FileNotFoundError:
        return []

    samples.sort(key=lambda item: item[0])
    return samples


def _is_high_spike(samples: list[tuple[datetime, float]], idx: int, on_threshold: float) -> bool:
    """
    A high ST spike is a single unconfirmed ST reading >= ON threshold with no adjacent
    reading >= ON threshold.
    """
    _ts, st_val = samples[idx]
    if st_val < on_threshold:
        return False

    prev_high = idx > 0 and samples[idx - 1][1] >= on_threshold
    next_high = idx < (len(samples) - 1) and samples[idx + 1][1] >= on_threshold
    return not (prev_high or next_high)


def compute_it_from_log(
    log_path: str,
    now_dt: datetime,
    window_days: int,
    *,
    on_threshold: float,
) -> tuple[float | None, bool]:
    """
    Compute informational-only IT from historical ST values.

    Rules:
    - IT is not considered ready until there is a full `window_days` of history.
    - Isolated high ST spikes are excluded from the IT average.
    - Returns (it_pci, it_ready). When not ready, it_pci is None.
    """
    now_local = _to_local_naive(now_dt)
    cutoff = now_local - timedelta(days=window_days)

    samples = _read_structured_samples(log_path)
    if not samples:
        return None, False

    first_ts = samples[0][0]
    it_ready = first_ts <= cutoff
    if not it_ready:
        return None, False

    window_values: list[float] = []
    for idx, (ts, st_val) in enumerate(samples):
        if ts < cutoff:
            continue
        if _is_high_spike(samples, idx, on_threshold):
            continue
        window_values.append(st_val)

    if not window_values:
        return None, True

    it_pci = round(sum(window_values) / len(window_values), 2)
    return it_pci, True

RADON_LOG_PATH = os.getenv(
    "RADON_LOG_PATH",
    "/opt/radonbox/current/radon-min/radon-log.txt"
).strip()

def _to_local_naive(dt: datetime) -> datetime:
    """
    Normalize datetimes for safe comparison against mixed historical log formats.
    - aware -> convert to local timezone, then drop tzinfo
    - naive -> leave as-is
    """
    if dt.tzinfo is not None:
        return dt.astimezone().replace(tzinfo=None)
    return dt

# ---------------------------
# Main
# ---------------------------

async def main() -> int:
    dbg_write("Starting radon automation...")
    dbg_write("")
    dbg_write("=== Radon run start ===")
    dbg_write(
        f"Env: Python {sys.version.split()[0]}, "
        f"Bleak {getattr(__import__('bleak'), '__version__', 'unknown')}, "
        f"Platform {os.uname().sysname} {os.uname().release} ({os.uname().machine})"
    )

    # ---------------------------
    # Installation settle window
    # ---------------------------
    now_ts = int(time.time())
    install_ts = _parse_int(INSTALL_TS_RAW)
    settle_seconds = _parse_int(RADON_SETTLE_SECONDS_RAW) or 86400

    valid_after_ts = _parse_int(RADON_VALID_AFTER_TS_RAW)
    if valid_after_ts is None and install_ts is not None:
        valid_after_ts = install_ts + settle_seconds

    is_settling = bool(install_ts is not None and valid_after_ts is not None and now_ts < valid_after_ts)
    radon_is_valid = not is_settling

    # Publish install/validity info for portal/status consumers.
    status_patch({
    "install": {
        "install_ts": install_ts,
        "settle_seconds": (settle_seconds if install_ts is not None else None),
        "valid_after_ts": valid_after_ts,
        "is_settling": is_settling,
    },
    "radon": {
        "is_valid": radon_is_valid,
        "valid_reason": ("settling" if is_settling else "ok"),
    }
    })


    # Read radon
    # If AIR_MAC is empty, discover current address via AIR_MFG_ID.
    mac = AIR_MAC
    if not mac:
        if AIR_MFG_ID is None:
            status_patch({
                "airthings": {"state": "ERROR", "level": "error", "mac": None},
                "summary": {"state": "ERROR", "level": "error", "text": "Missing AIR_MAC and invalid AIR_MFG_ID"}
            })
            raise RuntimeError("Missing AIR_MAC and invalid AIR_MFG_ID; cannot discover Airthings device.")
        dbg_write(f"No AIR_MAC set; discovering Airthings via AIR_MFG_ID={AIR_MFG_ID_RAW}...")
        mac = await resolve_airthings_addr_by_mfg_id(AIR_MFG_ID)
        if not mac:
            status_patch({
                "airthings": {"state": "ERROR", "level": "error", "mac": None},
                "summary": {"state": "ERROR", "level": "error", "text": "Could not discover Airthings via AIR_MFG_ID"}
            })
            raise RuntimeError(f"Could not discover Airthings via AIR_MFG_ID={AIR_MFG_ID_RAW}.")
        dbg_write(f"Discovered Airthings address: {mac}")

    reading = await read_radon_gatt(mac)

    st_pci = reading.short_pci
    airthings_lt_pci = reading.long_pci

    dbg_write(f"Airthings ST radon: {st_pci:.2f} pCi/L")
    dbg_write("Airthings LT radon: N/A (disabled, reporting 0.0)")

    # --- Compute IT (Intermediate-Term, informational only) ---
    now_dt = datetime.now().astimezone()

    it_pci, it_ready = compute_it_from_log(
        RADON_LOG_PATH,
        now_dt,
        IT_WINDOW_DAYS,
        on_threshold=ON_THRESHOLD,
    )

    sample_count = len(_read_structured_samples(RADON_LOG_PATH))

    if it_ready and it_pci is not None:
        dbg_write(f"Computed IT ({IT_WINDOW_DAYS}-day): {it_pci:.2f} pCi/L (ready=True)")
    else:
        it_pci = None
        dbg_write(
            f"Computed IT ({IT_WINDOW_DAYS}-day): not yet available "
            f"(samples={sample_count}, need full {IT_WINDOW_DAYS} days)"
        )

    status_patch({
        "summary": {"state": ("SETTLING" if is_settling else "OPERATIONAL"), "level": ("warn" if is_settling else "ok"), "text": ("Settling — readings valid after %s" % datetime.fromtimestamp(valid_after_ts).astimezone().isoformat(timespec="seconds") if (is_settling and valid_after_ts) else "System operational")}
    })

    status_patch({
        "radon": {
            "st_pci": round(st_pci, 2),
            "it_pci": (round(it_pci, 2) if it_pci is not None else None),
            "it_window_days": IT_WINDOW_DAYS,
            "it_ready": bool(it_ready),
            "airthings_lt_pci": 0.0,
            "is_valid": radon_is_valid,
            "valid_reason": ("settling" if is_settling else "ok"),
        }
    })

    # Read Shelly state
    current_state = shelly_get_state()
    dbg_write(f"Current Shelly state: {current_state}")

    installation_flag = 0

    # Decide fan state (algorithm extracted to a standalone function)
    installation_day = is_installation_day()
    desired_state, fan_reason, _algo_state = decide_fan_state(
        st_pci=st_pci,
        it_pci=it_pci,
        it_ready=it_ready,
        current_state=current_state,
        on_threshold=ON_THRESHOLD,
        off_threshold=OFF_THRESHOLD,
        installation_day=installation_day,
    )
    if installation_day:
        installation_flag = 1
        dbg_write(
            f"Installation day: forcing fan ON regardless of ST={st_pci}, IT={it_pci}."
        )
    else:
        if fan_reason.startswith("ST_ON_STREAK_"):
            dbg_write(
                f"ON rule met (ST={st_pci} >= {ON_THRESHOLD} for {ST_ON_CONSECUTIVE_SAMPLES} consecutive samples); turning ON."
            )
        elif fan_reason == "ST_SPIKE_WAIT_CONFIRM":
            dbg_write(
                f"High ST reading {st_pci} is unconfirmed; treating as spike and holding previous fan state."
            )
        elif fan_reason.startswith("ST_OFF_STREAK_"):
            dbg_write(
                f"OFF rule met (ST={st_pci} <= {OFF_THRESHOLD} for {ST_OFF_CONSECUTIVE_SAMPLES} consecutive samples); turning OFF."
            )
        else:
            dbg_write(
                f"ST={st_pci} is between OFF<={OFF_THRESHOLD} and ON>={ON_THRESHOLD} confirmation zones; reasserting last desired state."
            )
        
    # Always (re)assert the desired Shelly state every cycle.
    # This is idempotent for Shelly and helps recover from external flips (power glitch, schedule, manual press, etc.).
    if desired_state == current_state:
        dbg_write(f"Desired Shelly state already {desired_state}; sending command anyway to ensure state.")
    shelly_set_state(desired_state)

    fan_state = 1 if desired_state else 0
    timestamp = datetime.now().isoformat(timespec="milliseconds")

    try:
        it_csv = "" if it_pci is None else f"{it_pci}"
        sys.stdout.write(
            f"{timestamp},{st_pci},{it_csv},{airthings_lt_pci},{fan_state},{installation_flag},{fan_reason}\n"
        )
        sys.stdout.flush()
    except Exception as e:
        log_exception("Structured log write failed", e)

    dbg_write("Radon automation complete.")
    return 0


if __name__ == "__main__":
    import asyncio
    try:
        raise SystemExit(asyncio.run(main()))
    except KeyboardInterrupt:
        raise