#!/usr/bin/env bash
# radon-devices-init.sh — Device discovery + config cache for RadonBox (Beta3)
#
# Beta3 behavior change:
# - Airthings "discovery" is allowed to succeed even if GATT validation is flaky (sleepy sensor).
#   We select the best Airthings candidate from scan output if strict validation fails.
#
set -euo pipefail
# Logging + locking (single-instance)
LOG_DIR="/var/log/radonbox"
INIT_LOG="${LOG_DIR}/radon-devices-init.log"
LOCKFILE="/run/lock/radon-devices-init.lock"
LOCK_FD=

mkdir -p "$LOG_DIR" /run/lock || true
# Provide historical convenience path: /opt/radonbox/current/radon-min/radon-devices-init.log
if [[ -d "/opt/radonbox/current/radon-min" ]]; then
  ln -sf "$INIT_LOG" "/opt/radonbox/current/radon-min/radon-devices-init.log" || true
fi

exec {LOCK_FD}>"$LOCKFILE" || true
if ! flock -n "$LOCK_FD"; then
  echo "[radon-devices-init] Another discovery is already running (lock: $LOCKFILE). Exiting." >&2
  exit 0
fi
RADON_DIR="/opt/radonbox/current/radon-min"
FALLBACK_DIR="/home/boris/radon-min"
if [[ -d "$RADON_DIR" ]]; then
  BASE="$RADON_DIR"
else
  BASE="$FALLBACK_DIR"
fi
RADON_LOG="${BASE}/radon-log.txt"
CHART="${BASE}/radon-chart.png"
CONFIG="/etc/radonbox/radon-config.conf"
INSTALL_DATE="/etc/radonbox/install-date.txt"

RUN_RADON="/usr/local/bin/run-radon.sh"

AIR_DISCOVER="${BASE}/discover-airthings-mac.py"

CONF_DIR="/etc/radonbox"
LAST_AIR_MAC_FILE="${CONF_DIR}/last-air-mac"

KEEP_INSTALL_SNAPSHOTS=5

STATUS_UPDATER="/usr/local/bin/radon-status-update.py"

status_patch() {
  [[ -x "$STATUS_UPDATER" ]] || return 0
  sudo "$STATUS_UPDATER" "$1" >/dev/null 2>&1 || true
}

log() {
  local msg="$1"
  local ts
  ts="$(date '+%Y-%m-%d %H:%M:%S')"
  echo "[${ts}] [radon-devices-init] ${msg}" | tee -a "$INIT_LOG" >&2
}

ensure_init_log() {
  mkdir -p "$LOG_DIR"
  touch "$INIT_LOG"
  chmod 664 "$INIT_LOG" || true
  chown boris:boris "$INIT_LOG" || true
}

write_install_date_marker() {
  sudo mkdir -p "$CONF_DIR"
  echo "$(date +%F)" | sudo tee "$INSTALL_DATE" >/dev/null
  sudo chown root:root "$INSTALL_DATE"
  sudo chmod 0644 "$INSTALL_DATE"
  log "Wrote install-date marker: $INSTALL_DATE"
}

prune_install_snapshots() {
  local keep="${1:-5}"
  local files
  files="$(ls -1t "${BASE}"/radon-log.install-*.txt 2>/dev/null || true)"
  [[ -z "$files" ]] && return 0

  local n=0
  while IFS= read -r f; do
    [[ -z "$f" ]] && continue
    n=$((n+1))
    if (( n > keep )); then
      rm -f "$f" || true
    fi
  done <<< "$files"
}

rotate_or_reset_artifacts() {
  if [[ -f "$RADON_LOG" ]]; then
    local ts
    ts="$(date +%Y%m%d-%H%M%S)"
    mv -f "$RADON_LOG" "${BASE}/radon-log.install-${ts}.txt"
  fi
  rm -f "$CHART" || true
  prune_install_snapshots "$KEEP_INSTALL_SNAPSHOTS"
  log "Reset artifacts: rotated radon-log and removed chart (if present); kept newest ${KEEP_INSTALL_SNAPSHOTS} install snapshots"
}

config_is_populated() {
  [[ -f "$CONFIG" ]] || return 1
  local shelly switchid
  shelly="$(grep -E '^[[:space:]]*SHELLY_HOST=' "$CONFIG" 2>/dev/null | sed 's/^[[:space:]]*SHELLY_HOST=//' | tr -d $'
' | awk 'NF{v=$0} END{print v}' || true)"
  switchid="$(grep -E '^[[:space:]]*SHELLY_SWITCH_ID=' "$CONFIG" 2>/dev/null | sed 's/^[[:space:]]*SHELLY_SWITCH_ID=//' | tr -d $'
' | awk 'NF{v=$0} END{print v}' || true)"
  [[ -n "$shelly" && -n "$switchid" ]]
}

discover_shelly_mdns_once() {
  command -v avahi-browse >/dev/null 2>&1 || { log "ERROR: avahi-browse not found"; return 1; }

  local line
  line="$(avahi-browse -rtp _http._tcp 2>/dev/null \
        | grep -Ei '^=;.*;IPv4;.*;.*;local;.*\.local;[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+;80;' \
        | grep -i shelly \
        | head -n1 || true)"

  [[ -z "$line" ]] && return 1

  local host addr
  host="$(echo "$line" | awk -F';' '{print $7}' | tr -d $'\r')"
  addr="$(echo "$line" | awk -F';' '{print $8}' | tr -d $'\r')"
  [[ -z "$host" && -z "$addr" ]] && return 1

  echo "${host} ${addr}"
}

discover_shelly_mdns_retry() {
  local tries="${1:-10}"
  local sleep_s="${2:-2}"
  local i host addr

  for ((i=1; i<=tries; i++)); do
    if read -r host addr < <(discover_shelly_mdns_once); then
      echo "${host} ${addr}"
      return 0
    fi
    log "Shelly mDNS not ready yet (attempt ${i}/${tries}); sleeping ${sleep_s}s..."
    sleep "$sleep_s"
  done

  log "ERROR: No resolved Shelly mDNS record found via avahi-browse after ${tries} attempts."
  return 1
}

validate_shelly_rpc() {
  local h="$1"
  curl -s --max-time 2 "http://${h}/rpc/Shelly.GetDeviceInfo" >/dev/null 2>&1
}

write_config_atomic() {
  local shelly_host="$1"
  local air_mac="$2"
  local switch_id="${3:-0}"

  # Ensure config exists; do NOT rewrite whole file (preserve keys like OWNER_EMAIL, EMAIL_* etc.)
  sudo mkdir -p "$CONF_DIR"
  if [[ ! -f "$CONFIG" ]]; then
    sudo tee "$CONFIG" >/dev/null <<'EOF'
# RadonBox device config
# Filled/updated by radon-devices-init.sh after install/factory-reset
EOF
    sudo chown root:root "$CONFIG"
    sudo chmod 0644 "$CONFIG"
  fi

  # Helper: set/replace KEY=VALUE in-place, else append.
  # Only updates the keys we own; preserves everything else.
  set_kv() {
    local key="$1"
    local val="$2"
    if sudo grep -qE "^[[:space:]]*${key}=" "$CONFIG"; then
      sudo sed -i -E "s|^[[:space:]]*${key}=.*|${key}=${val}|" "$CONFIG"
    else
      echo "${key}=${val}" | sudo tee -a "$CONFIG" >/dev/null
    fi
  }

  # Load factory defaults (thresholds etc.) so our fallbacks match factory reset behavior
  local factory_defaults="/opt/radonbox/current/radon-min/radon-factory-defaults.conf"
  if [[ -f "$factory_defaults" ]]; then
    # shellcheck disable=SC1090
    source "$factory_defaults" >/dev/null 2>&1 || true
  fi

  # Preserve existing thresholds (or default)
  local radon_on radon_off
  radon_on="$(grep -E '^RADON_ON_THRESHOLD=' "$CONFIG" 2>/dev/null | tail -n1 | cut -d= -f2- | tr -d $'\r' | xargs || true)"
  radon_off="$(grep -E '^RADON_OFF_THRESHOLD=' "$CONFIG" 2>/dev/null | tail -n1 | cut -d= -f2- | tr -d $'\r' | xargs || true)"
  radon_on="${radon_on:-${RADON_ON_THRESHOLD:-4.0}}"
  radon_off="${radon_off:-${RADON_OFF_THRESHOLD:-2.0}}"

  # Airthings auto-detect defaults (kept here so installs are robust to BLE address randomization)
  local air_mode air_mfg_id
  air_mode="$(grep -E '^AIR_MODE=' "$CONFIG" 2>/dev/null | tail -n1 | cut -d= -f2- | tr -d $'\r' || true)"
  air_mfg_id="$(grep -E '^AIR_MFG_ID=' "$CONFIG" 2>/dev/null | tail -n1 | cut -d= -f2- | tr -d $'\r' || true)"
  air_mode="${air_mode:-auto}"
  air_mfg_id="${air_mfg_id:-0x0334}"

  # Update only keys owned by devices-init (everything else preserved)
  set_kv "SHELLY_HOST" "$shelly_host"
  set_kv "SHELLY_SWITCH_ID" "$switch_id"
  set_kv "AIR_MODE" "$air_mode"
  set_kv "AIR_MFG_ID" "$air_mfg_id"
  set_kv "RADON_ON_THRESHOLD" "$radon_on"
  set_kv "RADON_OFF_THRESHOLD" "$radon_off"

  # Keep discovery keys grouped under the "Device discovery" section for readability.
  # Also avoids confusing cases where SHELLY_SWITCH_ID gets appended at end of file.
  if sudo grep -qE "^# --- Device discovery ---" "$CONFIG"; then
    local tmp
    tmp="$(mktemp)"
    sudo awk -v shelly="$shelly_host" -v sw="$switch_id" -v mode="$air_mode" -v mfg="$air_mfg_id" \
      'BEGIN{in_disc=0; inserted=0}
        function iskey(line){ return line ~ /^(SHELLY_HOST|SHELLY_SWITCH_ID|AIR_MODE|AIR_MFG_ID)=/ }
        {
          if ($0 ~ /^# --- Device discovery ---/) {
            print $0
            print "SHELLY_HOST=" shelly
            print "SHELLY_SWITCH_ID=" sw
                        print "AIR_MODE=" mode
            print "AIR_MFG_ID=" mfg
            inserted=1
            in_disc=1
            next
          }
          if (in_disc) {
            if ($0 ~ /^# ---/ && $0 !~ /^# --- Device discovery ---/) { in_disc=0 }
            else if (iskey($0)) next
          }
          if (!in_disc && iskey($0)) next
          print $0
        }
        END{
          if (!inserted) {
            print ""
            print "# --- Device discovery ---"
            print "SHELLY_HOST=" shelly
            print "SHELLY_SWITCH_ID=" sw
                        print "AIR_MODE=" mode
            print "AIR_MFG_ID=" mfg
          }
        }' "$CONFIG" > "$tmp"
    sudo install -o root -g root -m 0644 "$tmp" "$CONFIG"
    rm -f "$tmp" || true
  fi
}


read_cached_air_mac() {
  [[ -f "$LAST_AIR_MAC_FILE" ]] || return 1
  local m
  m="$(tr -d $'\r' < "$LAST_AIR_MAC_FILE" | grep -Eo '([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}' | tail -n1 | tr '[:lower:]' '[:upper:]' || true)"
  [[ "$m" =~ ^([0-9A-F]{2}:){5}[0-9A-F]{2}$ ]] || return 1
  echo "$m"
}

write_cached_air_mac() {
  local m="$1"
  sudo mkdir -p "$CONF_DIR"
  echo "$m" | sudo tee "$LAST_AIR_MAC_FILE" >/dev/null
  sudo chown root:root "$LAST_AIR_MAC_FILE"
  sudo chmod 0644 "$LAST_AIR_MAC_FILE"
}

# Strict mode: whatever discover-airthings-mac.py considers "validated"
discover_airthings_mac_strict() {
  sudo -n systemctl restart bluetooth >>"$INIT_LOG" 2>&1 || true
  sleep 2

  local preferred=""
  if preferred="$(read_cached_air_mac)"; then
    log "Found cached Airthings MAC in ${LAST_AIR_MAC_FILE}: ${preferred} (will prefer it first)"
  fi

  local attempt air_mac
  air_mac=""

  for attempt in 1 2 3 4 5; do
    log "Airthings discovery attempt ${attempt}/5 (strict validate) ..."
    if [[ -n "$preferred" ]]; then
      air_mac="$(sudo -n /usr/bin/python3 "$AIR_DISCOVER" --preferred-mac "$preferred" 2>>"$INIT_LOG" \
        | grep -Eo '([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}' | tail -n1 | tr -d $'\r' | tr '[:lower:]' '[:upper:]' || true)"
    else
      air_mac="$(sudo -n /usr/bin/python3 "$AIR_DISCOVER" 2>>"$INIT_LOG" \
        | grep -Eo '([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}' | tail -n1 | tr -d $'\r' | tr '[:lower:]' '[:upper:]' || true)"
    fi

    if [[ "$air_mac" =~ ^([0-9A-F]{2}:){5}[0-9A-F]{2}$ ]]; then
      log "Airthings validated (strict): $air_mac"
      echo "$air_mac"
      return 0
    fi

    if [[ "$attempt" == "2" ]]; then
      log "Airthings strict validate still failing; restarting bluetooth and retrying..."
      sudo -n systemctl restart bluetooth >>"$INIT_LOG" 2>&1 || true
    fi
    sleep 5
  done

  return 1
}

# Soft mode: choose best Airthings-looking MAC from discover script output
discover_airthings_mac_soft() {
  log "Airthings strict validate failed; using SOFT selection from scan output (sleepy sensor friendly)."

  local preferred=""
  if preferred="$(read_cached_air_mac)"; then
    log "Soft mode: using cached MAC as preferred candidate: ${preferred}"
    echo "$preferred"
    return 0
  fi

  # Capture combined output so we can parse "Airthings/Wave" lines
  local out
  out="$(sudo -n /usr/bin/python3 "$AIR_DISCOVER" 2>&1 || true)"
  echo "$out" >>"$INIT_LOG"

  # First try: any line that mentions Airthings or Wave and contains a MAC
  local mac
  mac="$(echo "$out" \
    | awk 'BEGIN{IGNORECASE=1} /Airthings|Wave/ {
        for(i=1;i<=NF;i++){
          if($i ~ /^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$/){print toupper($i); exit}
        }
      }')"

  if [[ "$mac" =~ ^([0-9A-F]{2}:){5}[0-9A-F]{2}$ ]]; then
    log "Airthings selected (soft): $mac"
    echo "$mac"
    return 0
  fi

  # Fallback: first MAC seen at all (last resort)
  mac="$(echo "$out" | grep -Eo '([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}' | head -n1 | tr '[:lower:]' '[:upper:]' || true)"
  if [[ "$mac" =~ ^([0-9A-F]{2}:){5}[0-9A-F]{2}$ ]]; then
    log "Airthings selected (soft fallback): $mac"
    echo "$mac"
    return 0
  fi

  return 1
}

main() {
  ensure_init_log
  log "===== starting ====="
  log "Using config: $CONFIG"

  status_patch '{
    "summary":{"state":"INSTALLING","level":"warn","text":"Discovering devices..."},
    "shelly":{"state":"DISCOVERING","level":"warn"},
    "airthings":{"state":"DISCOVERING","level":"warn"}
  }'

  if [[ -f "$CONFIG" ]]; then
    log "Existing $CONFIG:"
    sudo sed 's/^/[radon-devices-init]   /' "$CONFIG" 2>/dev/null | tee -a "$INIT_LOG" >&2 || true
  else
    log "No existing $CONFIG (will create if discovery succeeds)."
  fi

  write_install_date_marker

  if config_is_populated; then
    log "Config already populated; nothing to do."
    status_patch '{
      "summary":{"state":"OPERATIONAL","level":"ok","text":"Config already populated"},
      "shelly":{"state":"VALIDATED","level":"ok"},
      "airthings":{"state":"FOUND","level":"ok"}
    }'
    log "===== done ====="
    exit 0
  fi

  rotate_or_reset_artifacts

  # ---- Discover Shelly ----
  local host addr shelly_use

# If SHELLY_HOST is already set in config (installer override), prefer it if reachable.
local cfg_shelly
cfg_shelly="$(grep -E '^SHELLY_HOST=' "$CONFIG" 2>/dev/null | sed 's/^SHELLY_HOST=//' | tr -d $'\r' | awk 'NF{v=$0} END{print v}' || true)"

if [[ -n "$cfg_shelly" ]] && validate_shelly_rpc "$cfg_shelly"; then
  shelly_use="$cfg_shelly"
  log "Using installer-provided SHELLY_HOST=$cfg_shelly"
else
  [[ -n "$cfg_shelly" ]] && log "Installer-provided SHELLY_HOST=$cfg_shelly not reachable; falling back to auto-discovery"
  read -r host addr < <(discover_shelly_mdns_retry 10 2)

  if [[ -n "${host:-}" ]] && validate_shelly_rpc "$host"; then
    shelly_use="$host"
    log "mDNS Shelly resolved and validated via hostname: host='${host}' addr='${addr}' using='${shelly_use}'"
  elif [[ -n "${addr:-}" ]] && validate_shelly_rpc "$addr"; then
    shelly_use="$addr"
    log "mDNS Shelly validated via IP fallback: host='${host}' addr='${addr}' using='${shelly_use}'"
  else
    log "ERROR: Shelly discovery failed or RPC not reachable (host='${host}' addr='${addr}'). Not writing $CONFIG."
    status_patch '{
      "shelly":{"state":"ERROR","level":"error","last_error":"Shelly discovery failed"},
      "summary":{"state":"ERROR","level":"error","text":"Smart plug not reachable"}
    }'
    log "===== done ====="
    exit 1
  fi

  fi

  status_patch '{
    "shelly":{"state":"VALIDATED","level":"ok","host":"'"$shelly_use"'","switch_id":0,"last_error":null},
    "summary":{"state":"INSTALLING","level":"warn","text":"Smart plug connected — discovering radon meter..."}
  }'
  # ---- Airthings ----
  # BLE devices often use randomized addresses; we do NOT persist a MAC.
  # radon-automation.py will discover the Airthings device on each run via AIR_MFG_ID.
  log "Skipping Airthings MAC discovery during install; radon meter will be discovered per run."
  local air_mac
  air_mac=""
  status_patch '{
    "airthings":{"state":"DISCOVER_ON_DEMAND","level":"ok","tip":"Radon meter will be discovered on each run (BLE address randomization)."},
    "summary":{"state":"READY_WAITING_FOR_FIRST_READ","level":"warn","text":"Installation complete — waiting for first radon reading"}
  }'

  # ---- Write config BEFORE running run-radon.sh ----
  write_config_atomic "$shelly_use" "$air_mac" "0"
  log "Wrote $CONFIG:"
  sudo sed 's/^/[radon-devices-init]   /' "$CONFIG" 2>/dev/null | tee -a "$INIT_LOG" >&2 || true

  # ---- Run one radon cycle ----
  if [[ ! -x "$RUN_RADON" ]]; then
    log "ERROR: $RUN_RADON not found or not executable."
    status_patch '{
      "summary":{"state":"ERROR","level":"error","text":"run-radon.sh missing; cannot complete first cycle"}
    }'
    log "===== done ====="
    exit 1
  fi

  log "Running one radon cycle via $RUN_RADON ..."
  log "Working directory: $BASE"
  log "RUN_RADON path: $RUN_RADON"
  cd "$BASE" || { log "ERROR: cd $BASE failed"; exit 1; }

  if "$RUN_RADON" >>"$INIT_LOG" 2>&1; then
    log "One radon cycle complete."
    log "===== done ====="
  else
    rc=$?
    log "ERROR: initial run-radon failed with exit code $rc"
    status_patch '{
      "summary":{"state":"ERROR","level":"error","text":"Initial radon cycle failed during install"}
    }'
    exit "$rc"
  fi

}

main "$@"
