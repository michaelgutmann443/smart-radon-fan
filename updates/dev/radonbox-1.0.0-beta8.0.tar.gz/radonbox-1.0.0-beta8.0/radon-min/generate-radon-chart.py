#!/usr/bin/env python3
"""
Boris generate-radon-chart.py

Log format (CSV lines written by radon-automation.py):
    legacy: timestamp_iso,short_pci,long_pci,fan_state,install_flag,reason
    current: timestamp_iso,short_pci,it_pci_or_blank,airthings_lt_pci,fan_state,install_flag,reason
"""

import os
import sys
import csv
from datetime import datetime, timedelta

import matplotlib.pyplot as plt
import matplotlib.dates as mdates

CONFIG_PATH = "/etc/radonbox/radon-config.conf"

def _read_kv_conf(path: str) -> dict:
    kv = {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for raw in f:
                s = raw.strip()
                if not s or s.startswith('#') or '=' not in s:
                    continue
                k, v = s.split('=', 1)
                kv[k.strip()] = v.strip()
    except FileNotFoundError:
        return {}
    except Exception:
        return {}
    return kv

def _normalize_dt(dt: datetime) -> datetime:
    # Ensure offset-aware datetimes are converted to local naive for subtraction/plotting.
    if getattr(dt, 'tzinfo', None) is not None and dt.tzinfo is not None:
        try:
            return dt.astimezone().replace(tzinfo=None)
        except Exception:
            return dt.replace(tzinfo=None)
    return dt

def _parse_dt(val: str) -> datetime | None:
    if not val:
        return None
    v = str(val).strip()
    try:
        # Epoch seconds?
        if v.replace('.', '', 1).isdigit():
            return datetime.fromtimestamp(float(v))
    except Exception:
        pass
    try:
        dt = datetime.fromisoformat(v)
        return _normalize_dt(dt)
    except Exception:
        return None

def _get_settling_info() -> tuple[datetime | None, datetime | None, float | None]:
    kv = _read_kv_conf(CONFIG_PATH)
    install_dt = None
    if kv.get('INSTALL_ISO'):
        install_dt = _parse_dt(kv.get('INSTALL_ISO', ''))
    if install_dt is None and kv.get('INSTALL_TS'):
        install_dt = _parse_dt(kv.get('INSTALL_TS', ''))
    if install_dt is None:
        return None, None, None

    valid_dt = None
    if kv.get('RADON_VALID_AFTER_TS'):
        valid_dt = _parse_dt(kv.get('RADON_VALID_AFTER_TS', ''))
    if valid_dt is None:
        try:
            settle_s = int(str(kv.get('RADON_SETTLE_SECONDS', '86400')).strip() or '86400')
        except Exception:
            settle_s = 86400
        valid_dt = install_dt + timedelta(seconds=settle_s)

    install_dt = _normalize_dt(install_dt)
    valid_dt = _normalize_dt(valid_dt)
    try:
        dur_h = max(0.0, (valid_dt - install_dt).total_seconds() / 3600.0)
    except Exception:
        dur_h = None
    return install_dt, valid_dt, dur_h

# Defaults
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE_DEFAULT = os.path.join(SCRIPT_DIR, "radon-log.txt")
OUT_PNG = os.path.join(SCRIPT_DIR, "radon-chart.png")


CONFIG_PATHS = [
    "/etc/radonbox/radon-config.conf",
    os.path.expanduser("~/radon-config.conf"),
]

def load_thresholds():
    # Env overrides win (useful for testing)
    env_on = os.getenv("RADON_ON_THRESHOLD")
    env_off = os.getenv("RADON_OFF_THRESHOLD")
    if env_on and env_off:
        return float(env_on), float(env_off)

    # Parse radon-config.conf key=value
    for path in CONFIG_PATHS:
        try:
            with open(path, "r", encoding="utf-8") as f:
                kv = {}
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, v = [x.strip() for x in line.split("=", 1)]
                    kv[k] = v
            # Use the same keys radon-automation uses (adjust if your names differ)
            on = float(kv.get("RADON_ON_THRESHOLD", kv.get("RADON_ON_PCI", "2.0")))
            off = float(kv.get("RADON_OFF_THRESHOLD", kv.get("RADON_OFF_PCI", "1.5")))
            return on, off
        except FileNotFoundError:
            continue
        except Exception:
            # If config is malformed, fall through to defaults
            break

    return 4.0, 2.0

RADON_ON_THRESHOLD, RADON_OFF_THRESHOLD = load_thresholds()


def load_it_window_days():
    env_days = os.getenv("IT_WINDOW_DAYS")
    if env_days:
        try:
            return max(1, int(env_days))
        except Exception:
            pass

    for path in CONFIG_PATHS:
        try:
            with open(path, "r", encoding="utf-8") as f:
                kv = {}
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, v = [x.strip() for x in line.split("=", 1)]
                    kv[k] = v
            return max(1, int(kv.get("IT_WINDOW_DAYS", "7")))
        except FileNotFoundError:
            continue
        except Exception:
            break

    return 7

IT_WINDOW_DAYS = load_it_window_days()



def parse_log(path):
    """
    Supports:
      old: timestamp,ST,LT,fan,install,reason
      new: timestamp,ST,IT_or_blank,AirthingsLT,fan,install,reason

    Notes:
      - ST is always displayed exactly as logged.
      - IT may be blank until a full 7-day average exists.
      - Airthings LT is currently ignored for display.
    """
    times = []
    sts = []
    its = []
    lts = []
    fans = []
    install_flags = []

    try:
        with open(path, "r", encoding="utf-8") as f:
            reader = csv.reader(f)
            for row in reader:
                try:
                    if len(row) == 6:
                        # Legacy format:
                        # timestamp, ST, LT, fan, install, reason
                        ts_str, st_str, legacy_second_str, fan_str, install_str, reason = row
                        ts = datetime.fromisoformat(ts_str)
                        st_val = float(st_str)
                        it_val = float(legacy_second_str)   # fallback for old logs
                        lt_val = None
                        fan_val = int(fan_str)
                        install_val = int(install_str)

                    elif len(row) == 7:
                        # Current format:
                        # timestamp, ST, IT_or_blank, LT, fan, install, reason
                        ts_str, st_str, it_str, lt_str, fan_str, install_str, reason = row
                        ts = datetime.fromisoformat(ts_str)
                        st_val = float(st_str)
                        it_val = float(it_str) if str(it_str).strip() != "" else None
                        lt_val = float(lt_str) if str(lt_str).strip() != "" else None
                        fan_val = int(fan_str)
                        install_val = int(install_str)

                    else:
                        continue

                except Exception:
                    continue

                times.append(ts)
                sts.append(st_val)
                its.append(it_val)
                lts.append(lt_val)
                fans.append(fan_val)
                install_flags.append(install_val)

    except FileNotFoundError:
        print(f"Log file not found: {path}")
        return [], [], [], [], [], []

    return times, sts, its, lts, fans, install_flags


def trim_by_days(times, sts, its, lts, fans, install_flags, days_back):
    """
    Keep only points within the last `days_back` days from the most recent timestamp.
    If days_back is None or <= 0, return the data unchanged.
    """
    if not times or days_back is None or days_back <= 0:
        return times, sts, its, lts, fans, install_flags

    latest = max(times)
    cutoff = latest - timedelta(days=days_back)

    zipped = list(zip(times, sts, its, lts, fans, install_flags))
    trimmed = [
        (t, st, it, lt, f, inst)
        for (t, st, it, lt, f, inst) in zipped
        if t >= cutoff
    ]

    if not trimmed:
        # Nothing newer than cutoff; keep just the last point so chart isn't empty
        t_last = latest
        st_last = sts[-1]
        it_last = its[-1]
        lt_last = lts[-1]
        f_last = fans[-1]
        inst_last = install_flags[-1]
        return [t_last], [st_last], [it_last], [lt_last], [f_last], [inst_last]

    t2, st2, it2, lt2, f2, inst2 = zip(*trimmed)
    return list(t2), list(st2), list(it2), list(lt2), list(f2), list(inst2)



def make_chart(times, sts, its, lts, fans, install_flags, out_png):
    if not times:
        print("No structured data found in log; chart not generated.")
        return

    # Sort by time and keep LT aligned with the rest of the series.
    data = sorted(zip(times, sts, its, lts, fans, install_flags), key=lambda t: t[0])
    times, sts, its, lts, fans, install_flags = zip(*data)

    fig, ax1 = plt.subplots(figsize=(14, 5))

    # --- Radon lines (left Y axis) ---
    ax1.plot(
        times,
        sts,
        "o-",
        linewidth=2,
        markersize=6,
        color="red",
        label="Daily",
    )

    # Plot IT only where it actually exists and only after a true full IT window
    # has elapsed since install. This suppresses any legacy/pre-policy IT values
    # that may still be present in older log rows.
    install_dt_for_it = None
    try:
        install_dt_for_it, _valid_dt_unused, _dur_h_unused = _get_settling_info()
    except Exception:
        install_dt_for_it = None

    it_start_dt = None
    if install_dt_for_it is not None:
        it_start_dt = install_dt_for_it + timedelta(days=IT_WINDOW_DAYS)

    it_pairs = []
    for t, it in zip(times, its):
        if it is None:
            continue
        if it_start_dt is not None and t < it_start_dt:
            continue
        it_pairs.append((t, it))

    if it_pairs:
        it_times = [t for t, _it in it_pairs]
        it_vals = [_it for _t, _it in it_pairs]
        ax1.plot(
            it_times,
            it_vals,
            "s-",
            linewidth=2,
            markersize=6,
            color="orange",
            label="7-Day Avg",
        )

    ax1.set_ylabel("Radon (pCi/L)", color="maroon")
    ax1.tick_params(axis="y", labelcolor="maroon")

    # Threshold lines
    ax1.axhline(
        RADON_ON_THRESHOLD,
        color="green",
        linestyle="--",
        linewidth=1,
        label=f"ON Threshold {RADON_ON_THRESHOLD}"
    )
    ax1.axhline(
        RADON_OFF_THRESHOLD,
        color="purple",
        linestyle="--",
        linewidth=1,
        label=f"OFF Threshold {RADON_OFF_THRESHOLD}"
    )

    # --- Fan state (right Y axis) ---
    ax2 = ax1.twinx()
    ax2.step(
        times,
        fans,
        where="post",
        linewidth=2,
        color="blue",
        label="Fan State",
    )

    ax2.set_ylim(-0.1, 1.1)
    ax2.set_ylabel("Fan State", color="blue")
    ax2.tick_params(axis="y", labelcolor="blue")
    ax2.set_yticks([])  # no numeric ticks; we use big ON/OFF labels instead

    # Big ON / OFF labels on the right edge (like chumbajr)
    ax2.text(
        1.02,
        1.0,
        "ON",
        color="blue",
        transform=ax2.transAxes,
        va="center",
        ha="left",
    )
    ax2.text(
        1.02,
        0.0,
        "OFF",
        color="blue",
        transform=ax2.transAxes,
        va="center",
        ha="left",
    )

    # --- X-axis formatting (chumbajr-style auto scale) ---
    ax1.set_xlabel("Time")
    ax1.set_title("Radon Mitigation Automation")

    # Settling info label (only while still settling)
    try:
        install_dt, valid_dt, dur_h = _get_settling_info()
        if install_dt is not None and valid_dt is not None:
            latest_t = times[-1]
            if latest_t < valid_dt:
                msg = f"Settling: readings valid after {valid_dt.strftime('%Y-%m-%d %H:%M')}"
                if dur_h is not None:
                    msg += f" (~{dur_h:.0f}h after install)"
                # Draw on ax2 (twin axis) so it stays above the fan line
                ax2.text(
                    0.5,
                    0.92,
                    msg,
                    transform=ax2.transAxes,
                    ha='center',
                    va='center',
                    fontsize=10,
                    zorder=50,
                    bbox=dict(boxstyle='round', facecolor='white', edgecolor='black', alpha=1.0),
                )
    except Exception:
        pass

    locator = mdates.AutoDateLocator()
    formatter = mdates.ConciseDateFormatter(locator)
    ax1.xaxis.set_major_locator(locator)
    ax1.xaxis.set_major_formatter(formatter)
    fig.autofmt_xdate()

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()

    ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper left")

    # --- Installation-day callout ---
    try:
        install_banner_hours = float(os.getenv("INSTALL_BANNER_HOURS", "24"))
    except Exception:
        install_banner_hours = 24.0

    show_install_banner = False
    try:
        install_dt, _valid_dt, _dur_h = _get_settling_info()
    except Exception:
        install_dt = None

    if install_dt is not None:
        latest_t = times[-1]
        show_install_banner = latest_t < (install_dt + timedelta(hours=install_banner_hours))

    if show_install_banner:
        ax1.text(
            0.5,
            0.5,
            "INSTALLATION DAY\nFan forced ON",
            transform=ax1.transAxes,
            ha="center",
            va="center",
            fontsize=14,
            bbox=dict(
                boxstyle="round",
                facecolor="white",
                edgecolor="black",
                alpha=0.85,
            ),
        )
    fig.tight_layout()
    out_dir = os.path.dirname(os.path.abspath(out_png))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
    print(f"Chart written to {out_png}")



def main():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--log", default=LOG_FILE_DEFAULT, help="Path to radon log file")
    parser.add_argument("--output", default=OUT_PNG, help="Output chart PNG path")
    parser.add_argument("--days-back", type=int, default=None, help="Trim to the most recent N days before plotting")
    args = parser.parse_args()

    times, sts, its, lts, fans, install_flags = parse_log(args.log)
    times, sts, its, lts, fans, install_flags = trim_by_days(
        times, sts, its, lts, fans, install_flags, args.days_back
    )

    make_chart(times, sts, its, lts, fans, install_flags, args.output)


if __name__ == "__main__":
    main()
