#!/usr/bin/env python3
"""
Boris generate-radon-chart.py

Log format (CSV lines written by radon-automation.py):
    timestamp_iso,short_pci,long_pci,fan_state,install_flag,reason
"""

import os
import sys
import csv
from datetime import datetime, timedelta

import matplotlib.pyplot as plt
import matplotlib.dates as mdates

# Defaults
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE_DEFAULT = os.path.join(SCRIPT_DIR, "radon-log.txt")
OUT_PNG = os.path.join(SCRIPT_DIR, "radon-chart.png")

# Thresholds (must match radon-automation.py)
RADON_ON_THRESHOLD = float(os.getenv("RADON_ON_THRESHOLD", "2.0"))
RADON_OFF_THRESHOLD = float(os.getenv("RADON_OFF_THRESHOLD", "1.5"))


def parse_log(path):
    """
    Parse structured CSV lines from radon-log.txt.

    We only accept rows with 6 fields:
        timestamp_iso, short, long, fan, install_flag, reason
    and skip all other log lines.
    """
    times = []
    shorts = []
    longs = []
    fans = []
    install_flags = []

    try:
        with open(path, "r", encoding="utf-8") as f:
            reader = csv.reader(f)
            for row in reader:
                if len(row) != 6:
                    # Skip non-CSV or legacy log lines
                    continue

                ts_str, short_str, long_str, fan_str, install_str, reason = row

                try:
                    ts = datetime.fromisoformat(ts_str)
                    short_val = float(short_str)
                    long_val = float(long_str)
                    fan_val = int(fan_str)
                    install_val = int(install_str)
                except Exception:
                    # Malformed CSV row; skip
                    continue

                times.append(ts)
                shorts.append(short_val)
                longs.append(long_val)
                fans.append(fan_val)
                install_flags.append(install_val)

    except FileNotFoundError:
        print(f"Log file not found: {path}")
        return [], [], [], [], []

    return times, shorts, longs, fans, install_flags


def trim_by_days(times, shorts, longs, fans, install_flags, days_back):
    """
    Keep only points within the last `days_back` days from the most recent timestamp.
    If days_back is None or <= 0, return the data unchanged.
    """
    if not times or days_back is None or days_back <= 0:
        return times, shorts, longs, fans, install_flags

    latest = max(times)
    cutoff = latest - timedelta(days=days_back)

    zipped = list(zip(times, shorts, longs, fans, install_flags))
    trimmed = [(t, s, l, f, inst) for (t, s, l, f, inst) in zipped if t >= cutoff]

    if not trimmed:
        # Nothing newer than cutoff; keep just the last point so chart isn't empty
        t_last = latest
        s_last = shorts[-1]
        l_last = longs[-1]
        f_last = fans[-1]
        inst_last = install_flags[-1]
        return [t_last], [s_last], [l_last], [f_last], [inst_last]

    t2, s2, l2, f2, inst2 = zip(*trimmed)
    return list(t2), list(s2), list(l2), list(f2), list(inst2)


def make_chart(times, shorts, longs, fans, install_flags, out_png):
    if not times:
        print("No structured data found in log; chart not generated.")
        return

    # Sort by time
    data = sorted(zip(times, shorts, longs, fans, install_flags), key=lambda t: t[0])
    times, shorts, longs, fans, install_flags = zip(*data)

    fig, ax1 = plt.subplots(figsize=(14, 5))

    # --- Radon lines (left Y axis) ---
    ax1.plot(
        times,
        shorts,
        "o-",
        linewidth=2,
        markersize=6,
        color="red",
        label="Short-Term",
    )
    ax1.plot(
        times,
        longs,
        "s-",
        linewidth=2,
        markersize=6,
        color="orange",
        label="Long-Term",
    )

    ax1.set_ylabel("Radon (pCi/L)", color="maroon")
    ax1.tick_params(axis="y", labelcolor="maroon")

    # Threshold lines
    ax1.axhline(
        RADON_ON_THRESHOLD,
        color="green",
        linestyle="--",
        linewidth=1,
        label=f"ON Threshold {RADON_ON_THRESHOLD}"
    )
    ax1.axhline(
        RADON_OFF_THRESHOLD,
        color="purple",
        linestyle="--",
        linewidth=1,
        label=f"OFF Threshold {RADON_OFF_THRESHOLD}"
    )

    # --- Fan state (right Y axis) ---
    ax2 = ax1.twinx()
    ax2.step(
        times,
        fans,
        where="post",
        linewidth=2,
        color="blue",
        label="Fan State",
    )

    ax2.set_ylim(-0.1, 1.1)
    ax2.set_ylabel("Fan State", color="blue")
    ax2.tick_params(axis="y", labelcolor="blue")
    ax2.set_yticks([])  # no numeric ticks; we use big ON/OFF labels instead

    # Big ON / OFF labels on the right edge (like chumbajr)
    ax2.text(
        1.02,
        1.0,
        "ON",
        color="blue",
        transform=ax2.transAxes,
        va="center",
        ha="left",
    )
    ax2.text(
        1.02,
        0.0,
        "OFF",
        color="blue",
        transform=ax2.transAxes,
        va="center",
        ha="left",
    )

    # --- X-axis formatting (chumbajr-style auto scale) ---
    ax1.set_xlabel("Time")
    ax1.set_title("Radon Mitigation Automation")

    locator = mdates.AutoDateLocator()
    formatter = mdates.ConciseDateFormatter(locator)
    ax1.xaxis.set_major_locator(locator)
    ax1.xaxis.set_major_formatter(formatter)
    fig.autofmt_xdate()

    # --- Legend ---
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper left")

    # --- Installation-day callout ---
    # If the most recent point has install_flag == 1, show a central box.
    if install_flags and install_flags[-1] == 1:
        ax1.text(
            0.5,
            0.5,
            "INSTALLATION DAY\nFan forced ON initially",
            transform=ax1.transAxes,
            ha="center",
            va="center",
            fontsize=14,
            bbox=dict(
                boxstyle="round",
                facecolor="white",
                edgecolor="black",
                alpha=0.85,
            ),
        )

    fig.tight_layout()
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
    print(f"Chart written to {out_png}")


def main():
    # Defaults
    log_file = LOG_FILE_DEFAULT
    days_back = None  # None = use full history

    # CLI: python3 generate-radon-chart.py [logfile] [days_back]
    if len(sys.argv) >= 2:
        log_file = sys.argv[1]
    if len(sys.argv) >= 3:
        try:
            days_back = int(sys.argv[2])
        except ValueError:
            days_back = None

    times, shorts, longs, fans, install_flags = parse_log(log_file)
    times, shorts, longs, fans, install_flags = trim_by_days(
        times, shorts, longs, fans, install_flags, days_back
    )

    make_chart(times, shorts, longs, fans, install_flags, OUT_PNG)


if __name__ == "__main__":
    main()
