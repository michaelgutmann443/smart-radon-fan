#!/usr/bin/env python3
"""
radon-automation.py

Reads Airthings radon via BLE (Bleak), controls a Shelly switch via HTTP RPC,
logs human-readable lines + a single structured CSV line per run.

Key design rule:
- Do NOT write directly to radon-log.txt from inside this script.
  run-radon.sh captu
# Best-effort battery life (OK/LOW). Not required for operation.
b_pct = await try_read_battery_percent(client)
batt_obj = battery_life_obj(b_pct)
                    status_patch({
                        "airthings": {
                                    "battery": batt_obj,
                            "battery": batt_obj
                        }
                    })
res STDOUT/STDERR via tee into radon-log.txt.
"""

import os
import sys
import time
import json
import socket
import traceback
import subprocess
import asyncio
from dataclasses import dataclass
from datetime import datetime, date
from typing import Optional

import requests
from bleak import BleakClient, BleakScanner


# ---------------------------
# Status (Beta3)
# ---------------------------

STATUS_UPDATER = "/usr/local/bin/radon-status-update.py"

def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")



def _bytes_to_hex(b):
    try:
        if b is None:
            return None
        if isinstance(b, (bytes, bytearray)):
            return b.hex()
        if isinstance(b, list):
            return bytes(b).hex()
        return str(b)
    except Exception:
        return None

def status_patch(patch: dict) -> None:
    try:
        if os.path.exists(STATUS_UPDATER):
            subprocess.run([STATUS_UPDATER, json.dumps(patch)], timeout=5)
    except Exception:
        pass


# ---------------------------
# Paths / config
# ---------------------------

INSTALL_DATE_PATH = "/etc/radonbox/install-date.txt"

# These are expected to be exported by run-radon.sh after sourcing /etc/radonbox/radon-config.conf
SHELLY_HOST = os.getenv("SHELLY_HOST", "").strip().rstrip("/")
SHELLY_SWITCH_ID = os.getenv("SHELLY_SWITCH_ID", "").strip()
AIR_MAC = os.getenv("AIR_MAC", "").strip()

# Fail fast if we don't have required cached config
if not AIR_MAC:
    status_patch({
        "airthings": {"state": "ERROR", "level": "error", "mac": None},
        "summary": {"state": "ERROR", "level": "error", "text": "Missing AIR_MAC in config"}
    })
    raise RuntimeError(
        "Missing AIR_MAC. Expected /etc/radonbox/radon-config.conf to be populated "
        "and exported by run-radon.sh (or run radon-devices-init.sh on install)."
    )

if not SHELLY_HOST or not SHELLY_SWITCH_ID:
    status_patch({
        "shelly": {"state": "ERROR", "level": "error", "host": SHELLY_HOST or None},
        "summary": {"state": "ERROR", "level": "error", "text": "Missing Shelly config in radon-config.conf"}
    })
    raise RuntimeError(
        "Missing SHELLY_HOST or SHELLY_SWITCH_ID. Expected /etc/radonbox/radon-config.conf "
        "to be populated and exported by run-radon.sh (or run radon-devices-init.sh on install)."
    )

# If SHELLY_HOST doesn't start with scheme, assume http
if not (SHELLY_HOST.startswith("http://") or SHELLY_HOST.startswith("https://")):
    SHELLY_HOST = "http://" + SHELLY_HOST

# Thresholds
ON_THRESHOLD = float(os.getenv("RADON_ON_THRESHOLD", "2.0"))
OFF_THRESHOLD = float(os.getenv("RADON_OFF_THRESHOLD", "1.5"))

# Clamp obviously-bogus radon readings (keeps charts/logs sane)
RADON_CLAMP_MAX = float(os.getenv("RADON_CLAMP_MAX", "50.0"))

# BLE behavior
SCAN_SECONDS = float(os.getenv("AIR_SCAN_SECONDS", "20"))
CONNECT_TIMEOUT = float(os.getenv("AIR_CONNECT_TIMEOUT", "25"))
CYCLES = int(os.getenv("AIR_CYCLES", "3"))
ATTEMPTS_PER_CYCLE = int(os.getenv("AIR_ATTEMPTS_PER_CYCLE", "2"))

# Retry cadence (status page)
RETRY_SECONDS = int(os.getenv("AIR_RETRY_SECONDS", "30"))

DBG_TO_STDOUT = os.getenv("DBG_TO_STDOUT", "1").strip() not in ("0", "false", "False", "no", "NO")

# Airthings Wave radon characteristic UUID used by your current system
CHAR_UUID = "b42e4dcc-ade7-11e4-89d3-123b93f75cba"
# Standard BLE Battery Level characteristic (0–100). Not all Airthings models expose this;
# we treat it as best-effort and map it to Battery Life OK/LOW.
BATTERY_CHAR_UUID = "00002a19-0000-1000-8000-00805f9b34fb"


# ---------------------------
# Logging helpers
# ---------------------------

def dbg_write(msg: str) -> None:
    """One place to write human-readable log lines."""
    if not DBG_TO_STDOUT:
        return
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
    sys.stdout.write(f"{ts}: {msg}\n")
    sys.stdout.flush()


def log_exception(prefix: str, e: Exception) -> None:
    dbg_write(f"{prefix}: [{type(e).__name__}] {e}")
    tb = traceback.format_exc().strip()
    if tb:
        dbg_write(f"Trace: {tb.splitlines()[-1]}")


# ---------------------------
# Utilities
# ---------------------------

def is_installation_day() -> bool:
    """True if INSTALL_DATE_PATH exists and matches today's date."""
    try:
        with open(INSTALL_DATE_PATH, "r", encoding="utf-8") as f:
            s = f.read().strip()
        if not s:
            return False
        return s == date.today().isoformat()
    except Exception:
        return False


def shelly_rpc(path: str, payload: Optional[dict] = None, timeout: float = 2.0) -> dict:
    url = f"{SHELLY_HOST}{path}"
    if payload is None:
        r = requests.get(url, timeout=timeout)
    else:
        r = requests.post(url, json=payload, timeout=timeout)
    r.raise_for_status()
    return r.json()


def shelly_get_state() -> bool:
    try:
        j = shelly_rpc(f"/rpc/Switch.GetStatus?id={SHELLY_SWITCH_ID}")
        status_patch({
            "shelly": {
                "state": "VALIDATED", "level": "ok",
                "host": SHELLY_HOST, "switch_id": int(SHELLY_SWITCH_ID),
                "last_ok_local": _now_iso(), "last_error": None
            }
        })
        return bool(j.get("output", False))
    except Exception as e:
        log_exception("Shelly.GetStatus failed", e)
        status_patch({
            "shelly": {
                "state": "ERROR", "level": "warn",
                "host": SHELLY_HOST, "switch_id": int(SHELLY_SWITCH_ID or 0),
                "last_error": f"{type(e).__name__}: {e}"
            }
        })
        # Conservative fallback: treat as OFF
        return False


def shelly_set_state(on: bool) -> None:
    try:
        _ = shelly_rpc("/rpc/Switch.Set", {"id": int(SHELLY_SWITCH_ID), "on": bool(on)})
        dbg_write(f"Shelly set -> {'ON' if on else 'OFF'} @ {SHELLY_HOST}")
        status_patch({
            "shelly": {
                "state": "VALIDATED", "level": "ok",
                "host": SHELLY_HOST, "switch_id": int(SHELLY_SWITCH_ID),
                "last_ok_local": _now_iso(), "last_error": None
            }
        })
    except Exception as e:
        log_exception("Shelly.Set failed", e)
        status_patch({
            "shelly": {
                "state": "ERROR", "level": "warn",
                "host": SHELLY_HOST, "switch_id": int(SHELLY_SWITCH_ID or 0),
                "last_error": f"{type(e).__name__}: {e}"
            }
        })


@dataclass
class RadonReading:
    short_pci: float
    long_pci: float


def parse_wave_payload(data: bytes) -> Optional[RadonReading]:
    try:
        if not data or len(data) < 6:
            return None
        short_raw = int.from_bytes(data[2:4], byteorder="little", signed=False)
        long_raw = int.from_bytes(data[4:6], byteorder="little", signed=False)
        short_pci = round(short_raw / 10.0, 2)
        long_pci = round(long_raw / 10.0, 2)
        return RadonReading(short_pci=short_pci, long_pci=long_pci)
    except Exception:
        return None



async def try_read_battery_percent(client):
    """Best-effort read of standard BLE battery level (0..100). Returns int or None."""
    try:
        raw = await client.read_gatt_char(BATTERY_CHAR_UUID)
        if not raw:
            return None
        pct = int(raw[0])
        if 0 <= pct <= 100:
            return pct
        return None
    except Exception:
        return None

def battery_life_obj(pct):
    """Map pct to a simple OK/LOW/UNKNOWN object for the portal."""
    if pct is None:
        return {"state": "UNKNOWN", "level": "info", "text": "Battery Life UNKNOWN"}
    if pct <= 15:
        return {"state": "LOW", "level": "warn", "text": "Battery Life LOW", "percent": pct}
    return {"state": "OK", "level": "ok", "text": "Battery Life OK", "percent": pct}


def vendor_battery_obj_from_payload(raw: Optional[bytes]) -> dict:
    """
    Airthings Wave-series devices often do NOT expose the standard BLE Battery Level (0x2A19).
    We do not yet have a validated mapping from the vendor payload bits to battery state
    (fresh batteries still reported "LOW" under the prior heuristic).

    To avoid false warnings, report UNKNOWN until a reliable mapping is proven.
    """
    return {"state": "UNKNOWN", "level": "info", "text": "Battery Life UNKNOWN"}

async def read_radon_gatt(mac: str) -> RadonReading:
    """
    Connect to the Airthings MAC and read/validate radon values, with retries.
    Writes status updates for installer status page.
    """
    last_good: Optional[RadonReading] = None

    attempt_counter = 0
    attempt_max = CYCLES * ATTEMPTS_PER_CYCLE


    batt_obj = {"state": "UNKNOWN", "level": "info", "text": "Battery Life UNKNOWN"}
    # installer-friendly baseline
    status_patch({
        "airthings": {
            "state": "WAITING_FOR_READ",
            "level": "warn",
            "mac": mac,
                             "battery": batt_obj,
            "read": {
                "attempt": 0,
                "attempt_max": attempt_max,
                "retry_seconds": RETRY_SECONDS,
                "last_attempt_local": None,
                "next_retry_local": None,
                "last_ok_local": None,
                "last_error": None
            },
            "tip": "Battery radon sensors often sleep. Pick up the meter or wave your hand near it to wake it. RadonBox will keep retrying automatically."
        },
        "summary": {
            "state": "READY_WAITING_FOR_FIRST_READ",
            "level": "warn",
            "text": "Installation complete — waiting for first radon reading"
        }
    })

    for cycle in range(1, CYCLES + 1):
        dbg_write(f"[cycle {cycle}/{CYCLES}] Scanning up to {SCAN_SECONDS:.0f}s for Airthings device {mac}...")
        try:
            found = False
            devices = await BleakScanner.discover(timeout=SCAN_SECONDS)
            dbg_write(f"[cycle {cycle}] Scan complete: saw {len(devices)} devices.")
            for d in devices:
                if (d.address or "").lower() == mac.lower():
                    found = True
                    rssi = getattr(d, "rssi", None)
                    name = getattr(d, "name", None)
                    dbg_write(f"[cycle {cycle}] Target device seen: {d.address} RSSI={rssi} Name={name}")
                    status_patch({
                        "airthings": {
                            "state": "FOUND",
                            "level": "ok",
                            "mac": mac,
                             "battery": batt_obj,
                            "name": name,
                            "rssi": rssi
                                                     ,"adv": {
                                 "manufacturer_data": {k: _bytes_to_hex(v) for k, v in (getattr(d, "metadata", {}) or {}).get("manufacturer_data", {}).items()},
                                 "service_data": {k: _bytes_to_hex(v) for k, v in (getattr(d, "metadata", {}) or {}).get("service_data", {}).items()}
                             }
                         }
                    })
                    break

            if not found:
                dbg_write(f"[cycle {cycle}] Target device not seen in scan; retrying next cycle.")
                status_patch({
                    "airthings": {
                        "state": "WAITING_FOR_READ",
                        "level": "warn",
                        "mac": mac,
                        "read": {"last_error": "Device not seen in BLE scan"}
                    }
                })
                continue
        except Exception as e:
            log_exception(f"[cycle {cycle}] Scan error", e)
            status_patch({
                "airthings": {
                    "state": "WAITING_FOR_READ",
                    "level": "warn",
                    "mac": mac,
                         "battery": batt_obj,
                    "read": {"last_error": f"Scan error: {type(e).__name__}: {e}"}
                }
            })
            continue

        for attempt in range(1, ATTEMPTS_PER_CYCLE + 1):
            attempt_counter += 1
            last_attempt = _now_iso()
            next_retry = (datetime.now().astimezone() + __import__("datetime").timedelta(seconds=RETRY_SECONDS)).isoformat(timespec="seconds")

            status_patch({
                "airthings": {
                    "state": "WAITING_FOR_READ",
                    "level": "warn",
                    "mac": mac,
                         "battery": batt_obj,
                    "read": {
                        "attempt": attempt_counter,
                        "attempt_max": attempt_max,
                        "last_attempt_local": last_attempt,
                        "next_retry_local": next_retry,
                        "retry_seconds": RETRY_SECONDS
                    }
                }
            })

            try:
                wait_s = 4.0 + (cycle * 0.4) + (attempt * 0.4)
                dbg_write(f"[cycle {cycle}] Attempt {attempt}/{ATTEMPTS_PER_CYCLE}: wait {wait_s:.1f}s before connect...")
                time.sleep(wait_s)
                dbg_write(f"[cycle {cycle}] Connecting with timeout={CONNECT_TIMEOUT:.1f}s ...")
                client = BleakClient(mac, timeout=CONNECT_TIMEOUT)
                try:
                    await client.connect()
                    dbg_write("[connect] Connected. Reading radon GATT...")

                    # Service discovery can help on flaky connections; ignore failures here.
                    try:
                        await client.get_services()
                    except Exception:
                        pass

                    for vtry in range(1, 4):
                        raw = await client.read_gatt_char(CHAR_UUID)
                        batt_obj = vendor_battery_obj_from_payload(raw)
                        # Diagnostics: capture the raw vendor payload (hex) to enable
                        # Airthings-specific battery decoding (device does not expose 0x2A19).
                        try:
                            status_patch({
                                "airthings": {
                                    "vendor_payload_len": len(raw) if raw is not None else None,
                                    "vendor_payload_hex": raw.hex() if isinstance(raw, (bytes, bytearray)) else None
                                }
                            })
                        except Exception:
                            pass

                        reading = parse_wave_payload(raw)
                        if reading is None:
                            dbg_write(f"[validation] Try {vtry}: could not parse payload; retrying read...")
                            time.sleep(0.3)
                            continue

                        short_pci = reading.short_pci
                        long_pci = reading.long_pci

                        if short_pci < 0:
                            short_pci = 0.0
                        if long_pci < 0:
                            long_pci = 0.0

                        if short_pci > RADON_CLAMP_MAX:
                            dbg_write(f"[validation] Clamping short from {short_pci} -> {RADON_CLAMP_MAX}")
                            short_pci = RADON_CLAMP_MAX
                        if long_pci > RADON_CLAMP_MAX:
                            dbg_write(f"[validation] Clamping long from {long_pci} -> {RADON_CLAMP_MAX}")
                            long_pci = RADON_CLAMP_MAX

                        dbg_write(f"[validation] OK (clamped if needed): short={short_pci} pCi/L, long={long_pci} pCi/L")
                        last_good = RadonReading(short_pci=short_pci, long_pci=long_pci)

                        status_patch({
                            "airthings": {
                                "state": "READ_OK",
                                "level": "ok",
                                "mac": mac,
                                "battery": batt_obj,
                                "read": {"last_ok_local": _now_iso(), "last_error": None}
                            }
                        })

                        return last_good
                finally:
                    # Always tear down BLE state; EOFError can leave a half-open connection.
                    try:
                        await client.disconnect()
                    except Exception:
                        pass

            except EOFError:
                if last_good is not None:
                    dbg_write(f"[cycle {cycle}] EOFError after successful validation; ignoring and returning last_good.")
                    status_patch({
                        "airthings": {
                            "state": "READ_OK",
                            "level": "ok",
                            "mac": mac,
                            "read": {"last_ok_local": _now_iso(), "last_error": None}
                        }
                    })
                    return last_good

                dbg_write(f"[cycle {cycle}] EOFError before validation; retrying...")
                status_patch({
                    "airthings": {
                        "state": "WAITING_FOR_READ",
                        "level": "warn",
                        "mac": mac,
                        "read": {"last_error": "EOFError during GATT read"}
                    }
                })
                time.sleep(float(RETRY_SECONDS))
            except Exception as e:
                log_exception(f"[cycle {cycle}] Connect/read error (attempt {attempt})", e)
                status_patch({
                    "airthings": {
                        "state": "WAITING_FOR_READ",
                        "level": "warn",
                        "mac": mac,
                         "battery": batt_obj,
                        "read": {"last_error": f"{type(e).__name__}: {e}"}
                    }
                })
                dbg_write(f"[cycle {cycle}] Waiting 12.0s before next attempt...")
                time.sleep(12.0)

    raise RuntimeError("Failed to read radon from Airthings after retries.")


# ---------------------------
# Main
# ---------------------------

async def main() -> int:
    dbg_write("Starting radon automation...")
    dbg_write("")
    dbg_write("=== Radon run start ===")
    dbg_write(
        f"Env: Python {sys.version.split()[0]}, "
        f"Bleak {getattr(__import__('bleak'), '__version__', 'unknown')}, "
        f"Platform {os.uname().sysname} {os.uname().release} ({os.uname().machine})"
    )

    # Read radon
    reading = await read_radon_gatt(AIR_MAC)
    short_pci = reading.short_pci
    long_pci = reading.long_pci

    dbg_write(f"Airthings short-term radon: {short_pci:.2f} pCi/L")
    dbg_write(f"Airthings long-term radon: {long_pci:.2f} pCi/L")
    dbg_write(f"Airthings reading (for chart): short={short_pci} pCi/L, long={long_pci} pCi/L")

    status_patch({
        "summary": {"state": "OPERATIONAL", "level": "ok", "text": "System operational"}
    })

    # Read Shelly state
    current_state = shelly_get_state()
    dbg_write(f"Current Shelly state: {current_state}")

    installation_flag = 0
    desired_state = current_state
    fan_reason = "HOLD_STATE"

    if is_installation_day():
        installation_flag = 1
        desired_state = True
        fan_reason = "INSTALLATION_DAY_FORCE_ON"
        dbg_write(
            f"Installation day: forcing fan ON regardless of short={short_pci}, long={long_pci}."
        )
    else:
        if short_pci >= ON_THRESHOLD or long_pci >= ON_THRESHOLD:
            desired_state = True
            fan_reason = "ON_THRESHOLD"
            dbg_write(
                f"ON rule met (short={short_pci} >= {ON_THRESHOLD} OR long={long_pci} >= {ON_THRESHOLD}); turning ON."
            )
        elif short_pci < OFF_THRESHOLD and long_pci < OFF_THRESHOLD:
            desired_state = False
            fan_reason = "OFF_THRESHOLD"
            dbg_write(
                f"OFF rule met (short={short_pci} < {OFF_THRESHOLD} AND long={long_pci} < {OFF_THRESHOLD}); turning OFF."
            )
        else:
            desired_state = current_state
            fan_reason = "HOLD_STATE"
            dbg_write(
                f"Hysteresis band: short={short_pci}, long={long_pci}, between OFF<{OFF_THRESHOLD} and ON≥{ON_THRESHOLD}; Shelly unchanged."
            )

    # Always (re)assert the desired Shelly state when we have made an explicit ON/OFF decision.
    # This is idempotent for Shelly and helps recover from stale/misreported state reads.
    if fan_reason != "HOLD_STATE":
        if desired_state == current_state:
            dbg_write(f"Desired Shelly state already {desired_state}; sending command anyway to ensure state.")
        shelly_set_state(desired_state)

    fan_state = 1 if desired_state else 0
    timestamp = datetime.now().isoformat(timespec="milliseconds")

    try:
        sys.stdout.write(f"{timestamp},{short_pci},{long_pci},{fan_state},{installation_flag},{fan_reason}\n")
        sys.stdout.flush()
    except Exception as e:
        log_exception("Structured log write failed", e)

    dbg_write("Radon automation complete.")
    return 0


if __name__ == "__main__":
    import asyncio
    try:
        raise SystemExit(asyncio.run(main()))
    except KeyboardInterrupt:
        raise