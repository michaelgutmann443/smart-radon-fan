#!/usr/bin/env bash
set -e
echo "[onboard-check] wlan0 state:"
ip -br addr show wlan0
echo
echo "[onboard-check] active connections:"
nmcli -t -f NAME,DEVICE,STATE connection show --active
echo
if [[ -f /etc/radonbox/boot-mode ]]; then
  echo "[onboard-check] boot-mode flag:"
  cat /etc/radonbox/boot-mode
else
  echo "[onboard-check] no boot-mode flag found."
fi
