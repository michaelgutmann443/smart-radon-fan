#!/usr/bin/env bash
set -euo pipefail

echo "[radon-reset] Starting baseline reset for Smart Radon Fan"

# Resolve current active release
CURRENT_ROOT="$(readlink -f /opt/radonbox/current)"
RADON_MIN="$CURRENT_ROOT/radon-min"
RB_FLAG="$RADON_MIN/rb-flag.sh"

if [ ! -x "$RB_FLAG" ]; then
  echo "[radon-reset] ERROR: rb-flag.sh not found or not executable at $RB_FLAG" >&2
  exit 1
fi

# 1) Force AP mode for next boot
echo "[radon-reset] Setting boot mode to AP"
sudo "$RB_FLAG" ap

# 2) Remove runtime artifacts (logs, charts, discovery logs)
echo "[radon-reset] Removing runtime artifacts"
sudo rm -f \
  "$RADON_MIN/radon-log.txt" \
  "$RADON_MIN/radon-chart.png" \
  "$RADON_MIN/radon-devices-init.log" \
  "$RADON_MIN/radon-status.json" || true

# 3) Reset device configuration (but keep defaults)
echo "[radon-reset] Clearing /etc/radonbox/radon-config.conf"
sudo tee /etc/radonbox/radon-config.conf >/dev/null <<'EOF'
# RadonBox device config
# Filled by radon-devices-init.sh after install/factory-reset
SHELLY_HOST=
AIR_MAC=
SHELLY_SWITCH_ID=
RADON_ON_THRESHOLD=2.0
RADON_OFF_THRESHOLD=1.5
RADON_EXECUTION_FREQUENCY=1
EVENING_FAN_OFF=
EOF

sudo chmod 0644 /etc/radonbox/radon-config.conf

# 4) Sync filesystem
sync
#sudo reboot


echo "[reset] Ready for a radonbox reboot..."

