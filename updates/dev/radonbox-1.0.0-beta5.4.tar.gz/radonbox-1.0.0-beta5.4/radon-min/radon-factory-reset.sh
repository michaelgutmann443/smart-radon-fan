#!/usr/bin/env bash
set -euo pipefail

echo "[factory-reset] Starting factory reset..."

# 1) Use existing helper to set boot mode to AP for next boot
if [ -x /home/boris/radon-min/rb-flag.sh ]; then
    /home/boris/radon-min/rb-flag.sh ap
    echo "[factory-reset] Set boot-mode to ap via rb-flag.sh"
else
    echo "[factory-reset] ERROR: /home/boris/radon-min/rb-flag.sh not found or not executable" >&2
fi

# 2) Clear Wi-Fi credentials (tune to your stack as needed)

# NetworkManager connections (if present)
if [ -d /etc/NetworkManager/system-connections ]; then
    rm -f /etc/NetworkManager/system-connections/*.nmconnection || true
    echo "[factory-reset] Cleared NetworkManager connections"
fi

# Legacy wpa_supplicant config (if present)
if [ -f /etc/wpa_supplicant/wpa_supplicant.conf ]; then
    rm -f /etc/wpa_supplicant/wpa_supplicant.conf || true
    echo "[factory-reset] Cleared wpa_supplicant.conf"
fi

# 3) Reset radon-config.conf to defaults (do NOT delete it)
sudo mkdir -p /etc/radonbox
sudo tee /etc/radonbox/radon-config.conf >/dev/null <<'EOF'
# RadonBox device config
# Filled by radon-devices-init.sh after install/factory-reset
SHELLY_HOST=
AIR_MAC=
SHELLY_SWITCH_ID=
RADON_ON_THRESHOLD=2.0
RADON_OFF_THRESHOLD=1.5
RADON_EXECUTION_FREQUENCY=1
EVENING_FAN_OFF=
EOF
sudo chown root:root /etc/radonbox/radon-config.conf
sudo chmod 0644 /etc/radonbox/radon-config.conf
echo "[factory-reset] Reset /etc/radonbox/radon-config.conf with defaults"

# 4) Clear first-day flag so installation-day behavior works again
if [ -f /home/boris/radonbox-first-day.flag ]; then
    rm -f /home/boris/radonbox-first-day.flag || true
    echo "[factory-reset] Cleared /home/boris/radonbox-first-day.flag"
fi

# 5) (Optional) Clear chart/log for a visually fresh unit on reinstall.
# Uncomment if you want that:
# if [ -d /home/boris/radon-min ]; then
#     rm -f /home/boris/radon-min/radon-log.txt /home/boris/radon-min/radon-chart.png || true
#     echo "[factory-reset] Cleared radon-log.txt and radon-chart.png"
# fi

echo "[factory-reset] Factory reset completed. Rebooting..."
sleep 1

/sbin/shutdown -r now
