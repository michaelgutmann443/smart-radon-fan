#!/usr/bin/env python3
"""
read-airthings.py  (advertisement-only version)

- Listens for BLE advertisements from a specific Airthings device (AIR_MAC).
- Uses manufacturer data key 0x0334 (Airthings company ID).
- Decodes short-term and long-term radon from the adv payload.
- Outputs ONLY the short-term radon in pCi/L to stdout (for run-radon.sh).
- Prints a brief debug line with both ST/LT to stderr.

Env / config:
  - AIR_MAC             : optional, overrides config
  - RADON_ADV_TIMEOUT   : optional, seconds to listen (default 20)
  - /etc/radonbox/radon-config.conf with line: AIR_MAC=XX:XX:...

Exit codes:
  0 = success, printed numeric pCi/L to stdout
  1 = no data / timeout
  2 = configuration or dependency error
"""

import sys
import os
import asyncio

try:
    from bleak import BleakScanner
except Exception as e:
    print(f"ERR:no_bleak:{e}", file=sys.stderr)
    sys.exit(2)

CFG_PATH = "/etc/radonbox/radon-config.conf"
AIRTHINGS_COMPANY_ID = 0x0334
DEFAULT_TIMEOUT = float(os.environ.get("RADON_ADV_TIMEOUT", "20.0"))


def load_air_mac() -> str | None:
    """Return AIR_MAC (uppercased) from env or config file, or None."""
    mac = os.environ.get("AIR_MAC", "").strip()
    if mac:
        return mac.upper()

    try:
        with open(CFG_PATH, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("AIR_MAC="):
                    val = line.split("=", 1)[1].strip()
                    if val:
                        return val.upper()
    except FileNotFoundError:
        pass

    return None


def decode_radon_from_adv(payload: bytes) -> tuple[float, float]:
    """
    Decode Airthings short-term and long-term radon from a 0x0334 payload.

    Based on observed frames like:
      73 64 d7 af 21 00

    We treat:
      payload[4] -> short-term radon, in Bq/m³
      payload[5] -> long-term radon, in Bq/m³
    and convert to pCi/L by dividing by 37.0.

    Returns (short_pci, long_pci) as floats.
    """
    if len(payload) < 6:
        raise ValueError(f"Payload too short for radon decode: {payload!r}")

    short_bq = payload[4]
    long_bq = payload[5]

    short_pci = round(short_bq / 37.0, 2)
    long_pci = round(long_bq / 37.0, 2)
    return short_pci, long_pci


async def read_once(air_mac: str, timeout: float) -> tuple[float, float] | None:
    """
    Listen for Airthings advertisements for up to `timeout` seconds.

    Returns (short_pci, long_pci) on success, or None on timeout.
    """
    air_mac = air_mac.upper()
    found: dict[str, bytes] = {}

    def detection_callback(device, advertisement_data):
        # Ignore everything except our target MAC
        if device.address.upper() != air_mac:
            return

        md = getattr(advertisement_data, "manufacturer_data", None) or {}
        payload = md.get(AIRTHINGS_COMPANY_ID)
        if not payload:
            return

        # Save the latest payload; main loop will stop after timeout
        found["payload"] = bytes(payload)

    scanner = BleakScanner(detection_callback)

    await scanner.start()
    try:
        await asyncio.sleep(timeout)
    finally:
        await scanner.stop()

    payload = found.get("payload")
    if not payload:
        return None

    try:
        return decode_radon_from_adv(payload)
    except Exception as e:
        print(f"ERR:decode:{e}", file=sys.stderr)
        return None


async def main_async() -> int:
    air_mac = load_air_mac()
    if not air_mac:
        print("ERR:no_air_mac: AIR_MAC not set in env or config", file=sys.stderr)
        return 2

    short_long = await read_once(air_mac, DEFAULT_TIMEOUT)
    if short_long is None:
        print("ERR:no_adv: no Airthings advertisement with radon data", file=sys.stderr)
        return 1

    short_pci, long_pci = short_long

    # Debug info to stderr; safe for automation
    print(
        f"INFO:Airthings {air_mac}: short={short_pci} pCi/L, long={long_pci} pCi/L",
        file=sys.stderr,
    )

    # IMPORTANT: stdout prints ONLY the short-term radon (for run-radon.sh)
    print(f"{short_pci}")
    return 0


def main() -> None:
    try:
        rc = asyncio.run(main_async())
    except KeyboardInterrupt:
        rc = 130
    except Exception as e:
        print(f"ERR:unhandled:{e}", file=sys.stderr)
        rc = 1
    sys.exit(rc)


if __name__ == "__main__":
    main()
