#!/usr/bin/env python3
"""discover-airthings-mac.py — discover an Airthings radon meter BLE MAC (Boris Beta)

Design goals
- **STDOUT is MAC only** (single line) on success, empty on failure.
- All logs go to **STDERR**.
- Be forgiving of transient BlueZ/Bleak flakiness: retries + backoff.
- Prefer a known MAC first (e.g. cached from a prior successful install).

Typical use (from radon-devices-init.sh):
  sudo -n python3 discover-airthings-mac.py --preferred-mac 7C:E2:69:82:AB:1F
"""

from __future__ import annotations

import argparse
import asyncio
import os
import re
import sys
import time
from dataclasses import dataclass
from typing import Iterable, Optional, Tuple

# Bleak is installed on the Pi images we’ve been using.
from bleak import BleakClient, BleakScanner  # type: ignore


MAC_RE = re.compile(r"^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$")


def eprint(*args: object) -> None:
    print(*args, file=sys.stderr, flush=True)


def norm_mac(s: str) -> str:
    return s.strip().upper()


def is_mac(s: str) -> bool:
    return bool(MAC_RE.match(s.strip()))


def env_float(name: str, default: float) -> float:
    v = os.getenv(name)
    if v is None or v.strip() == "":
        return default
    try:
        return float(v)
    except Exception:
        return default


def env_int(name: str, default: int) -> int:
    v = os.getenv(name)
    if v is None or v.strip() == "":
        return default
    try:
        return int(v)
    except Exception:
        return default


@dataclass
class Candidate:
    mac: str
    rssi: Optional[int] = None
    name: str = ""

    def score(self) -> int:
        # Higher RSSI (less negative) is better; unknown RSSI sorts last.
        return self.rssi if self.rssi is not None else -9999


def looks_like_airthings_name(name: str) -> bool:
    n = (name or "").lower()
    # Airthings often advertises as "Airthings Wave2" or as a MAC-like name.
    return ("airthings" in n) or ("wave" in n) or bool(re.fullmatch(r"([0-9a-f]{2}-){5}[0-9a-f]{2}", n))


def looks_like_non_target(name: str) -> bool:
    n = (name or "").lower()
    return ("shelly" in n) or ("plug" in n) or ("tile" in n)


async def scan_candidates(scan_s: float, top_n: int) -> list[Candidate]:
    devices = await BleakScanner.discover(timeout=scan_s)
    out: list[Candidate] = []
    for d in devices:
        mac = getattr(d, "address", "") or ""
        name = getattr(d, "name", "") or ""
        # bleak < 0.23 used BLEDevice.rssi; newer uses AdvertisementData.rssi.
        rssi = getattr(d, "rssi", None)
        if not mac:
            continue
        if not is_mac(mac):
            continue
        out.append(Candidate(mac=norm_mac(mac), rssi=rssi, name=name))

    # Sort: likely Airthings first, then by RSSI
    out.sort(key=lambda c: (0 if looks_like_airthings_name(c.name) and not looks_like_non_target(c.name) else 1, -c.score()))
    return out[:top_n]


async def validate_by_gatt(mac: str, connect_timeout: float, gatt_retries: int, retry_delay_s: float) -> bool:
    """A lightweight validation: connect + fetch services.

    We avoid reading specific characteristics here because those vary by model/firmware,
    and the goal is just to confirm "this is connectable and speaks GATT".
    """
    mac = norm_mac(mac)
    for attempt in range(1, gatt_retries + 1):
        try:
            async with BleakClient(mac, timeout=connect_timeout) as client:
                # get_services() is deprecated in newer bleak, but still present in our environment.
                # Prefer services property if present.
                try:
                    _ = client.services  # may trigger service discovery
                except Exception:
                    try:
                        await client.get_services()  # type: ignore[attr-defined]
                    except Exception:
                        pass
                # If we got here, we connected successfully.
                return True
        except Exception as e:
            eprint(f"[discover-airthings] GATT validate failed for {mac} attempt {attempt}/{gatt_retries}: {type(e).__name__}: {e}")
            if attempt < gatt_retries:
                await asyncio.sleep(retry_delay_s)
    return False


async def discover(preferred_mac: str | None, scan_s: float, top_n: int, tries: int,
                   connect_timeout: float, gatt_retries: int, retry_delay_s: float,
                   between_attempt_s: float) -> Optional[str]:
    # 0) If preferred provided, try it first.
    if preferred_mac and is_mac(preferred_mac):
        pm = norm_mac(preferred_mac)
        eprint(f"[discover-airthings] Preferred MAC provided: {pm} — validating...")
        if await validate_by_gatt(pm, connect_timeout, gatt_retries, retry_delay_s):
            return pm
        eprint(f"[discover-airthings] Preferred MAC did not validate (will fall back to scan).")

    # 1) Repeat scan + validate loop.
    for attempt in range(1, tries + 1):
        eprint(f"[discover-airthings] Scanning BLE for {scan_s:.1f}s (attempt {attempt}/{tries}) ...")
        cands = await scan_candidates(scan_s, top_n)
        if not cands:
            eprint("[discover-airthings] No BLE candidates seen.")
            if attempt < tries:
                await asyncio.sleep(between_attempt_s)
            continue

        eprint("[discover-airthings] Top candidates:")
        for c in cands:
            rssi_txt = f"{c.rssi:4d}" if c.rssi is not None else "None"
            eprint(f"  RSSI={rssi_txt}  {c.mac}  name='{c.name}'")

        # Try top candidates in order; validate each.
        for idx, c in enumerate(cands[:6], start=1):
            if looks_like_non_target(c.name):
                continue
            eprint(f"[discover-airthings] [{idx}/6] Trying {c.mac} (RSSI={c.rssi}, name='{c.name}') ...")
            if await validate_by_gatt(c.mac, connect_timeout, gatt_retries, retry_delay_s):
                return c.mac

        eprint("[discover-airthings] No candidates validated by GATT read.")
        if attempt < tries:
            await asyncio.sleep(between_attempt_s)

    return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--preferred-mac", default=os.getenv("RB_AIR_PREFERRED", "").strip() or None)
    ap.add_argument("--scan-s", type=float, default=env_float("RB_AIR_SCAN_S", 20.0))
    ap.add_argument("--top-n", type=int, default=env_int("RB_AIR_TOP_N", 10))
    ap.add_argument("--tries", type=int, default=env_int("RB_AIR_TRIES", 3))
    ap.add_argument("--connect-timeout", type=float, default=env_float("RB_AIR_CONNECT_TIMEOUT", 25.0))
    ap.add_argument("--gatt-retries", type=int, default=env_int("RB_AIR_GATT_RETRIES", 3))
    ap.add_argument("--retry-delay-s", type=float, default=env_float("RB_AIR_RETRY_DELAY_S", 2.0))
    ap.add_argument("--between-attempt-s", dest="between_attempt_s", type=float, default=env_float("RB_AIR_BETWEEN_ATTEMPTS", 5.0))
    args = ap.parse_args()

    try:
        mac = asyncio.run(
            discover(
                preferred_mac=args.preferred_mac,
                scan_s=args.scan_s,
                top_n=args.top_n,
                tries=args.tries,
                connect_timeout=args.connect_timeout,
                gatt_retries=args.gatt_retries,
                retry_delay_s=args.retry_delay_s,
                between_attempt_s=args.between_attempt_s,
            )
        )
    except KeyboardInterrupt:
        return 2

    if mac and is_mac(mac):
        # IMPORTANT: stdout is MAC only.
        print(norm_mac(mac), flush=True)
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
