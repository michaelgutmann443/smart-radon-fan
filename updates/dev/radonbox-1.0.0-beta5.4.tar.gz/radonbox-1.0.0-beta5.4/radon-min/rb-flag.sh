#!/usr/bin/env bash
# rb-flag.sh — Set/show RadonBox boot-mode flag (FLAG-ONLY).
# Usage: rb-flag.sh {ap|managed|show}
#
# Contract:
# - Writes /etc/radonbox/boot-mode as lowercase: "ap" or "managed"
# - Does NOT touch networking or services.
# - Mode changes take effect on next reboot via rb-mode-manager.sh (or equivalent).

set -euo pipefail

FLAG_FILE="/etc/radonbox/boot-mode"

SUDO=""
if [[ $EUID -ne 0 ]]; then
  SUDO="sudo"
fi

log() { printf "[rb-flag] %s\n" "$*"; }
usage() { echo "Usage: $(basename "$0") {ap|managed|show}"; }

ensure_dir() { $SUDO mkdir -p "$(dirname "$FLAG_FILE")"; }

write_flag() {
  local val="$1"
  ensure_dir
  echo "$val" | $SUDO tee "$FLAG_FILE" >/dev/null
}

show_flag() {
  cat "$FLAG_FILE" 2>/dev/null || echo "ap"
}

ARG="${1:-show}"
ARG_LC="$(echo "$ARG" | tr '[:upper:]' '[:lower:]')"

case "$ARG_LC" in
  ap)
    write_flag "ap"
    log "Set boot-mode to ap (takes effect on next reboot)"
    ;;
  managed)
    write_flag "managed"
    log "Set boot-mode to managed (takes effect on next reboot)"
    ;;
  show)
    show_flag
    ;;
  *)
    usage
    exit 1
    ;;
esac
