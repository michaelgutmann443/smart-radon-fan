#!/usr/bin/env bash
# radon-reset-and-reboot.sh
# Manual reset helper:
# 1) set boot-mode to AP
# 2) remove radon artifacts
# 3) blank radon-config.conf
# 4) reboot

set -euo pipefail

BASE="/home/boris/radon-min"
CONFIG_DIR="/etc/radonbox"
CONFIG_FILE="${CONFIG_DIR}/radon-config.conf"
RB_FLAG="${BASE}/rb-flag.sh"

echo "[reset] Setting boot-mode to AP..."
"$RB_FLAG" ap

echo "[reset] Removing radon artifacts..."
rm -f \
  "$BASE/radon-chart.png" \
  "$BASE/radon-log.txt" \
  "$BASE/radon-devices-init.log" || true

echo "[reset] Blanking $CONFIG_FILE..."
sudo mkdir -p "$CONFIG_DIR"
sudo tee "$CONFIG_FILE" >/dev/null <<'EOF'
# RadonBox device config
# Filled by radon-devices-init.sh after install/factory-reset
SHELLY_HOST=
AIR_MAC=
SHELLY_SWITCH_ID=
RADON_ON_THRESHOLD=2.0
RADON_OFF_THRESHOLD=1.5
RADON_EXECUTION_FREQUENCY=1
EVENING_FAN_OFF=
EOF

echo "[reset] Ready for a radonbox reboot..."

