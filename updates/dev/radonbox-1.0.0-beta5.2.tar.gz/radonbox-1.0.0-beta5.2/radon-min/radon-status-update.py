#!/usr/bin/env python3
import json, os, sys, datetime

STATUS_PATH = "/etc/radonbox/device-status.json"

def deep_merge(dst, src):
    for k, v in src.items():
        if isinstance(v, dict) and isinstance(dst.get(k), dict):
            deep_merge(dst[k], v)
        else:
            dst[k] = v

def now_iso():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")

def load_base():
    if not os.path.exists(STATUS_PATH):
        return {}
    try:
        with open(STATUS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def main():
    if len(sys.argv) != 2:
        print("usage: radon-status-update.py '<json_patch>'", file=sys.stderr)
        sys.exit(2)

    patch = json.loads(sys.argv[1])
    base = load_base()

    base.setdefault("version", 1)
    base.setdefault("hostname", os.uname().nodename)
    base["updated_local"] = now_iso()

    deep_merge(base, patch)

    os.makedirs(os.path.dirname(STATUS_PATH), exist_ok=True)
    tmp = STATUS_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(base, f, indent=2, sort_keys=True)
        f.write("\n")
    os.replace(tmp, STATUS_PATH)
    os.chmod(STATUS_PATH, 0o644)

if __name__ == "__main__":
    main()
