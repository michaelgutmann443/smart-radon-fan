#!/usr/bin/env bash
echo "=== RadonBox Onboard Status ==="
echo "boot-mode: $(cat /etc/radonbox/boot-mode 2>/dev/null || echo none)"
echo
nmcli -t -f NAME,UUID,TYPE,DEVICE connection show | grep ':wifi' || echo "no wifi profiles"
echo
ip -br addr show wlan0
echo
systemctl is-active hostapd dnsmasq radon-portal
