#!/usr/bin/env bash
set -e
echo "[restore-managed] Forcing managed Wi-Fi mode..."
sudo systemctl stop hostapd dnsmasq || true
sudo rfkill unblock wlan || true
sudo ip addr flush dev wlan0 || true
sudo ip link set wlan0 down
sudo ip link set wlan0 up
sudo nmcli device set wlan0 managed yes
sudo systemctl restart NetworkManager
echo "[restore-managed] wlan0 now under NetworkManager control."
