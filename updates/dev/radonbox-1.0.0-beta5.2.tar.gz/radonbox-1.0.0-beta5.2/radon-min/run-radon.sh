#!/usr/bin/env bash
#
# run-radon.sh — Boris Beta (robust config parsing + Beta3 status updates)
#
set -euo pipefail

BASE="/home/boris/radon-min"
LOG="$BASE/radon-log.txt"
CHART="$BASE/radon-chart.png"
CONFIG="/etc/radonbox/radon-config.conf"

STATUS_UPDATER="/usr/local/bin/radon-status-update.py"

MAX_LOG_BYTES=$((5 * 1024 * 1024))
LOG_ROTATIONS=5

status_patch() {
  # usage: status_patch '{"summary":{...}}'
  [[ -x "$STATUS_UPDATER" ]] || return 0
  sudo "$STATUS_UPDATER" "$1" >/dev/null 2>&1 || true
}

rotate_log_if_needed() {
  local LOG_PATH="$1" MAX_BYTES="$2" KEEP="$3"
  mkdir -p "$(dirname "$LOG_PATH")"
  if [ ! -f "$LOG_PATH" ]; then
    install -o boris -g boris -m 664 /dev/null "$LOG_PATH" 2>/dev/null || true
    [ -f "$LOG_PATH" ] || : > "$LOG_PATH"
    return 0
  fi
  local SIZE
  SIZE=$(stat -c%s "$LOG_PATH" 2>/dev/null || echo 0)
  [ "$SIZE" -lt "$MAX_BYTES" ] && return 0

  local DIR BASENAME STEM EXT SUFFIX
  DIR="$(dirname "$LOG_PATH")"
  BASENAME="$(basename "$LOG_PATH")"
  STEM="${BASENAME%.*}"
  SUFFIX="${BASENAME##*.}"
  EXT=""
  if [ "$STEM" != "$BASENAME" ]; then EXT=".$SUFFIX"; fi

  rm -f "$DIR/${STEM}-${KEEP}${EXT}" 2>/dev/null || true
  local i
  for ((i=KEEP-1; i>=1; i--)); do
    [ -f "$DIR/${STEM}-${i}${EXT}" ] && mv -f "$DIR/${STEM}-${i}${EXT}" "$DIR/${STEM}-$((i+1))${EXT}"
  done
  mv -f "$LOG_PATH" "$DIR/${STEM}-1${EXT}"
  install -o boris -g boris -m 664 /dev/null "$LOG_PATH" 2>/dev/null || true
  [ -f "$LOG_PATH" ] || : > "$LOG_PATH"
  chown boris:boris "$LOG_PATH" "$DIR/${STEM}-1${EXT}" 2>/dev/null || true
  chmod 664 "$LOG_PATH" "$DIR/${STEM}-1${EXT}" 2>/dev/null || true
}

# Return last NON-EMPTY value for KEY= from CONFIG
get_cfg() {
  local key="$1"
  [[ -f "$CONFIG" ]] || { echo ""; return 0; }
  grep -E "^${key}=" "$CONFIG" 2>/dev/null \
    | sed -E "s/^${key}=//" \
    | tr -d '\r' \
    | awk 'NF{v=$0} END{print v}'
}

# ---- single-instance lock (skip if already running) ----
LOCKFILE="/var/lock/run-radon.lock"
exec 9>"$LOCKFILE"
if ! flock -n 9; then
  # already running — exit quietly
  exit 0
fi

mkdir -p "$BASE"
cd "$BASE"

rotate_log_if_needed "$LOG" "$MAX_LOG_BYTES" "$LOG_ROTATIONS"

now_iso="$(date -Is)"
echo
echo "[run-radon] ===== run-radon.sh start @ ${now_iso} =====" | tee -a "$LOG"

status_patch '{
  "runtime":{"state":"RUNNING","level":"warn"},
  "summary":{"state":"RUNNING","level":"warn","text":"Running radon cycle..."},
  "chart":{"state":"NOT_READY","level":"info","path":"'"$CHART"'"}
}'

CONF="/etc/radonbox/radon-config.conf"

echo "[run-radon] Loading device config from $CONF"

if [[ ! -f "$CONF" ]]; then
  echo "[run-radon] ERROR: missing $CONF"
  exit 1
fi

# Export variables defined in the config file
set -a
# shellcheck disable=SC1090
source "$CONF"
set +a

echo "[run-radon] Loaded config: SHELLY_HOST='${SHELLY_HOST:-}' AIR_MAC='${AIR_MAC:-}' SHELLY_SWITCH_ID='${SHELLY_SWITCH_ID:-}' RADON_ON_THRESHOLD='${RADON_ON_THRESHOLD:-}' RADON_OFF_THRESHOLD='${RADON_OFF_THRESHOLD:-}'"


env | grep -E '^(SHELLY_HOST|AIR_MAC|SHELLY_SWITCH_ID|RADON_ON_THRESHOLD|RADON_OFF_THRESHOLD)=' | tee -a "$LOG" || true

echo "[run-radon] Running radon-automation.py..." | tee -a "$LOG"
status_patch '{
  "runtime":{"state":"READING_RADON","level":"warn"}
}'

if ! /usr/bin/python3 -u "$BASE/radon-automation.py" 2>&1 | tee -a "$LOG"; then
  echo "[run-radon] ERROR: radon-automation.py failed. Exiting." | tee -a "$LOG"
  status_patch '{
    "runtime":{"state":"ERROR","level":"error","last_error":"radon-automation.py failed"},
    "summary":{"state":"ERROR","level":"error","text":"Radon read failed — will retry on next scheduled run"}
  }'
  exit 1
fi

echo "[run-radon] radon-automation.py completed successfully." | tee -a "$LOG"
status_patch '{
  "runtime":{"state":"RADON_AUTOMATION_OK","level":"ok"}
}'

# If we got a successful radon read, Airthings is no longer "discovering".
# Promote Airthings status to OK to avoid stale install-phase state lingering.
status_patch '{
  "airthings":{
    "state":"OK",
    "level":"ok",
    "mac":"'"${AIR_MAC:-}"'",
    "last_error":null
  }
}'

echo "[run-radon] Generating chart from $LOG -> $CHART ..." | tee -a "$LOG"
if /usr/bin/python3 "$BASE/generate-radon-chart.py"; then
  echo "[$(date -Is)] Chart updated: ${CHART}" | tee -a "$LOG"
  status_patch '{
    "chart":{"state":"READY","level":"ok","path":"'"$CHART"'","last_error":null},
    "runtime":{"state":"IDLE","level":"ok","last_run_local":"'"$(date -Is)"'"},
    "summary":{"state":"POST_RUN","level":"ok","text":"Run complete — chart updated"}
  }'
else
  echo "[run-radon] WARNING: generate-radon-chart.py failed." | tee -a "$LOG"
  status_patch '{
    "chart":{"state":"ERROR","level":"warn","path":"'"$CHART"'","last_error":"generate-radon-chart.py failed"},
    "runtime":{"state":"IDLE","level":"warn","last_run_local":"'"$(date -Is)"'"},
    "summary":{"state":"POST_RUN","level":"warn","text":"Run complete — chart generation failed"}
  }'
fi

chown boris:boris "$LOG" "$CHART" 2>/dev/null || true
chmod 664 "$LOG" "$CHART" 2>/dev/null || true

now_iso="$(date -Is)"
echo "[$now_iso] Run complete." | tee -a "$LOG"
echo "[run-radon] ===== run-radon.sh end @ ${now_iso} =====" | tee -a "$LOG"
echo
