#!/bin/bash
#
# RadonBox one-shot-reset.sh
# Purpose: reset Pi networking into Access Point (AP) mode,
#          launch onboarding portal (Flask), and prepare for Wi-Fi provisioning.
#
# Works even if run over SSH — the session will disconnect when wlan0 flips to AP.
# After reboot, AP SSID = "RadonBox-Setup", password = "radon1234"

set -e

echo "[+] Stopping any running services..."
sudo systemctl stop NetworkManager hostapd dnsmasq radon-portal || true

# --------------------------------------------------------------------
# Step 1. Prevent NetworkManager from interfering
# --------------------------------------------------------------------
echo "[+] Forcing wlan0 unmanaged..."
sudo nmcli device set wlan0 managed no || true

# --------------------------------------------------------------------
# Step 2. Reset wlan0 and bind the AP IP
# --------------------------------------------------------------------
echo "[+] Configuring wlan0 for Access Point..."
sudo ip link set wlan0 down
sudo ip addr flush dev wlan0
sudo ip addr add 192.168.4.1/24 dev wlan0
sudo ip link set wlan0 up

# Allow the kernel to fully apply the IP before starting DHCP/DNS
sleep 3

# --------------------------------------------------------------------
# Step 3. Start hostapd and dnsmasq
# --------------------------------------------------------------------
echo "[+] Starting hostapd..."
sudo systemctl restart hostapd

# Short pause before dnsmasq so 192.168.4.1 is bound
sleep 3

echo "[+] Starting dnsmasq..."
sudo systemctl restart dnsmasq

# --------------------------------------------------------------------
# Step 4. Launch Flask portal
# --------------------------------------------------------------------
echo "[+] Launching onboarding portal..."
sudo systemctl restart radon-portal

# --------------------------------------------------------------------
# Step 5. Confirm status
# --------------------------------------------------------------------
echo "[+] Checking AP status..."
ip -br addr show wlan0
iw dev wlan0 info | grep -E 'type|ssid|channel' || true
sudo systemctl status hostapd --no-pager | head -n 10 || true
sudo systemctl status dnsmasq --no-pager | head -n 10 || true
sudo systemctl status radon-portal --no-pager | head -n 5 || true

echo
echo "[✅] RadonBox AP should now be visible as 'RadonBox-Setup' (password: radon1234)"
echo "[ℹ️ ] Your SSH session may have disconnected if you were on wlan0 — that's expected."

