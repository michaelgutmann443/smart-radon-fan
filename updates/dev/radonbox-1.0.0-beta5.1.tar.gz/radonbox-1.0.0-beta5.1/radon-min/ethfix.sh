#!/usr/bin/env bash
set -e
echo "[ethfix] Recovering wired Ethernet..."
sudo ip link set eth0 down || true
sudo ip addr flush dev eth0 || true
sudo ip link set eth0 up
sudo systemctl restart NetworkManager || true
sleep 2
ip -br addr show eth0
