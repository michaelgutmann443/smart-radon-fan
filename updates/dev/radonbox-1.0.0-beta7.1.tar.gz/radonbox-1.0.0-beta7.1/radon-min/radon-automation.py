#!/usr/bin/env python3
"""
radon-automation.py

Reads Airthings radon via BLE (Bleak), controls a Shelly switch via HTTP RPC,
logs human-readable lines + a single structured CSV line per run.

Key design rule:
- Do NOT write directly to radon-log.txt from inside this script.
  run-radon.sh captu
# Best-effort battery life (OK/LOW). Not required for operation.
b_pct = await try_read_battery_percent(client)
batt_obj = battery_life_obj(b_pct)
                    status_patch({
                        "airthings": {
                                    "battery": batt_obj,
                            "battery": batt_obj
                        }
                    })
res STDOUT/STDERR via tee into radon-log.txt.
"""

import os
import sys
import time
import json
import socket
import traceback
import subprocess
import asyncio
from dataclasses import dataclass
from datetime import datetime, date
from typing import Optional

import requests
from bleak import BleakClient, BleakScanner


# ---------------------------
# Status (Beta3)
# ---------------------------

STATUS_UPDATER = "/usr/local/bin/radon-status-update.py"

def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")



def _bytes_to_hex(b):
    try:
        if b is None:
            return None
        if isinstance(b, (bytes, bytearray)):
            return b.hex()
        if isinstance(b, list):
            return bytes(b).hex()
        return str(b)
    except Exception:
        return None

def status_patch(patch: dict) -> None:
    try:
        if os.path.exists(STATUS_UPDATER):
            subprocess.run([STATUS_UPDATER, json.dumps(patch)], timeout=5)
    except Exception:
        pass


# ---------------------------
# Paths / config
# ---------------------------

INSTALL_DATE_PATH = "/etc/radonbox/install-date.txt"

# These are expected to be exported by run-radon.sh after sourcing /etc/radonbox/radon-config.conf
SHELLY_HOST = os.getenv("SHELLY_HOST", "").strip().rstrip("/")
SHELLY_SWITCH_ID = os.getenv("SHELLY_SWITCH_ID", "").strip()
AIR_MAC = os.getenv("AIR_MAC", "").strip()
AIR_MFG_ID_RAW = os.getenv("AIR_MFG_ID", "0x0334").strip()
INSTALL_TS_RAW = os.getenv("INSTALL_TS", "").strip()
RADON_SETTLE_SECONDS_RAW = os.getenv("RADON_SETTLE_SECONDS", "86400").strip()
RADON_VALID_AFTER_TS_RAW = os.getenv("RADON_VALID_AFTER_TS", "").strip()

# Fail fast if we don't have required cached config
# If AIR_MAC is empty, we will discover the current BLE address at runtime.
# BLE privacy addressing can rotate the device address, so treating it as a stable identity is brittle.
def _parse_mfg_id(s: str) -> Optional[int]:
    try:
        s = (s or "").strip().lower()
        if not s:
            return None
        return int(s, 16) if s.startswith("0x") else int(s)
    except Exception:
        return None


def _parse_int(s: str) -> Optional[int]:
    try:
        s = (s or "").strip()
        if not s:
            return None
        return int(s)
    except Exception:
        return None

AIR_MFG_ID = _parse_mfg_id(AIR_MFG_ID_RAW)

async def resolve_airthings_addr_by_mfg_id(mfg_id: int) -> Optional[str]:
    """Resolve the current Airthings BLE address by scanning for manufacturer_data[mfg_id]."""
    best_addr = None
    best_rssi = -9999

    try:
        found_map = await BleakScanner.discover(timeout=SCAN_SECONDS, return_adv=True)
        for addr, (dev, adv) in found_map.items():
            md = getattr(adv, "manufacturer_data", None) or {}
            if mfg_id in md:
                rssi = getattr(adv, "rssi", None)
                if rssi is None:
                    rssi = getattr(dev, "rssi", None)
                if rssi is None:
                    rssi = -9999
                if rssi > best_rssi:
                    best_rssi = rssi
                    best_addr = addr
    except TypeError:
        # Older Bleak: collect adv via callback
        def _cb(dev, adv):
            nonlocal best_addr, best_rssi
            md = getattr(adv, "manufacturer_data", None) or {}
            if mfg_id in md:
                rssi = getattr(adv, "rssi", None)
                if rssi is None:
                    rssi = getattr(dev, "rssi", None)
                if rssi is None:
                    rssi = -9999
                if rssi > best_rssi:
                    best_rssi = rssi
                    best_addr = dev.address
        async with BleakScanner(detection_callback=_cb):
            await asyncio.sleep(SCAN_SECONDS)

    return best_addr

if not SHELLY_HOST or not SHELLY_SWITCH_ID:
    status_patch({
        "shelly": {"state": "ERROR", "level": "error", "host": SHELLY_HOST or None},
        "summary": {"state": "ERROR", "level": "error", "text": "Missing Shelly config in radon-config.conf"}
    })
    raise RuntimeError(
        "Missing SHELLY_HOST or SHELLY_SWITCH_ID. Expected /etc/radonbox/radon-config.conf "
        "to be populated and exported by run-radon.sh (or run radon-devices-init.sh on install)."
    )

# If SHELLY_HOST doesn't start with scheme, assume http
if not (SHELLY_HOST.startswith("http://") or SHELLY_HOST.startswith("https://")):
    SHELLY_HOST = "http://" + SHELLY_HOST

# Thresholds
ON_THRESHOLD = float(os.getenv("RADON_ON_THRESHOLD", "2.0"))
OFF_THRESHOLD = float(os.getenv("RADON_OFF_THRESHOLD", "1.5"))

# Clamp obviously-bogus radon readings (keeps charts/logs sane)
RADON_CLAMP_MAX = float(os.getenv("RADON_CLAMP_MAX", "50.0"))

# BLE behavior
SCAN_SECONDS = float(os.getenv("AIR_SCAN_SECONDS", "20"))
CONNECT_TIMEOUT = float(os.getenv("AIR_CONNECT_TIMEOUT", "25"))
CYCLES = int(os.getenv("AIR_CYCLES", "3"))
ATTEMPTS_PER_CYCLE = int(os.getenv("AIR_ATTEMPTS_PER_CYCLE", "2"))

# Retry cadence (status page)
RETRY_SECONDS = int(os.getenv("AIR_RETRY_SECONDS", "30"))

DBG_TO_STDOUT = os.getenv("DBG_TO_STDOUT", "1").strip() not in ("0", "false", "False", "no", "NO")

# Shelly RPC robustness (Wi‑Fi jitter can cause occasional connect delays).
# Use separate connect/read timeouts and a small retry loop to avoid false ERROR states.
SHELLY_CONNECT_TIMEOUT = float(os.getenv("SHELLY_CONNECT_TIMEOUT", "3.0"))
SHELLY_READ_TIMEOUT = float(os.getenv("SHELLY_READ_TIMEOUT", "5.0"))
# Number of retries AFTER the first attempt (so 1 means up to 2 total tries).
SHELLY_RPC_RETRIES = int(os.getenv("SHELLY_RPC_RETRIES", "1"))
# Base sleep seconds between retries (will backoff linearly: base*(attempt_index+1)).
SHELLY_RPC_RETRY_SLEEP_BASE = float(os.getenv("SHELLY_RPC_RETRY_SLEEP_BASE", "0.3"))


# Airthings Wave radon characteristic UUID used by your current system
CHAR_UUID = "b42e4dcc-ade7-11e4-89d3-123b93f75cba"
# Standard BLE Battery Level characteristic (0–100). Not all Airthings models expose this;
# we treat it as best-effort and map it to Battery Life OK/LOW.
BATTERY_CHAR_UUID = "00002a19-0000-1000-8000-00805f9b34fb"


# ---------------------------
# Logging helpers
# ---------------------------

def dbg_write(msg: str) -> None:
    """One place to write human-readable log lines."""
    if not DBG_TO_STDOUT:
        return
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
    sys.stdout.write(f"{ts}: {msg}\n")
    sys.stdout.flush()


def log_exception(prefix: str, e: Exception) -> None:
    dbg_write(f"{prefix}: [{type(e).__name__}] {e}")
    tb = traceback.format_exc().strip()
    if tb:
        dbg_write(f"Trace: {tb.splitlines()[-1]}")


# ---------------------------
# Utilities
# ---------------------------

def is_installation_day() -> bool:
    """True if INSTALL_DATE_PATH exists and matches today's date."""
    try:
        with open(INSTALL_DATE_PATH, "r", encoding="utf-8") as f:
            s = f.read().strip()
        if not s:
            return False
        return s == date.today().isoformat()
    except Exception:
        return False


def shelly_rpc(path: str, payload: Optional[dict] = None, timeout: Optional[float] = None) -> dict:
    """
    Call Shelly RPC endpoint with robust timeouts + retries.

    - Wi‑Fi can occasionally spike (ARP, power-save, interference). A 2s connect timeout is
      often too aggressive in real homes.
    - We use (connect, read) timeouts and retry once by default.
    """
    url = f"{SHELLY_HOST}{path}"

    # Allow a single float override for both connect+read (backwards compatible).
    if timeout is None:
        timeout_obj = (SHELLY_CONNECT_TIMEOUT, SHELLY_READ_TIMEOUT)
    else:
        timeout_obj = (float(timeout), float(timeout))

    last_exc: Exception | None = None
    total_attempts = max(1, 1 + int(SHELLY_RPC_RETRIES))

    for attempt_idx in range(total_attempts):
        try:
            if payload is None:
                r = requests.get(url, timeout=timeout_obj)
            else:
                r = requests.post(url, json=payload, timeout=timeout_obj)
            r.raise_for_status()
            return r.json()
        except Exception as e:
            last_exc = e
            # Retry on transient errors.
            if attempt_idx < total_attempts - 1:
                time.sleep(SHELLY_RPC_RETRY_SLEEP_BASE * (attempt_idx + 1))
                continue
            raise


def shelly_get_state() -> bool:
    try:
        j = shelly_rpc(f"/rpc/Switch.GetStatus?id={SHELLY_SWITCH_ID}")
        status_patch({
            "shelly": {
                "state": "VALIDATED", "level": "ok",
                "host": SHELLY_HOST, "switch_id": int(SHELLY_SWITCH_ID),
                "last_ok_local": _now_iso(), "last_error": None
            }
        })
        return bool(j.get("output", False))
    except Exception as e:
        log_exception("Shelly.GetStatus failed", e)
        status_patch({
            "shelly": {
                "state": "ERROR", "level": "warn",
                "host": SHELLY_HOST, "switch_id": int(SHELLY_SWITCH_ID or 0),
                "last_error": f"{type(e).__name__}: {e}"
            }
        })
        # Conservative fallback: treat as OFF
        return False


def shelly_set_state(on: bool) -> None:
    try:
        _ = shelly_rpc("/rpc/Switch.Set", {"id": int(SHELLY_SWITCH_ID), "on": bool(on)})
        dbg_write(f"Shelly set -> {'ON' if on else 'OFF'} @ {SHELLY_HOST}")
        status_patch({
            "shelly": {
                "state": "VALIDATED", "level": "ok",
                "host": SHELLY_HOST, "switch_id": int(SHELLY_SWITCH_ID),
                "last_ok_local": _now_iso(), "last_error": None
            }
        })
    except Exception as e:
        log_exception("Shelly.Set failed", e)
        status_patch({
            "shelly": {
                "state": "ERROR", "level": "warn",
                "host": SHELLY_HOST, "switch_id": int(SHELLY_SWITCH_ID or 0),
                "last_error": f"{type(e).__name__}: {e}"
            }
        })


@dataclass
class RadonReading:
    short_pci: float
    long_pci: float


def parse_wave_payload(data: bytes) -> Optional[RadonReading]:
    try:
        if not data or len(data) < 6:
            return None
        short_raw = int.from_bytes(data[2:4], byteorder="little", signed=False)
        long_raw = int.from_bytes(data[4:6], byteorder="little", signed=False)
        short_pci = round(short_raw / 10.0, 2)
        long_pci = round(long_raw / 10.0, 2)
        return RadonReading(short_pci=short_pci, long_pci=long_pci)
    except Exception:
        return None



async def try_read_battery_percent(client):
    """Best-effort read of standard BLE battery level (0..100). Returns int or None."""
    try:
        raw = await client.read_gatt_char(BATTERY_CHAR_UUID)
        if not raw:
            return None
        pct = int(raw[0])
        if 0 <= pct <= 100:
            return pct
        return None
    except Exception:
        return None

def battery_life_obj(pct):
    """Map pct to a simple OK/LOW/UNKNOWN object for the portal."""
    if pct is None:
        return {"state": "UNKNOWN", "level": "info", "text": "Battery Life UNKNOWN"}
    if pct <= 15:
        return {"state": "LOW", "level": "warn", "text": "Battery Life LOW", "percent": pct}
    return {"state": "OK", "level": "ok", "text": "Battery Life OK", "percent": pct}


def vendor_battery_obj_from_payload(raw: Optional[bytes]) -> dict:
    """
    Airthings Wave-series devices often do NOT expose the standard BLE Battery Level (0x2A19).
    We do not yet have a validated mapping from the vendor payload bits to battery state
    (fresh batteries still reported "LOW" under the prior heuristic).

    To avoid false warnings, report UNKNOWN until a reliable mapping is proven.
    """
    return {"state": "UNKNOWN", "level": "info", "text": "Battery Life UNKNOWN"}

async def read_radon_gatt(mac: str) -> RadonReading:
    """
    Connect to the Airthings MAC and read/validate radon values, with retries.
    Writes status updates for installer status page.
    """
    last_good: Optional[RadonReading] = None

    attempt_counter = 0
    attempt_max = CYCLES * ATTEMPTS_PER_CYCLE


    batt_obj = {"state": "UNKNOWN", "level": "info", "text": "Battery Life UNKNOWN"}
    # installer-friendly baseline
    status_patch({
        "airthings": {
            "state": "WAITING_FOR_READ",
            "level": "warn",
            "mac": mac,
                             "battery": batt_obj,
            "read": {
                "attempt": 0,
                "attempt_max": attempt_max,
                "retry_seconds": RETRY_SECONDS,
                "last_attempt_local": None,
                "next_retry_local": None,
                "last_ok_local": None,
                "last_error": None
            },
            "tip": "Battery radon sensors often sleep. Pick up the meter or wave your hand near it to wake it. RadonBox will keep retrying automatically."
        },
        "summary": {
            "state": "READY_WAITING_FOR_FIRST_READ",
            "level": "warn",
            "text": "Installation complete — waiting for first radon reading"
        }
    })

    for cycle in range(1, CYCLES + 1):
        dbg_write(f"[cycle {cycle}/{CYCLES}] Scanning up to {SCAN_SECONDS:.0f}s for Airthings device {mac}...")
        try:
            found = False
            # Scan for BLE devices and capture AdvertisementData (avoids deprecated BLEDevice.rssi/metadata)
            adv_by_addr = {}
            devices = []
            try:
                # Newer Bleak: returns dict[address] = (BLEDevice, AdvertisementData)
                found_map = await BleakScanner.discover(timeout=SCAN_SECONDS, return_adv=True)
                for addr, (dev, adv) in found_map.items():
                    devices.append(dev)
                    adv_by_addr[addr] = adv
            except TypeError:
                # Older Bleak: collect adv data via detection callback
                devices_map = {}
                def _cb(dev, adv):
                    devices_map[dev.address] = dev
                    adv_by_addr[dev.address] = adv
                async with BleakScanner(detection_callback=_cb):
                    await asyncio.sleep(SCAN_SECONDS)
                devices = list(devices_map.values())
            
            dbg_write(f"[cycle {cycle}] Scan complete: saw {len(devices)} devices.")
            for d in devices:
                if (d.address or "").lower() == mac.lower():
                    found = True
                    rssi = getattr(adv_by_addr.get(d.address), "rssi", None)
                    name = getattr(d, "name", None)
                    dbg_write(f"[cycle {cycle}] Target device seen: {d.address} RSSI={rssi} Name={name}")
                    status_patch({
                        "airthings": {
                            "state": "FOUND",
                            "level": "ok",
                            "mac": mac,
                             "battery": batt_obj,
                            "name": name,
                            "rssi": rssi
                                                     ,"adv": {
                                 "manufacturer_data": {k: _bytes_to_hex(v) for k, v in (getattr(adv_by_addr.get(d.address), "manufacturer_data", {}) or {}).items()},
                                 "service_data": {k: _bytes_to_hex(v) for k, v in (getattr(adv_by_addr.get(d.address), "service_data", {}) or {}).items()}
                             }
                         }
                    })
                    break

            if not found:
                dbg_write(f"[cycle {cycle}] Target device not seen in scan; retrying next cycle.")
                status_patch({
                    "airthings": {
                        "state": "WAITING_FOR_READ",
                        "level": "warn",
                        "mac": mac,
                        "read": {"last_error": "Device not seen in BLE scan"}
                    }
                })
                continue
        except Exception as e:
            log_exception(f"[cycle {cycle}] Scan error", e)
            status_patch({
                "airthings": {
                    "state": "WAITING_FOR_READ",
                    "level": "warn",
                    "mac": mac,
                         "battery": batt_obj,
                    "read": {"last_error": f"Scan error: {type(e).__name__}: {e}"}
                }
            })
            continue

        for attempt in range(1, ATTEMPTS_PER_CYCLE + 1):
            attempt_counter += 1
            last_attempt = _now_iso()
            next_retry = (datetime.now().astimezone() + __import__("datetime").timedelta(seconds=RETRY_SECONDS)).isoformat(timespec="seconds")

            status_patch({
                "airthings": {
                    "state": "WAITING_FOR_READ",
                    "level": "warn",
                    "mac": mac,
                         "battery": batt_obj,
                    "read": {
                        "attempt": attempt_counter,
                        "attempt_max": attempt_max,
                        "last_attempt_local": last_attempt,
                        "next_retry_local": next_retry,
                        "retry_seconds": RETRY_SECONDS
                    }
                }
            })

            try:
                wait_s = 4.0 + (cycle * 0.4) + (attempt * 0.4)
                dbg_write(f"[cycle {cycle}] Attempt {attempt}/{ATTEMPTS_PER_CYCLE}: wait {wait_s:.1f}s before connect...")
                time.sleep(wait_s)
                dbg_write(f"[cycle {cycle}] Connecting with timeout={CONNECT_TIMEOUT:.1f}s ...")
                client = BleakClient(mac, timeout=CONNECT_TIMEOUT)
                try:
                    await client.connect()
                    dbg_write("[connect] Connected. Reading radon GATT...")

                    # Service discovery can help on flaky connections; ignore failures here.
                    try:
                        await client.get_services()
                    except Exception:
                        pass

                    for vtry in range(1, 4):
                        raw = await client.read_gatt_char(CHAR_UUID)
                        batt_obj = vendor_battery_obj_from_payload(raw)
                        # Diagnostics: capture the raw vendor payload (hex) to enable
                        # Airthings-specific battery decoding (device does not expose 0x2A19).
                        try:
                            status_patch({
                                "airthings": {
                                    "vendor_payload_len": len(raw) if raw is not None else None,
                                    "vendor_payload_hex": raw.hex() if isinstance(raw, (bytes, bytearray)) else None
                                }
                            })
                        except Exception:
                            pass

                        reading = parse_wave_payload(raw)
                        if reading is None:
                            dbg_write(f"[validation] Try {vtry}: could not parse payload; retrying read...")
                            time.sleep(0.3)
                            continue

                        short_pci = reading.short_pci
                        long_pci = reading.long_pci

                        if short_pci < 0:
                            short_pci = 0.0
                        if long_pci < 0:
                            long_pci = 0.0

                        if short_pci > RADON_CLAMP_MAX:
                            dbg_write(f"[validation] Clamping short from {short_pci} -> {RADON_CLAMP_MAX}")
                            short_pci = RADON_CLAMP_MAX
                        if long_pci > RADON_CLAMP_MAX:
                            dbg_write(f"[validation] Clamping long from {long_pci} -> {RADON_CLAMP_MAX}")
                            long_pci = RADON_CLAMP_MAX

                        dbg_write(f"[validation] OK (clamped if needed): short={short_pci} pCi/L, long={long_pci} pCi/L")
                        last_good = RadonReading(short_pci=short_pci, long_pci=long_pci)

                        status_patch({
                            "airthings": {
                                "state": "READ_OK",
                                "level": "ok",
                                "mac": mac,
                                "battery": batt_obj,
                                "read": {"last_ok_local": _now_iso(), "last_error": None}
                            }
                        })

                        return last_good
                finally:
                    # Always tear down BLE state; EOFError can leave a half-open connection.
                    try:
                        await client.disconnect()
                    except Exception:
                        pass

            except EOFError:
                if last_good is not None:
                    dbg_write(f"[cycle {cycle}] EOFError after successful validation; ignoring and returning last_good.")
                    status_patch({
                        "airthings": {
                            "state": "READ_OK",
                            "level": "ok",
                            "mac": mac,
                            "read": {"last_ok_local": _now_iso(), "last_error": None}
                        }
                    })
                    return last_good

                dbg_write(f"[cycle {cycle}] EOFError before validation; retrying...")
                status_patch({
                    "airthings": {
                        "state": "WAITING_FOR_READ",
                        "level": "warn",
                        "mac": mac,
                        "read": {"last_error": "EOFError during GATT read"}
                    }
                })
                time.sleep(float(RETRY_SECONDS))
            except Exception as e:
                log_exception(f"[cycle {cycle}] Connect/read error (attempt {attempt})", e)
                status_patch({
                    "airthings": {
                        "state": "WAITING_FOR_READ",
                        "level": "warn",
                        "mac": mac,
                         "battery": batt_obj,
                        "read": {"last_error": f"{type(e).__name__}: {e}"}
                    }
                })
                dbg_write(f"[cycle {cycle}] Waiting 12.0s before next attempt...")
                time.sleep(12.0)

    raise RuntimeError("Failed to read radon from Airthings after retries.")



# ---------------------------
# Fan control algorithm (extracted)
# ---------------------------

FAN_ALGO_STATE_PATH = os.getenv("RADON_FAN_ALGO_STATE_PATH", "/var/lib/radonbox/fan-algo-state.json").strip()
ST_ON_CONSECUTIVE_SAMPLES = int(os.getenv("RADON_ST_ON_SAMPLES", "2"))  # N
# If we've seen fewer than N samples total (fresh install / reset), allow ST>=ON to trigger ON.
ALLOW_ST_ON_BEFORE_N_SAMPLES = os.getenv("RADON_ALLOW_ST_ON_BEFORE_N", "1").strip() not in ("0", "false", "False", "no", "NO")
ALGO_UPGRADE_FREEZE = os.getenv("RADON_ALGO_UPGRADE_FREEZE", "1").strip() not in ("0", "false", "False", "no", "NO")

FAN_ALGO_VERSION = "always-command-v2"


def _load_fan_algo_state() -> dict:
    try:
        with open(FAN_ALGO_STATE_PATH, "r", encoding="utf-8") as f:
            j = json.load(f)
        if not isinstance(j, dict):
            return {}
        return j
    except Exception:
        return {}


def _save_fan_algo_state(j: dict) -> None:
    try:
        d = os.path.dirname(FAN_ALGO_STATE_PATH)
        if d and not os.path.exists(d):
            os.makedirs(d, exist_ok=True)
        tmp = FAN_ALGO_STATE_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(j, f, sort_keys=True)
        os.replace(tmp, FAN_ALGO_STATE_PATH)
    except Exception:
        # Non-fatal; algorithm will still work, just without persistence.
        pass


def _backup_fan_algo_state() -> str | None:
    """Best-effort backup of the algo state file; returns backup path or None."""
    try:
        if not os.path.exists(FAN_ALGO_STATE_PATH):
            return None
        ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        bak = FAN_ALGO_STATE_PATH + f".bak.{ts}"
        shutil.copy2(FAN_ALGO_STATE_PATH, bak)
        return bak
    except Exception:
        return None


def decide_fan_state(
    short_pci: float,
    long_pci: float,
    current_state: bool,
    on_threshold: float,
    off_threshold: float,
    *,
    installation_day: bool,
) -> tuple[bool, str, dict]:
    """
    Decide desired fan state and reason, with a simple ST>=ON consecutive-samples filter.

    Key change (Beta reliability):
    - We persist and use last_desired_state so SRF remains authoritative even if the Shelly
      flips state externally (power glitch, schedule, manual press, etc.).
    - The caller can (and should) re-assert the desired state every cycle (idempotent).

    Behavior:
    - Installation day: force ON.
    - ON:
        * Immediate ON if LT >= ON threshold (LT is slow but meaningful).
        * Otherwise, require ST >= ON for N consecutive samples to turn ON.
        * Exception: during the first (N-1) total samples (fresh install/reset),
          allow ST>=ON to turn ON (configurable via RADON_ALLOW_ST_ON_BEFORE_N).
    - OFF: Only if (ST < OFF) AND (LT < OFF).
    - Else: keep last_desired_state (fallback to current Shelly state if unknown).

    Returns: (desired_state, reason, updated_state_dict)
    """
    st = _load_fan_algo_state()
    stored_version = st.get("algo_version")
    upgrade_bootstrap = (stored_version != FAN_ALGO_VERSION)
    if upgrade_bootstrap:
        bak = _backup_fan_algo_state()
        st["last_desired_state"] = "UNDEFINED"
        st["upgrade_bootstrap"] = True
        st["upgrade_backup"] = bak
    total = int(st.get("total_samples", 0) or 0)
    st_on_streak = int(st.get("st_on_streak", 0) or 0)
    last_desired = st.get("last_desired_state", None)
    # Treat last_desired_state as a 3-state value: UNDEFINED / OFF / ON.
    # On first run (or after code update), bootstrap intent from the Shelly's observed state
    # to avoid surprising toggles.
    if st.get("algo_version") != FAN_ALGO_VERSION:
        last_desired_state = None
    elif isinstance(last_desired, bool):
        last_desired_state = last_desired
    elif isinstance(last_desired, str) and last_desired.strip().upper() == "UNDEFINED":
        last_desired_state = None
    else:
        last_desired_state = None

    if last_desired_state is None:
        last_desired_state = current_state  # bootstrap from hardware
        st["last_desired_state"] = "UNDEFINED"

    # Bootstrap last_desired_state (intent) on first run or after an algo version change.
    last_desired = st.get("last_desired_state", "UNDEFINED")
    if last_desired in (None, "", "UNDEFINED"):
        last_desired = True if current_state else False
        st["last_desired_state"] = last_desired
        st["last_desired_bootstrapped_from_shelly"] = True

    # Installation-day is a PURE override: force ON, but do not let this override
    # affect the algorithm's "memory" (total_samples / last_desired_state / streaks).
    desired = last_desired_state
    reason = "HOLD_STATE"

    if installation_day:
        desired = True
        reason = "INSTALLATION_DAY_FORCE_ON"
        # Do not update total_samples or last_desired_state, and do not accumulate streaks.
        st_on_streak = 0

    else:
        # Update counters for this sample (normal control only)
        total += 1
        if short_pci >= on_threshold:
            st_on_streak += 1
        else:
            st_on_streak = 0
        # OFF: both metrics must agree we are below OFF.
        if (short_pci < off_threshold) and (long_pci < off_threshold):
            desired = False
            reason = "OFF_THRESHOLD_BOTH"

        # ON: LT triggers immediately.
        elif long_pci >= on_threshold:
            desired = True
            reason = "LT_ON_THRESHOLD"

        # ON: ST triggers only with confirmation (or early-install exception).
        elif short_pci >= on_threshold:
            if st_on_streak >= ST_ON_CONSECUTIVE_SAMPLES:
                desired = True
                reason = f"ST_ON_STREAK_{ST_ON_CONSECUTIVE_SAMPLES}"
            elif ALLOW_ST_ON_BEFORE_N_SAMPLES and total < ST_ON_CONSECUTIVE_SAMPLES:
                # Not enough history yet; be conservative early in a fresh install/reset.
                desired = True
                reason = "ST_ON_NO_HISTORY"
            else:
                desired = last_desired_state
                reason = "ST_ON_WAIT_CONFIRM"

        else:
            desired = last_desired_state
            reason = "HOLD_STATE"

    # Persist state (best-effort)
    st["total_samples"] = total
    st["st_on_streak"] = st_on_streak
    st["algo_version"] = FAN_ALGO_VERSION
    st["last_desired_state"] = ("UNDEFINED" if installation_day else bool(desired))
    st["last_short_pci"] = short_pci
    st["last_long_pci"] = long_pci
    st["last_reason"] = reason
    st["install_override"] = bool(installation_day)
    st["last_update_local"] = _now_iso()
    _save_fan_algo_state(st)

    return desired, reason, st



# ---------------------------
# Main
# ---------------------------

async def main() -> int:
    dbg_write("Starting radon automation...")
    dbg_write("")
    dbg_write("=== Radon run start ===")
    dbg_write(
        f"Env: Python {sys.version.split()[0]}, "
        f"Bleak {getattr(__import__('bleak'), '__version__', 'unknown')}, "
        f"Platform {os.uname().sysname} {os.uname().release} ({os.uname().machine})"
    )

    # ---------------------------
    # Installation settle window
    # ---------------------------
    now_ts = int(time.time())
    install_ts = _parse_int(INSTALL_TS_RAW)
    settle_seconds = _parse_int(RADON_SETTLE_SECONDS_RAW) or 86400

    valid_after_ts = _parse_int(RADON_VALID_AFTER_TS_RAW)
    if valid_after_ts is None and install_ts is not None:
        valid_after_ts = install_ts + settle_seconds

    is_settling = bool(install_ts is not None and valid_after_ts is not None and now_ts < valid_after_ts)
    radon_is_valid = not is_settling

    # Publish install/validity info for portal/status consumers.
    status_patch({
    "install": {
        "install_ts": install_ts,
        "settle_seconds": (settle_seconds if install_ts is not None else None),
        "valid_after_ts": valid_after_ts,
        "is_settling": is_settling,
    },
    "radon": {
        "is_valid": radon_is_valid,
        "valid_reason": ("settling" if is_settling else "ok"),
    }
    })


    # Read radon
    # If AIR_MAC is empty, discover current address via AIR_MFG_ID.
    mac = AIR_MAC
    if not mac:
        if AIR_MFG_ID is None:
            status_patch({
                "airthings": {"state": "ERROR", "level": "error", "mac": None},
                "summary": {"state": "ERROR", "level": "error", "text": "Missing AIR_MAC and invalid AIR_MFG_ID"}
            })
            raise RuntimeError("Missing AIR_MAC and invalid AIR_MFG_ID; cannot discover Airthings device.")
        dbg_write(f"No AIR_MAC set; discovering Airthings via AIR_MFG_ID={AIR_MFG_ID_RAW}...")
        mac = await resolve_airthings_addr_by_mfg_id(AIR_MFG_ID)
        if not mac:
            status_patch({
                "airthings": {"state": "ERROR", "level": "error", "mac": None},
                "summary": {"state": "ERROR", "level": "error", "text": "Could not discover Airthings via AIR_MFG_ID"}
            })
            raise RuntimeError(f"Could not discover Airthings via AIR_MFG_ID={AIR_MFG_ID_RAW}.")
        dbg_write(f"Discovered Airthings address: {mac}")

    reading = await read_radon_gatt(mac)
    short_pci = reading.short_pci
    long_pci = reading.long_pci

    dbg_write(f"Airthings short-term radon: {short_pci:.2f} pCi/L")
    dbg_write(f"Airthings long-term radon: {long_pci:.2f} pCi/L")
    dbg_write(f"Airthings reading (for chart): short={short_pci} pCi/L, long={long_pci} pCi/L")

    status_patch({
        "summary": {"state": ("SETTLING" if is_settling else "OPERATIONAL"), "level": ("warn" if is_settling else "ok"), "text": ("Settling — readings valid after %s" % datetime.fromtimestamp(valid_after_ts).astimezone().isoformat(timespec="seconds") if (is_settling and valid_after_ts) else "System operational")}
    })

    # Read Shelly state
    current_state = shelly_get_state()
    dbg_write(f"Current Shelly state: {current_state}")

    installation_flag = 0

    # Decide fan state (algorithm extracted to a standalone function)
    installation_day = is_installation_day()
    desired_state, fan_reason, _algo_state = decide_fan_state(
        short_pci=short_pci,
        long_pci=long_pci,
        current_state=current_state,
        on_threshold=ON_THRESHOLD,
        off_threshold=OFF_THRESHOLD,
        installation_day=installation_day,
    )

    if installation_day:
        installation_flag = 1
        dbg_write(
            f"Installation day: forcing fan ON regardless of short={short_pci}, long={long_pci}."
        )
    else:
        if fan_reason == "LT_ON_THRESHOLD":
            dbg_write(
                f"ON rule met (long={long_pci} >= {ON_THRESHOLD}); turning ON."
            )
        elif fan_reason.startswith("ST_ON_STREAK_"):
            dbg_write(
                f"ON rule met (short={short_pci} >= {ON_THRESHOLD} for {ST_ON_CONSECUTIVE_SAMPLES} consecutive samples); turning ON."
            )
        elif fan_reason == "ST_ON_NO_HISTORY":
            dbg_write(
                f"ON rule met early (short={short_pci} >= {ON_THRESHOLD} with insufficient history); turning ON."
            )
        elif fan_reason == "ST_ON_WAIT_CONFIRM":
            dbg_write(
                f"Short-term >= ON but waiting for {ST_ON_CONSECUTIVE_SAMPLES} consecutive samples; reasserting last desired state."
            )
        elif fan_reason == "OFF_THRESHOLD_BOTH":
            dbg_write(
                f"OFF rule met (short={short_pci} < {OFF_THRESHOLD} AND long={long_pci} < {OFF_THRESHOLD}); turning OFF."
            )
        else:
            dbg_write(
                f"Hysteresis band: short={short_pci}, long={long_pci}, between OFF<{OFF_THRESHOLD} and ON≥{ON_THRESHOLD}; reasserting last desired state."
            )
        # Always (re)assert the desired Shelly state every cycle.
    # This is idempotent for Shelly and helps recover from external flips (power glitch, schedule, manual press, etc.).
    if desired_state == current_state:
        dbg_write(f"Desired Shelly state already {desired_state}; sending command anyway to ensure state.")
    shelly_set_state(desired_state)

    fan_state = 1 if desired_state else 0
    timestamp = datetime.now().isoformat(timespec="milliseconds")

    try:
        sys.stdout.write(f"{timestamp},{short_pci},{long_pci},{fan_state},{installation_flag},{fan_reason}\n")
        sys.stdout.flush()
    except Exception as e:
        log_exception("Structured log write failed", e)

    dbg_write("Radon automation complete.")
    return 0


if __name__ == "__main__":
    import asyncio
    try:
        raise SystemExit(asyncio.run(main()))
    except KeyboardInterrupt:
        raise