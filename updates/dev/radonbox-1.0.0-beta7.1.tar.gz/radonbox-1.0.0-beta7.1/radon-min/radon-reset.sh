#!/usr/bin/env bash
set -euo pipefail

DEFAULTS_FILE="/opt/radonbox/current/radon-min/radon-factory-defaults.conf"
RADON_CONFIG_INIT="/opt/radonbox/current/radon-min/radon-config-init.sh"

if [ ! -f "$DEFAULTS_FILE" ]; then
  echo "[radon-reset] ERROR: missing defaults file: $DEFAULTS_FILE" >&2
  exit 2
fi

# shellcheck disable=SC1090
. "$DEFAULTS_FILE"


echo "[radon-reset] Starting baseline reset for Smart Radon Fan"

# Resolve current active release
CURRENT_ROOT="$(readlink -f /opt/radonbox/current)"
RADON_MIN="$CURRENT_ROOT/radon-min"
RB_FLAG="$RADON_MIN/rb-flag.sh"

if [ ! -x "$RB_FLAG" ]; then
  echo "[radon-reset] ERROR: rb-flag.sh not found or not executable at $RB_FLAG" >&2
  exit 1
fi

# 1) Force AP mode for next boot
echo "[radon-reset] Setting boot mode to AP"
sudo "$RB_FLAG" ap

# 2) Remove runtime artifacts (logs, charts, discovery logs)
echo "[radon-reset] Removing runtime artifacts"
sudo rm -f \
  "$RADON_MIN/radon-log.txt" \
  "$RADON_MIN/radon-chart.png" \
  "$RADON_MIN/radon-devices-init.log" \
  "$RADON_MIN/radon-status.json" || true
# Persistent system logs (cleared for SD imaging / clean field boots)
if [ -d /var/log/radonbox ]; then
  sudo rm -f /var/log/radonbox/*.log || true
fi

# --- Site Report: Clears UI Setup checkbox
sudo rm -f /var/lib/radonbox/onboard-last.json

# 3) Reset device configuration
if [ ! -x "$RADON_CONFIG_INIT" ]; then
  echo "[radon-reset] ERROR: missing $RADON_CONFIG_INIT" >&2
  exit 2
fi

# Factory reset: clear volatile fields; preserve knobs (Shelly/thresholds) if present
sudo "$RADON_CONFIG_INIT" --factory-reset

# --- Beta7: Factory reset must clear persisted UI/device status ---
STATUS_JSON="/etc/radonbox/device-status.json"
if [ -f "$STATUS_JSON" ]; then
  echo "[reset] Removing persisted status: $STATUS_JSON"
  rm -f "$STATUS_JSON"
fi

# 4) Sync filesystem
sync

if [ "${1:-}" = "--reboot" ]; then
  echo "[radon-reset] Rebooting now..."
  sleep 1
  /sbin/reboot
fi

echo "[radon-reset] Ready for a radonbox reboot..."



echo "[reset] Ready for a radonbox reboot..."

