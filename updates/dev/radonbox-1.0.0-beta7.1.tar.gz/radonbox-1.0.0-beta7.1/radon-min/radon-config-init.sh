#!/usr/bin/env bash
set -euo pipefail

CONFIG="/etc/radonbox/radon-config.conf"
DEFAULTS="/opt/radonbox/current/radon-min/radon-factory-defaults.conf"

# Defaults (may be overridden by DEFAULTS if present)
RADON_ON_THRESHOLD_DEFAULT="4.0"
RADON_OFF_THRESHOLD_DEFAULT="2.0"
RADON_EXECUTION_FREQUENCY_DEFAULT="2"
EVENING_FAN_OFF_DEFAULT=""

AIR_MODE_DEFAULT="auto"
AIR_MFG_ID_DEFAULT="0x0334"
RADON_SETTLE_SECONDS_DEFAULT="86400"

# Site Report defaults (feature is opt-in; should be OFF after factory reset)
SITE_REPORT_ENABLED_DEFAULT="0"

# Preserve knobs by default on reset/install (can be disabled with --no-preserve)
PRESERVE=1
MODE="ensure"   # ensure|install|factory-reset

usage() {
  echo "Usage: $0 [--ensure|--install|--factory-reset] [--no-preserve]" >&2
  exit 2
}

while [ $# -gt 0 ]; do
  case "$1" in
    --ensure) MODE="ensure" ;;
    --install) MODE="install" ;;
    --factory-reset) MODE="factory-reset" ;;
    --no-preserve) PRESERVE=0 ;;
    -h|--help) usage ;;
    *) echo "Unknown arg: $1" >&2; usage ;;
  esac
  shift
done

# Factory reset must not preserve old thresholds or discovery settings
if [ "$MODE" = "factory-reset" ]; then
  PRESERVE=0
fi

if [ -f "$DEFAULTS" ]; then
  # shellcheck disable=SC1090
  . "$DEFAULTS" || true
  # Allow DEFAULTS to define these; otherwise keep hardcoded defaults.
  RADON_ON_THRESHOLD_DEFAULT="${RADON_ON_THRESHOLD:-$RADON_ON_THRESHOLD_DEFAULT}"
  RADON_OFF_THRESHOLD_DEFAULT="${RADON_OFF_THRESHOLD:-$RADON_OFF_THRESHOLD_DEFAULT}"
  RADON_EXECUTION_FREQUENCY_DEFAULT="${RADON_EXECUTION_FREQUENCY:-$RADON_EXECUTION_FREQUENCY_DEFAULT}"
  EVENING_FAN_OFF_DEFAULT="${EVENING_FAN_OFF:-$EVENING_FAN_OFF_DEFAULT}"
  RADON_SETTLE_SECONDS_DEFAULT="${RADON_SETTLE_SECONDS:-$RADON_SETTLE_SECONDS_DEFAULT}"
  AIR_MFG_ID_DEFAULT="${AIR_MFG_ID:-$AIR_MFG_ID_DEFAULT}"
  AIR_MODE_DEFAULT="${AIR_MODE:-$AIR_MODE_DEFAULT}"
  SITE_REPORT_ENABLED_DEFAULT="${SITE_REPORT_ENABLED:-$SITE_REPORT_ENABLED_DEFAULT}"
fi

# Read existing values (if any)
get_kv() {
  local key="$1"
  [ -f "$CONFIG" ] || return 0
  # last occurrence wins
  awk -F= -v k="$key" 'BEGIN{v=""} $1==k{v=$2} END{print v}' "$CONFIG" 2>/dev/null || true
}

# Preserved knobs (if PRESERVE=1)
SHELLY_HOST_OLD="$(get_kv SHELLY_HOST)"
SHELLY_SWITCH_ID_OLD="$(get_kv SHELLY_SWITCH_ID)"
RADON_ON_THRESHOLD_OLD="$(get_kv RADON_ON_THRESHOLD)"
RADON_OFF_THRESHOLD_OLD="$(get_kv RADON_OFF_THRESHOLD)"
RADON_EXECUTION_FREQUENCY_OLD="$(get_kv RADON_EXECUTION_FREQUENCY)"
EVENING_FAN_OFF_OLD="$(get_kv EVENING_FAN_OFF)"
SITE_REPORT_ENABLED_OLD="$(get_kv SITE_REPORT_ENABLED)"

# Apply preservation policy
if [ "$PRESERVE" -eq 1 ]; then
  SHELLY_HOST="${SHELLY_HOST_OLD:-}"
  SHELLY_SWITCH_ID="${SHELLY_SWITCH_ID_OLD:-0}"
  RADON_ON_THRESHOLD="${RADON_ON_THRESHOLD_OLD:-$RADON_ON_THRESHOLD_DEFAULT}"
  RADON_OFF_THRESHOLD="${RADON_OFF_THRESHOLD_OLD:-$RADON_OFF_THRESHOLD_DEFAULT}"
  RADON_EXECUTION_FREQUENCY="${RADON_EXECUTION_FREQUENCY_OLD:-$RADON_EXECUTION_FREQUENCY_DEFAULT}"
  EVENING_FAN_OFF="${EVENING_FAN_OFF_OLD:-$EVENING_FAN_OFF_DEFAULT}"
  SITE_REPORT_ENABLED="${SITE_REPORT_ENABLED_OLD:-$SITE_REPORT_ENABLED_DEFAULT}"
else
  SHELLY_HOST=""
  SHELLY_SWITCH_ID="0"
  RADON_ON_THRESHOLD="$RADON_ON_THRESHOLD_DEFAULT"
  RADON_OFF_THRESHOLD="$RADON_OFF_THRESHOLD_DEFAULT"
  RADON_EXECUTION_FREQUENCY="$RADON_EXECUTION_FREQUENCY_DEFAULT"
  EVENING_FAN_OFF="$EVENING_FAN_OFF_DEFAULT"
  SITE_REPORT_ENABLED="$SITE_REPORT_ENABLED_DEFAULT"
fi

# Always clear volatile fields on reset/install; ensure keeps existing unless missing.
INSTALL_TS=""
INSTALL_ISO=""
RADON_SETTLE_SECONDS="$RADON_SETTLE_SECONDS_DEFAULT"
RADON_VALID_AFTER_TS=""

OWNER_EMAIL=""
EMAIL_CONFIRMED="0"
EMAIL_CONFIRM_TOKEN=""
LAST_REPORTED_IP=""
LAST_REPORT_TS=""
REPORT_IP_URL=""

# Site Report (persisted in config; always clear "last sent" memory on reset/install)
LAST_SITE_REPORT_TS="0"
LAST_SITE_REPORT_SHA1=""

AIR_MAC=""
AIR_MODE="$AIR_MODE_DEFAULT"
AIR_MFG_ID="$AIR_MFG_ID_DEFAULT"

if [ "$MODE" = "ensure" ]; then
  # Only create file if missing; do not wipe existing.
  if [ -f "$CONFIG" ]; then
    exit 0
  fi
fi

mkdir -p "$(dirname "$CONFIG")"

tmp="$(mktemp)"
cat >"$tmp" <<EOF
# RadonBox device config

# --- Device discovery ---
SHELLY_HOST=${SHELLY_HOST}
SHELLY_SWITCH_ID=${SHELLY_SWITCH_ID}

# Airthings BLE: leave AIR_MAC blank; discover each run via manufacturer id.
AIR_MAC=
AIR_MFG_ID=${AIR_MFG_ID}
AIR_MODE=${AIR_MODE}

# --- Radon control defaults ---
RADON_ON_THRESHOLD=${RADON_ON_THRESHOLD}
RADON_OFF_THRESHOLD=${RADON_OFF_THRESHOLD}
RADON_EXECUTION_FREQUENCY=${RADON_EXECUTION_FREQUENCY}
EVENING_FAN_OFF=${EVENING_FAN_OFF}

# --- Installation metadata / settling ---
INSTALL_TS=
INSTALL_ISO=
RADON_SETTLE_SECONDS=${RADON_SETTLE_SECONDS}
RADON_VALID_AFTER_TS=

# --- IP-Show / report-ip.py (confirm-first design) ---
OWNER_EMAIL=
EMAIL_CONFIRMED=0
EMAIL_CONFIRM_TOKEN=
LAST_REPORTED_IP=
LAST_REPORT_TS=
REPORT_IP_URL=

# --- Site Report (opt-in) ---
SITE_REPORT_ENABLED=${SITE_REPORT_ENABLED}
LAST_SITE_REPORT_TS=0
LAST_SITE_REPORT_SHA1=
EOF

# If we're in install mode, stamp install fields now.
if [ "$MODE" = "install" ]; then
  # Wait for NTP sync (Pi typically has no RTC; AP-mode time may be wrong).
  for _i in $(seq 1 120); do
    if timedatectl show -p NTPSynchronized --value 2>/dev/null | grep -qx "yes"; then
      break
    fi
    sleep 1
  done

  now_ts="$(date +%s)"
  now_iso="$(date --iso-8601=seconds 2>/dev/null || date -Iseconds)"
  valid_after="$((now_ts + RADON_SETTLE_SECONDS_DEFAULT))"

  # Rewrite install lines in tmp (simple sed)
  sed -i "s/^INSTALL_TS=.*/INSTALL_TS=${now_ts}/" "$tmp"
  sed -i "s/^INSTALL_ISO=.*/INSTALL_ISO=${now_iso}/" "$tmp"
  sed -i "s/^RADON_SETTLE_SECONDS=.*/RADON_SETTLE_SECONDS=${RADON_SETTLE_SECONDS_DEFAULT}/" "$tmp"
  sed -i "s/^RADON_VALID_AFTER_TS=.*/RADON_VALID_AFTER_TS=${valid_after}/" "$tmp"
fi

# Install atomically
install -m 0644 "$tmp" "$CONFIG"
rm -f "$tmp"
sync
