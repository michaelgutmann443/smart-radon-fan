#!/usr/bin/env python3
"""
RadonBox Wi-Fi onboarding portal 

"""

import os
import time
import socket
import subprocess
import re
import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from flask import Flask, request, render_template, render_template_string, send_file, redirect, jsonify, make_response, redirect
from urllib.parse import urlparse
LOG_DIR = "/var/log/radonbox"


def log(msg: str):
    """Append message to onboard.log (and stdout). Safe early definition."""
    try:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{ts}] {msg}"
        print(line, flush=True)
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(ONBOARD_LOG, "a", encoding="utf-8", errors="replace") as f:
            f.write(line + "\n")
    except Exception:
        try:
            print(msg, flush=True)
        except Exception:
            pass


def now_iso():
    """Return current local time as ISO-8601 string with timezone offset."""
    try:
        import datetime as _dt
        return _dt.datetime.now().astimezone().isoformat(timespec="seconds")
    except Exception:
        try:
            return str(datetime.datetime.now())
        except Exception:
            return ""


BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def host_only(s: str) -> str:
    """Return host/IP without scheme for display (e.g., http://1.2.3.4 -> 1.2.3.4)."""
    if not s:
        return ""
    s = s.strip()
    s = re.sub(r"^https?://", "", s, flags=re.IGNORECASE)
    return s.strip("/")


# ---------------------------
# Beta7 AP helpers
# ---------------------------

AP_SUBNET_PREFIX = "192.168.4."
ONBOARD_LAST_PATH = "/var/lib/radonbox/onboard-last.json"

def is_ap_request() -> bool:
    """True if the HTTP request is coming from the AP side."""
    try:
        ra = (request.remote_addr or "").strip()
        host = (request.host or "").strip()
        return ra.startswith(AP_SUBNET_PREFIX) or host.startswith(AP_SUBNET_PREFIX)
    except Exception:
        return False

def save_last_onboard(ssid: str, psk: str, shelly_host: str, notify_email: str, site_report_enabled: str = "1") -> None:
    try:
        os.makedirs(os.path.dirname(ONBOARD_LAST_PATH), exist_ok=True)
        data = {
            "ssid": (ssid or "").strip(),
            "psk": (psk or "").strip(),
            "shelly_host": (shelly_host or "").strip(),
            "notify_email": _normalize_email(notify_email),
            "site_report_enabled": "1" if str(site_report_enabled).strip() in ("1","true","on","yes") else "0",
            "ts": time.time(),
        }
        with open(ONBOARD_LAST_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception as e:
        log(f"[onboard-last] save failed: {e}")

def load_last_onboard() -> dict:
    try:
        with open(ONBOARD_LAST_PATH, "r", encoding="utf-8") as f:
            return json.load(f) or {}
    except Exception:
        return {}

def _html_subst(template: str, **kwargs) -> str:
    """Simple placeholder substitution without str.format().

    We avoid str.format() because the embedded CSS/JS in our HTML contains lots
    of braces which would break format parsing.
    Placeholders must be literal tokens like {css}, {ssid}, etc.
    """
    out = template
    for k, v in kwargs.items():
        out = out.replace("{" + k + "}", str(v))
    return out


def get_sta_if() -> str:
    # Beta7 dual-radio: STA lives on wlan1 (USB). Fallback to wlan0 if needed.
    return "wlan1" if os.path.exists("/sys/class/net/wlan1") else "wlan0"

def get_iface_ipv4(ifname: str) -> str:
    try:
        rc, out, _ = run_cmd(["ip", "-4", "-br", "addr", "show", "dev", ifname], timeout=5)
        if rc == 0 and out:
            parts = out.strip().split()
            for p in parts:
                if "/" in p and p.count(".") == 3:
                    return p.split("/")[0]
    except Exception:
        pass
    return ""

def get_sta_ssid(ifname: str) -> str:
    try:
        rc, out, _ = run_cmd(["nmcli", "-t", "-f", "ACTIVE,SSID,DEVICE", "dev", "wifi"], timeout=10)
        if rc == 0 and out:
            for line in out.splitlines():
                parts = line.split(":", 2)
                if len(parts) == 3 and parts[0] == "yes" and parts[2] == ifname:
                    return parts[1]
    except Exception:
        pass
    return ""

def normalize_status_for_ui(data: dict) -> dict:
    """Normalize device-status JSON for consistent Status page display.

    Policy:
      - SmartPlug line: 'Shelly (<host>)' where <host> is host-only (no scheme).
      - RadonMeter line: '<device name> (<MAC>)' when available, else best-effort.
      - Never duplicate MACs or show both dashed/colon forms.
    """
    try:
        cfg = read_kv_conf(RADON_CONFIG)

        # ---- SmartPlug (Shelly): prefer RADON_CONFIG (source of truth) ----
        cfg_shelly = host_only((cfg.get("SHELLY_HOST") or "").strip())
        shelly = data.get("shelly") if isinstance(data.get("shelly"), dict) else {}
        host = cfg_shelly or host_only(str(shelly.get("host") or ""))
        if host:
            shelly["host"] = host
            shelly.setdefault("state", "CONFIGURED")
            shelly.setdefault("level", "info")
            shelly["text"] = f"Shelly ({host})"
            data["shelly"] = shelly

        # ---- RadonMeter (Airthings): show brand/model + MAC (single canonical format) ----
        air = data.get("airthings") if isinstance(data.get("airthings"), dict) else {}
        nm_raw = (air.get("name") or "").strip()
        mac = (air.get("mac") or "").strip()

        # Some upstream paths mistakenly put a MAC-like string into 'name' (e.g., AC-4D-...).
        # Treat that as "no friendly name".
        is_mac_like = bool(re.match(r"^[0-9A-Fa-f]{2}([:-][0-9A-Fa-f]{2}){5}$", nm_raw))
        nm = "" if is_mac_like else nm_raw

        # If upstream didn't provide a friendly name, use a sensible product label.
        if not nm and (mac or air):
            # If we ever add model detection, this can become "Airthings Wave2", etc.
            nm = "Airthings"

        # Only show ONE MAC representation (use the colon-form from JSON).
        if nm and mac:
            air["text"] = f"{nm} ({mac})"
        elif nm:
            air["text"] = nm
        elif mac:
            air["text"] = mac

        if air:
            data["airthings"] = air

    except Exception:
        pass
    return data


# ---------------------------
# Paths / constants
# ---------------------------

BOOT_FLAG = "/etc/radonbox/boot-mode"
ONBOARD_LOG = "/var/log/radonbox/onboard.log"

RADON_DIR = "/opt/radonbox/current/radon-min"

STATUS_UPDATER = "/opt/radonbox/current/radon-min/radon-status-update.py"
RADON_DEVICES_INIT = "/opt/radonbox/current/radon-min/radon-devices-init.sh"
RUN_RADON = "/opt/radonbox/current/radon-min/run-radon.sh"

DEVICE_STATUS_JSON = "/etc/radonbox/device-status.json"

# Update / Support status (best-effort; file may not exist on fresh installs)
UPDATE_STATUS_PATH = "/var/lib/radonbox/update-status.json"
UPDATE_LOG_PATH = "/var/log/radonbox/update.log"

# Updater launcher script (invoked via systemd-run)
UPDATER_PATH = "/usr/local/sbin/radonbox-update.sh"

def read_update_status():
    """Read updater status JSON (best-effort). Returns dict or {}."""
    try:
        if os.path.exists(UPDATE_STATUS_PATH):
            with open(UPDATE_STATUS_PATH, "r", encoding="utf-8", errors="replace") as f:
                return json.load(f) or {}
    except Exception:
        pass
    return {}

def write_update_status(d: dict):
    """Persist updater status JSON (best-effort)."""
    try:
        os.makedirs(os.path.dirname(UPDATE_STATUS_PATH), exist_ok=True)
        with open(UPDATE_STATUS_PATH, "w", encoding="utf-8") as f:
            json.dump(d or {}, f, indent=2, sort_keys=True)
    except Exception:
        pass

def tail_file(path, lines=40):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            data = f.readlines()
        return "".join(data[-lines:])
    except Exception:
        return ""


RB_FLAG = os.path.join(RADON_DIR, "rb-flag.sh")
RB_HOSTNAME_FILE = "/boot/rb-hostname"

RADON_CONFIG = "/etc/radonbox/radon-config.conf"
RADON_CONFIG_INIT = "/opt/radonbox/current/radon-min/radon-config-init.sh"
CHART_PATH = os.path.join(RADON_DIR, "radon-chart.png")

LATEST_URL_DEFAULT = "https://www.smartradonfan.com/updates/dev/latest.json"

# Pi-side IP reporting helper (calls your DigitalOcean service)
REPORT_IP = "/opt/radonbox/current/bin/report-ip.py"
# Pi-side Site-Report helper (posts status snapshot)
REPORT_SITE = "/opt/radonbox/current/bin/site-report.py"

# Config keys we will store
SRF_NOTIFY_EMAIL_KEY = "OWNER_EMAIL"
SRF_SITE_REPORT_ENABLED_KEY = "SITE_REPORT_ENABLED"
SRF_SITE_REPORT_FREQ_KEY = "SITE_REPORT_FREQ"
SITE_REPORT_CRON = "/etc/cron.d/radonbox-site-report"
SITE_REPORT_LOG = "/var/log/radonbox/site-report.log"
SITE_REPORT_TRIGGER_LOG = "/var/log/radonbox/site-report-trigger.log"
SITE_REPORT_SCRIPT = "/opt/radonbox/current/bin/site-report.py"

# Basic email validation (intentionally permissive)
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# Ensure Flask finds templates/system.html (your WorkingDirectory is RADON_DIR)
app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static"),
)




# ---------------------------
# Jinja helpers
# ---------------------------

@app.template_filter("humanize_text_timestamps")
def humanize_text_timestamps(s: str = "") -> str:
    """
    Replace embedded ISO-8601 timestamps in free-form text with MM/DD/YYYY, H:MM AM/PM.
    Example: 2026-02-24T09:26:08-08:00 -> 02/24/2026, 9:26 AM
    """
    try:
        if not s:
            return ""

        iso_re = re.compile(
            r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}"
            r"(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2}))"
        )

        def repl(m):
            return fmt_ts_str(m.group(1))

        return iso_re.sub(repl, str(s))
    except Exception:
        return str(s) if s is not None else ""


@app.template_filter("human_state")
def human_state(value):
    """Render ALL_CAPS_UNDERSCORE status strings in a human-friendly way.

    Defensive: imports are local; never raises.
    """
    try:
        import re as _re  # local import for safety
        s = (str(value) if value is not None else "").strip()
        if not s:
            return ""
        s = s.replace("_", " ").replace("-", " ")
        s = " ".join(s.split())
        s = s.title()

        # Simple word-boundary replacements for common acronyms/terms
        fixes = {
            "Ip": "IP",
            "Ap": "AP",
            "Ssid": "SSID",
            "Wifi": "Wi‑Fi",
            "Wi Fi": "Wi‑Fi",
            "Ble": "BLE",
            "Api": "API",
            "Usb": "USB",
            "Cpu": "CPU",
            "Rssi": "RSSI",
            "Ok": "OK",
            "Id": "ID",
        }
        for a, b in fixes.items():
            s = _re.sub(rf"\b{_re.escape(a)}\b", b, s)
        return s
    except Exception:
        # Last-resort fallback: don't break the page
        try:
            return str(value)
        except Exception:
            return ""

def fmt_ts_str(value):
    """Format ISO timestamp or epoch seconds into 'MM/DD/YYYY, H:MM AM/PM' (local time)."""
    try:
        import datetime as _dt
        if value is None:
            return ""
        # epoch seconds (int/float or numeric string)
        if isinstance(value, (int, float)):
            dt = _dt.datetime.fromtimestamp(float(value), tz=_dt.datetime.now().astimezone().tzinfo)
            return dt.strftime("%m/%d/%Y, %-I:%M %p")
        s = str(value).strip()
        if not s:
            return ""
        if re.fullmatch(r"\d+(?:\.\d+)?", s):
            dt = _dt.datetime.fromtimestamp(float(s), tz=_dt.datetime.now().astimezone().tzinfo)
            return dt.strftime("%m/%d/%Y, %-I:%M %p")
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = _dt.datetime.fromisoformat(s)
        if dt.tzinfo is not None:
            dt = dt.astimezone()
        return dt.strftime("%m/%d/%Y, %-I:%M %p")
    except Exception:
        try:
            return str(value)
        except Exception:
            return ""

@app.template_filter("fmt_ts")
def fmt_ts(value):
    return fmt_ts_str(value)

def run_cmd(cmd, timeout=30):
    cmd_str = " ".join(cmd)
    log(f"[run_cmd] exec: {cmd_str} (timeout={timeout}s)")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if proc.stdout:
            for line in proc.stdout.splitlines():
                log(f"[run_cmd] stdout: {line}")
        if proc.stderr:
            for line in proc.stderr.splitlines():
                log(f"[run_cmd] stderr: {line}")
        log(f"[run_cmd] rc={proc.returncode}")
        return proc.returncode, proc.stdout, proc.stderr
    except subprocess.TimeoutExpired as e:
        log(f"[run_cmd] TIMEOUT: {cmd_str}")
        return 124, "", f"TimeoutExpired: {e}"
    except Exception as e:
        log(f"[run_cmd] EXCEPTION {cmd_str}: {e!r}")
        return 1, "", str(e)

def status_patch(patch: dict) -> None:
    """Best-effort device-status update (never throws)."""
    try:
        if os.path.exists(STATUS_UPDATER):
            subprocess.run(
                [STATUS_UPDATER, json.dumps(patch)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
            )
    except Exception:
        pass
# ---------------------------
# Beta7 dual-radio boot self-heal
# ---------------------------

def _is_installed_best_effort() -> bool:
    """Heuristic: treat device as installed if we have a non-empty config or a status file."""
    try:
        if os.path.exists(DEVICE_STATUS_JSON):
            return True
    except Exception:
        pass
    try:
        if not is_blank_device_config():
            return True
    except Exception:
        pass
    return False


def _ensure_managed_autoconnect_best_effort() -> None:
    """On boot (e.g., 3am cron reboot), ensure the STA interface auto-connects.

    In dual-radio, /etc/radonbox/boot-mode may still say 'ap' (legacy single-radio),
    but we still want the STA (wlan1) to come up on the home network automatically.
    This routine is safe to run repeatedly and never raises.
    """
    try:
        sta_if = get_sta_if()
        log(f"[boot-heal] Ensuring managed auto-connect on {sta_if}")

        # If we already have a non-AP IPv4 on STA, we're done.
        ip_now = get_iface_ipv4(sta_if)
        if ip_now and (not ip_now.startswith(AP_SUBNET_PREFIX)) and (not ip_now.startswith("169.254.")):
            log(f"[boot-heal] STA already has IPv4 {ip_now}; OK")
            return

        # Make sure NetworkManager is running and owns the STA interface
        run_cmd(["/usr/bin/sudo", "systemctl", "enable", "NetworkManager"], timeout=30)
        run_cmd(["/usr/bin/sudo", "systemctl", "restart", "NetworkManager"], timeout=60)
        run_cmd(["/usr/bin/sudo", "nmcli", "dev", "set", sta_if, "managed", "yes"], timeout=20)
        run_cmd(["/usr/bin/sudo", "nmcli", "radio", "wifi", "on"], timeout=20)

        # Best-effort: ask NM to (re)connect the device. This uses any saved connection profile.
        run_cmd(["/usr/bin/sudo", "nmcli", "dev", "connect", sta_if], timeout=60)

        # Give it a moment, then re-check.
        time.sleep(4)
        ip_now = get_iface_ipv4(sta_if)
        ssid_now = get_sta_ssid(sta_if)
        log(f"[boot-heal] After nmcli dev connect: ssid={ssid_now!r} ip={ip_now!r}")

        # If still no managed IP, try bringing up the most-recent autoconnect Wi-Fi profile on this iface.
        if not ip_now or ip_now.startswith(AP_SUBNET_PREFIX) or ip_now.startswith("169.254."):
            rc, out, _ = run_cmd(["/usr/bin/sudo", "nmcli", "-t", "-f", "NAME,TYPE,AUTOCONNECT", "con", "show"], timeout=20)
            cand = None
            if rc == 0 and out:
                for line in out.splitlines():
                    parts = line.split(":")
                    if len(parts) >= 3 and parts[1] == "802-11-wireless":
                        # Prefer AUTOCONNECT yes; else first Wi-Fi profile
                        if parts[2] == "yes":
                            cand = parts[0]
                            break
                        if cand is None:
                            cand = parts[0]
            if cand:
                log(f"[boot-heal] Trying nmcli con up {cand!r} on {sta_if}")
                run_cmd(["/usr/bin/sudo", "nmcli", "con", "up", "id", cand, "ifname", sta_if], timeout=60)
                time.sleep(4)
                ip_now = get_iface_ipv4(sta_if)
                ssid_now = get_sta_ssid(sta_if)
                log(f"[boot-heal] After con up: ssid={ssid_now!r} ip={ip_now!r}")

    except Exception as e:
        log(f"[boot-heal] EXCEPTION: {e!r}")


def _boot_heal_thread() -> None:
    try:
        # Let services settle after reboot (USB Wi-Fi dongle + NM)
        time.sleep(20)

        # Only attempt if device appears installed; avoid interfering with first-time setup.
        if not _is_installed_best_effort():
            log("[boot-heal] Not installed yet; skipping managed auto-connect")
            return

        _ensure_managed_autoconnect_best_effort()
    except Exception as e:
        try:
            log(f"[boot-heal] thread exception: {e!r}")
        except Exception:
            pass


# Start boot self-heal in background (safe if it runs on every boot)
threading.Thread(target=_boot_heal_thread, daemon=True).start()



# ---------------------------
# Boot mode / hostname helpers
# ---------------------------

def default_unique_hostname(prefix="radonbox"):
    """
    Generate a stable, collision-resistant hostname based on wlan0 MAC.
    Example: radonbox-2b45
    """
    try:
        with open("/sys/class/net/wlan0/address") as f:
            mac = f.read().strip().lower().replace(":", "")
        suffix = mac[-4:]
        return f"{prefix}-{suffix}"
    except Exception:
        return prefix

def get_boot_mode() -> str:
    try:
        with open(BOOT_FLAG, "r", encoding="utf-8") as f:
            mode = f.read().strip().lower()
            if mode in ("ap", "managed"):
                return mode
    except FileNotFoundError:
        pass
    return "ap"

def set_boot_mode(mode: str) -> None:
    mode = (mode or "").strip().lower()
    if mode not in ("ap", "managed"):
        log(f"[set_boot_mode] invalid mode requested: {mode}")
        return
    log(f"[set_boot_mode] setting boot mode to {mode!r}")
    run_cmd([os.path.join(RADON_DIR, "rb-flag.sh"), mode], timeout=10)

def normalize_hostname(s: str) -> str:
    return (s or "").strip().lower()

def is_valid_hostname(h: str) -> bool:
    if not (1 <= len(h) <= 63):
        return False
    if h.startswith("-") or h.endswith("-"):
        return False
    return re.fullmatch(r"[a-z0-9-]+", h) is not None

def apply_hostname(new_hostname: str) -> bool:
    """
    Persist + apply hostname immediately.
    Note: Avahi may still rename if there is a conflict on the LAN.
    """
    try:
        with open(RB_HOSTNAME_FILE, "w", encoding="utf-8") as f:
            f.write(new_hostname + "\n")

        rc, _, err = run_cmd(["/usr/bin/hostnamectl", "set-hostname", new_hostname], timeout=10)
        if rc != 0:
            log(f"[hostname] WARNING: hostnamectl failed rc={rc}: {err}")

        # Keep /etc/hosts consistent for 127.0.1.1
        hosts_path = "/etc/hosts"
        try:
            with open(hosts_path, "r", encoding="utf-8") as f:
                lines = f.read().splitlines()
        except FileNotFoundError:
            lines = []

        new_lines = []
        replaced = False
        for line in lines:
            if line.strip().startswith("127.0.1.1"):
                new_lines.append(f"127.0.1.1\t{new_hostname}")
                replaced = True
            else:
                new_lines.append(line)
        if not replaced:
            new_lines.append(f"127.0.1.1\t{new_hostname}")

        with open(hosts_path, "w", encoding="utf-8") as f:
            f.write("\n".join(new_lines).rstrip() + "\n")

        log(f"[hostname] Applied hostname: {new_hostname}")
        return True
    except Exception as e:
        log(f"[hostname] ERROR applying hostname '{new_hostname}': {e!r}")
        return False

def get_pi_hostname() -> str:
    try:
        name = socket.gethostname().strip()
        return name or "radonbox"
    except Exception:
        return "radonbox"

def get_wlan0_ipv4() -> str:
    """
    Best-effort: returns the current wlan0 IPv4 address (e.g., 192.168.1.58),
    or "" if not available.
    """
    try:
        out = subprocess.check_output(
            ["/usr/sbin/ip", "-4", "addr", "show", "dev", "wlan0"],
            text=True,
            stderr=subprocess.DEVNULL,
        )
        m = re.search(r"\binet\s+(\d+\.\d+\.\d+\.\d+)\b", out)
        return m.group(1) if m else ""
    except Exception:
        return ""


# ---------------------------
# Config helpers
# ---------------------------

def read_kv_conf(path: str) -> dict:
    d = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                d[k.strip()] = v.strip()
    except FileNotFoundError:
        return {}
    except Exception as e:
        log(f"[conf] WARNING: failed reading {path}: {e!r}")
        return {}
    return d


def read_app_version() -> str:
    """Return portal version string from standard version files."""
    candidates = [
        "/opt/radonbox/current/portal/PORTAL_VERSION",
        "/opt/radonbox/current/PORTAL_VERSION",
        "/opt/radonbox/current/radon-min/PORTAL_VERSION",
        "/opt/radonbox/current/radon-min/VERSION",
        "/opt/radonbox/current/VERSION",
        "/etc/radonbox/version.txt",
    ]
    for p in candidates:
        try:
            if os.path.exists(p):
                with open(p, "r", encoding="utf-8", errors="replace") as f:
                    s = f.read().strip()
                if s:
                    return s.splitlines()[0].strip()
        except Exception:
            pass
    return "unknown"


def set_kv_conf_value(path: str, key: str, value: str) -> None:
    """Set or remove a KEY=VALUE line in a simple kv config file.
    Preserves other lines and comments. Writes atomically.
    If value is empty, removes the key.
    """
    value = (value or "").strip()
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.read().splitlines()
    except FileNotFoundError:
        lines = []

    out = []
    found = False
    for raw in lines:
        if raw.strip().startswith(f"{key}="):
            found = True
            if value:
                out.append(f"{key}={value}")
        else:
            out.append(raw)

    if (not found) and value:
        if out and out[-1].strip() != "":
            out.append("")
        out.append(f"{key}={value}")

    tmp = f"{path}.tmp"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(tmp, "w", encoding="utf-8") as f:
        f.write("\n".join(out).rstrip() + "\n")
    os.replace(tmp, path)

def is_blank_device_config() -> bool:
    cfg = read_kv_conf(RADON_CONFIG)
    for k in ("SHELLY_HOST", "AIR_MAC", "SHELLY_SWITCH_ID"):
        if not cfg.get(k):
            return True
    return False

def _normalize_email(s: str) -> str:
    s = (s or "").strip()
    return s

def _is_valid_email(s: str) -> bool:
    s = _normalize_email(s)
    if not s:
        return True  # blank is allowed (optional)
    return EMAIL_RE.match(s) is not None

def _run_config_init_best_effort(mode: str) -> None:
    """Best-effort config init/reset helper. Never raises."""
    try:
        mode = (mode or "").strip()
        if mode not in ("ensure", "install", "factory-reset"):
            mode = "ensure"
        if not os.path.exists(RADON_CONFIG_INIT):
            log(f"[config-init] SKIP: not found at {RADON_CONFIG_INIT}")
            return
        args = ["/usr/bin/sudo", RADON_CONFIG_INIT, f"--{mode}"]
        rc, out, err = run_cmd(args, timeout=60)
        if out:
            log(f"[config-init] stdout: {out.strip()}")
        if err:
            log(f"[config-init] stderr: {err.strip()}")
        if rc != 0:
            log(f"[config-init] WARNING: rc={rc}")
        else:
            log(f"[config-init] OK mode={mode}")
    except Exception as e:
        log(f"[config-init] EXCEPTION: {e!r}")


# ---------------------------
# Wi-Fi onboarding logic
# ---------------------------

def wait_for_wifi_ssid(target_ssid: str, timeout: int = 60, ifname: str = "") -> bool:
    target_ssid = (target_ssid or "").strip()
    ifname = (ifname or "").strip()
    if not target_ssid:
        return False

    deadline = time.time() + timeout
    log(f"[wait_for_wifi_ssid] waiting up to {timeout}s for SSID={target_ssid!r} ifname={ifname!r}")

    # If ifname is provided, include DEVICE so we can match the interface.
    fields = "ACTIVE,SSID,DEVICE" if ifname else "ACTIVE,SSID"
    while time.time() < deadline:
        rc, out, _ = run_cmd(["nmcli", "-t", "-f", fields, "dev", "wifi"], timeout=10)
        if rc == 0 and out:
            for line in out.splitlines():
                # With DEVICE included, line format is: yes:<ssid>:<dev>
                parts = line.split(":", 2)
                if len(parts) >= 2 and parts[0] == "yes" and parts[1] == target_ssid:
                    if ifname:
                        if len(parts) == 3 and parts[2] == ifname:
                            log(f"[wait_for_wifi_ssid] Connected to SSID={target_ssid!r} on {ifname}")
                            return True
                    else:
                        log(f"[wait_for_wifi_ssid] Connected to SSID={target_ssid!r}")
                        return True
        time.sleep(3)

    log(f"[wait_for_wifi_ssid] timeout waiting for SSID={target_ssid!r} ifname={ifname!r}")
    return False

def _wifi_list_ssids(ifname: str = "wlan0") -> list[str]:
    """
    Best-effort list of visible SSIDs (may be incomplete, but useful for gating connect).
    Returns de-duplicated SSIDs preserving order.
    """
    rc, out, _ = run_cmd(["nmcli", "-t", "-f", "SSID", "dev", "wifi", "list", "ifname", ifname], timeout=15)
    ssids: list[str] = []
    if rc == 0 and out:
        seen = set()
        for raw in out.splitlines():
            s = (raw or "").strip()
            if not s:
                continue
            if s not in seen:
                ssids.append(s)
                seen.add(s)
    return ssids


def _wifi_rescan_until_visible(target_ssid: str, ifname: str = "wlan0", timeout: int = 25) -> bool:
    """
    Force rescans and wait (with backoff) until target SSID appears in NM scan cache.
    This specifically avoids the race where 'nmcli dev wifi connect' fails with:
      'No network with SSID ... found.'
    """
    target_ssid = (target_ssid or "").strip()
    if not target_ssid:
        return False

    deadline = time.time() + max(1, int(timeout))
    backoff = [0.0, 0.8, 1.2, 2.0, 3.0, 4.0]

    i = 0
    while time.time() < deadline:
        # Rescan (best-effort)
        run_cmd(["nmcli", "dev", "wifi", "rescan", "ifname", ifname], timeout=20)

        ssids = _wifi_list_ssids(ifname=ifname)
        log(f"[wifi_scan] visible_count={len(ssids)} target_present={target_ssid in ssids}")

        if target_ssid in ssids:
            return True

        # Sleep with capped backoff
        sleep_s = backoff[i] if i < len(backoff) else 4.0
        i += 1
        if sleep_s:
            time.sleep(sleep_s)

    return False


def _wifi_connect_robust(ssid: str, psk: str, ifname: str = "wlan0") -> bool:
    """
    Robust Wi-Fi connect:
      - rescans and waits for SSID to enter NM cache
      - retries connect on the specific 'SSID not found' failure
      - final attempt uses 'hidden yes' to support hidden SSIDs
    Returns True if nmcli reports success; final truth still verified by wait_for_wifi_ssid().
    """
    ssid = (ssid or "").strip()
    psk = (psk or "").strip()
    if not ssid or not psk:
        return False

    # Give NM a fair chance to populate scan cache (prevents immediate "SSID not found")
    _wifi_rescan_until_visible(ssid, ifname=ifname, timeout=25)

    attempts = 3
    for attempt in range(1, attempts + 1):
        cmd = ["nmcli", "dev", "wifi", "connect", ssid, "password", psk, "ifname", ifname]
        # On last attempt, allow hidden SSID connects (harmless for broadcast SSIDs)
        if attempt == attempts:
            cmd += ["hidden", "yes"]

        rc, out, err = run_cmd(cmd, timeout=60)
        combined = (out or "") + "\n" + (err or "")

        if rc == 0:
            log(f"[wifi_connect] nmcli rc=0 (attempt {attempt}/{attempts})")
            return True

        # If this is the known race, rescan + retry.
        if "No network with SSID" in combined:
            log(f"[wifi_connect] SSID not found in scan cache (attempt {attempt}/{attempts}); rescanning and retrying")
            _wifi_rescan_until_visible(ssid, ifname=ifname, timeout=20)
            continue

        # Other failures (bad password, auth, etc.)—still allow retries, but log clearly.
        log(f"[wifi_connect] nmcli failed rc={rc} (attempt {attempt}/{attempts})")

        time.sleep(1.5)

    return False


def _trigger_report_ip_best_effort() -> None:
    """
    Best-effort call to Pi-side report-ip.py.
    Never raises. Logs stdout/stderr to ONBOARD_LOG.
    """
    try:
        if not os.path.exists(REPORT_IP):
            log(f"[report-ip] SKIP: not found at {REPORT_IP}")
            return
        rc, out, err = run_cmd(["/usr/bin/sudo", REPORT_IP, "--force"], timeout=60)
        if out:
            log(f"[report-ip] stdout: {out.strip()}")
        if err:
            log(f"[report-ip] stderr: {err.strip()}")
        if rc != 0:
            log(f"[report-ip] WARNING: rc={rc}")
        else:
            log("[report-ip] OK")
    except Exception as e:
        log(f"[report-ip] EXCEPTION: {e!r}")

def _trigger_report_site_best_effort() -> None:
    """
    Best-effort call to Pi-side report-site.py.
    Never raises. Logs stdout/stderr to ONBOARD_LOG.
    """
    try:
        if not os.path.exists(REPORT_SITE):
            log(f"[report-site] SKIP: not found at {REPORT_SITE}")
            return
        # Site report is optional; if disabled, script will no-op
        run_cmd([REPORT_SITE], timeout=30)
        log("[report-site] OK")
    except Exception as e:
        log(f"[report-site] WARNING: {e!r}")



def try_onboard(ssid: str, psk: str, shelly_host: str = "", notify_email: str = "", site_report_enabled: str = "1") -> bool:
    ssid = (ssid or "").strip()
    psk = (psk or "").strip()
    notify_email = _normalize_email(notify_email)
    log(f"[onboard] notify_email normalized={notify_email!r}")

    site_report_enabled = "1" if str(site_report_enabled).strip() in ("1","true","on","yes") else "0"
    log(f"[onboard] site_report_enabled normalized={site_report_enabled!r}")

    if not ssid or not psk:
        status_patch({"summary": {"state": "ERROR", "level": "error", "text": "Missing SSID or password"}})
        return False

    if not _is_valid_email(notify_email):
        status_patch({"summary": {"state": "ERROR", "level": "error", "text": "Invalid email address"}})
        return False

    # Persist email early (safe even in AP mode)
    try:
        if notify_email:
            log(f"[onboard] Saving {SRF_NOTIFY_EMAIL_KEY}={notify_email!r} into {RADON_CONFIG}")
            set_kv_conf_value(RADON_CONFIG, SRF_NOTIFY_EMAIL_KEY, notify_email)
            # New email implies unconfirmed until user clicks confirmation link
            set_kv_conf_value(RADON_CONFIG, "EMAIL_CONFIRMED", "0")
        else:
            log("[onboard] No notify_email provided; not saving email") 
    except Exception as e:
        log(f"[onboard] WARNING: failed saving email: {e!r}")


    # Persist Site-Report enable early (safe even in AP mode)
    try:
        log(f"[onboard] Saving {SRF_SITE_REPORT_ENABLED_KEY}={site_report_enabled!r} into {RADON_CONFIG}")
        set_kv_conf_value(RADON_CONFIG, SRF_SITE_REPORT_ENABLED_KEY, site_report_enabled)
    except Exception as e:
        log(f"[onboard] WARNING: failed saving site-report enabled: {e!r}")

    status_patch({
        "summary": {"state": "CONNECTING_WIFI", "level": "warn", "text": f"Connecting to Wi-Fi '{ssid}'..."},
        "wifi": {"state": "CONNECTING", "level": "warn", "ssid": ssid, "last_attempt_local": now_iso()},
        "meta": {"generated_local": now_iso()},
    })

    # Dual-radio: keep AP (wlan0) up; connect STA on wlan1 (USB dongle).
    sta_if = "wlan1" if os.path.exists("/sys/class/net/wlan1") else "wlan0"
    if sta_if != "wlan1":
        log("[onboard] WARNING: wlan1 not found; falling back to wlan0 (single-radio behavior)")
    log(f"[onboard] Connecting STA on {sta_if} (AP stays up)")

    # Bring up NetworkManager + connect (do NOT stop hostapd/dnsmasq)
    run_cmd(["systemctl", "enable", "NetworkManager"], timeout=30)
    run_cmd(["systemctl", "restart", "NetworkManager"], timeout=60)

    run_cmd(["nmcli", "dev", "set", sta_if, "managed", "yes"], timeout=20)
    run_cmd(["nmcli", "radio", "wifi", "on"], timeout=20)

    _wifi_connect_robust(ssid, psk, ifname=sta_if)
    if not wait_for_wifi_ssid(ssid, timeout=60, ifname=sta_if):
        status_patch({
            "summary": {"state": "ERROR", "level": "error", "text": f"Failed to connect to Wi-Fi '{ssid}'"},
            "wifi": {"state": "ERROR", "level": "error", "ssid": ssid},
            "meta": {"generated_local": now_iso()},
        })
        return False

    status_patch({
        "summary": {"state": "WIFI_CONNECTED", "level": "ok", "text": f"Connected to Wi-Fi '{ssid}'"},
        "wifi": {"state": "CONNECTED", "level": "ok", "ssid": ssid, "last_ok_local": now_iso()},
        "meta": {"generated_local": now_iso()},
    })

    # Initialize/refresh baseline device config and stamp installation settle window
    # (preserves knobs like thresholds/Shelly if present)
    try:
        _run_config_init_best_effort("install")
    except Exception as e:
        log(f"[config-init] SKIP: {e!r}")
    
    # Make next boot managed
    log("[onboard] Dual-radio: skipping set_boot_mode('managed')")

    # If installer provided a Shelly address/IP, prefer it.
    shelly_host = (shelly_host or "").strip()
    if shelly_host:
        try:
            log(f"[onboard] Pre-seeding SHELLY_HOST={shelly_host!r} into {RADON_CONFIG}")
            set_kv_conf_value(RADON_CONFIG, "SHELLY_HOST", shelly_host)
            set_kv_conf_value(RADON_CONFIG, "SHELLY_SWITCH_ID", "")
        except Exception as e:
            log(f"[onboard] WARNING: failed pre-seeding SHELLY_HOST: {e!r}")

    # Ensure SITE_REPORT_ENABLED is present AFTER config-init --install (config-init may rewrite the file)
    try:
        log(f"[onboard] Re-saving {SRF_SITE_REPORT_ENABLED_KEY}={site_report_enabled!r} into {RADON_CONFIG} (post config-init)")
        set_kv_conf_value(RADON_CONFIG, SRF_SITE_REPORT_ENABLED_KEY, site_report_enabled)
    except Exception as e:
        log(f"[onboard] WARNING: failed re-saving site-report enabled post config-init: {e!r}")

    # Ensure OWNER_EMAIL is present AFTER config-init --install (config-init may rewrite the file)
    try:
        if notify_email:
            log(f"[onboard] Re-saving {SRF_NOTIFY_EMAIL_KEY}={notify_email!r} into {RADON_CONFIG} (post config-init)")
            set_kv_conf_value(RADON_CONFIG, SRF_NOTIFY_EMAIL_KEY, notify_email)
    except Exception as e:
        log(f"[onboard] WARNING: failed re-saving email post config-init: {e!r}")

    # Trigger report-ip.py immediately after Wi-Fi success
    if notify_email:
        status_patch({"summary": {"state": "SENDING_EMAIL", "level": "warn", "text": "Sending confirmation email..."}})
        log("[onboard] Running IP-Show report immediately after Wi-Fi connect")
        _trigger_report_ip_best_effort()

    # Now do device discovery (slow)
    if os.path.exists(RADON_DEVICES_INIT) and is_blank_device_config():
        status_patch({"summary": {"state": "DISCOVERING_DEVICES", "level": "warn", "text": "Initializing devices..."}})
        run_cmd(["/usr/bin/bash", RADON_DEVICES_INIT], timeout=300)

    status_patch({"summary": {"state": "POST_INSTALL", "level": "ok", "text": "Install complete — open /status"}})

    # Trigger Site-Report snapshot after onboarding finishes
    if site_report_enabled == "1":
        log("[onboard] Running Site-Report snapshot after onboarding")
        _trigger_report_site_best_effort()

    return True


# ---------------------------
# Status endpoints
# ---------------------------

def read_device_status() -> dict:
    try:
        with open(DEVICE_STATUS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Use the status file mtime as the "Updated" timestamp shown in the UI (more reliable than
        # any stale value embedded in status.json).
        try:
            st_mtime = os.path.getmtime(DEVICE_STATUS_JSON)
            meta = data.get("meta") or {}
            if not isinstance(meta, dict):
                meta = {}
            meta["generated_local"] = datetime.fromtimestamp(st_mtime).astimezone().isoformat()
            data["meta"] = meta
        except Exception:
            pass


        # UX consistency: if the radon meter is still being discovered, don't show Chart=READY
        air = data.get("airthings") or {}
        if not isinstance(air, dict):
            air = {}
        air_state = (air.get("state") or "").upper()
        read_obj = air.get("read") or {}
        if not isinstance(read_obj, dict):
            read_obj = {}
        last_ok = (air.get("last_ok_local") or read_obj.get("last_ok_local") or "").strip()
        summary_state = ((data.get("summary") or {}).get("state") or "").upper()
        chart = data.get("chart") or {}
        chart_state = (chart.get("state") or "").upper()

        # If status.json doesn't provide a chart state yet, infer it from the existence of the PNG.
        # This avoids the confusing "Chart Unknown" when /radon-chart.png is already renderable.
        try:
            if not isinstance(chart, dict):
                chart = {}
            if chart_state in {"", "UNKNOWN"}:
                if os.path.exists(CHART_PATH) and os.path.getsize(CHART_PATH) > 0:
                    chart = dict(chart)
                    chart["state"] = "READY"
                    chart["level"] = chart.get("level") or "ok"
                    data["chart"] = chart
                    chart_state = "READY"
                else:
                    chart = dict(chart)
                    chart.setdefault("state", "NOT_READY")
                    chart.setdefault("level", "info")
                    data["chart"] = chart
        except Exception:
            pass
        
        if chart_state == "READY":
            if ("DISCOVER" in summary_state) or (air_state in {"DISCOVERING", "NOT_FOUND", "UNKNOWN"}) or (air_state != "READ_OK" and not last_ok):
                chart = dict(chart)
                chart["state"] = "NOT_READY"
                chart["level"] = "warn"
                chart.setdefault("last_error", None)
                data["chart"] = chart

        # last radon reading timestamp
        try:
            meta = data.get("meta") or {}
            if not isinstance(meta, dict):
                meta = {}
            air = data.get("airthings") or {}
            if not isinstance(air, dict):
                air = {}
            last_local = (
                air.get("last_ok_local")
                or air.get("last_read_local")
                or air.get("last_ok_time_local")
                or air.get("last_reading_local")
            )
            if not last_local:
                try:
                    with open(LAST_READING_PATH, "r", encoding="utf-8") as f:
                        saved = json.load(f)
                    if isinstance(saved, dict):
                        last_local = saved.get("time")
                except FileNotFoundError:
                    pass
                except Exception:
                    pass

            if last_local:
                meta["last_radon_reading_local"] = str(last_local)
                data["meta"] = meta
                try:
                    os.makedirs(os.path.dirname(LAST_READING_PATH), exist_ok=True)
                    with open(LAST_READING_PATH, "w", encoding="utf-8") as f:
                        json.dump({"time": str(last_local)}, f)
                except Exception:
                    pass
        except Exception:
            pass

        data = normalize_status_for_ui(data)

        return data
    except FileNotFoundError:
        return {
            "summary": {"state": "SETUP_MODE", "level": "warn", "text": "Setup mode — enter Wi-Fi credentials at /"},
            "wifi": {"state": "AP_MODE", "level": "warn"},
            "shelly": {"state": "UNKNOWN", "level": "info"},
            "airthings": {"state": "UNKNOWN", "level": "info"},
            "chart": {"state": "NOT_READY", "level": "info", "path": CHART_PATH},
            "runtime": {"state": "IDLE", "level": "info"},
            "meta": {"generated_local": now_iso()},
        }
    except Exception as e:
        return {"summary": {"state": "ERROR", "level": "error", "text": f"Failed to read status: {e!r}"}}

NAV_HTML = """
<div class="row" style="margin-top:10px;">
  <a href="/status">Status</a>
  <a href="/setup">Setup</a>
  <a href="/radon-chart.png">Chart</a>
  <a href="/support">Support</a>
</div>
"""

STATUS_HTML = r"""

<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>{{ page_title }}</title>
    {{ css|safe }}
  </head>
  <body>
    {% if msg %}
    <div style="max-width:980px; margin: 10px auto 0; padding: 0 12px;">
      <div class="card" style="border-color:#cfe4ff;">
        <div class="muted">{{ msg }}</div>
      </div>
    </div>
    {% endif %}
<div class="topbar">
      <div class="brand">Smart Radon Fan</div>
      <div class="muted">Managed Mode</div>
    </div>

    <div class="wrap">
      <div class="tabs">
        <a class="tab {{ 'active' if active_tab=='status' else '' }}" href="/status">Status</a>
        <a class="tab {{ 'active' if active_tab=='setup' else '' }}" href="/setup">Setup</a>
        <a class="tab {{ 'active' if active_tab=='chart' else '' }}" href="/radon-chart.png">Chart</a>
        <a class="tab {{ 'active' if active_tab=='support' else '' }}" href="/support">Support</a>
      </div>

      <div class="card">
        <h2 style="margin:0 0 10px 0;">Status</h2>

        <div class="muted" style="margin-bottom:10px;">Version: {{ app_version }}. <span id="statusClock">—</span></div>

        {% set summary = st.get('summary') or {} %}
        <div class="grid2" style="margin-top:12px;">
          <div class="kv">
            <div class="k">Overall</div>
            <div class="v" style="display:flex; flex-direction:column; gap:4px;">
              <span class="badge {{ (summary.get('level') or 'info')|lower }}">{{ (summary.get('state') or 'UNKNOWN')|human_state }}</span>
              {% set meta = st.get('meta') or {} %}
              {% if meta.get('generated_local') %}<div class="muted">Updated: {{ meta.get('generated_local')|fmt_ts }}</div>{% endif %}
              {% if summary.get('text') %}<div class="muted">{{ summary.get('text')|humanize_text_timestamps }}</div>{% endif %}
            </div>
          </div>
        </div>

        <div class="grid2" style="margin-top:12px;">
          <div class="kv">
            <div class="k">RadonBox</div>
            <div class="v">
              <span class="badge {{ (rb_level or 'info')|lower }}">{{ (rb_state or 'UNKNOWN')|human_state }}</span>
              {% if rb_ip %}<div class="muted" style="margin-top:6px;">Address: <code>{{ rb_ip }}</code></div>{% endif %}
              {% if hostname %}<div class="muted" style="margin-top:6px;">Hostname: <code>{{ hostname }}</code></div>{% endif %}
            </div>
          </div>
        </div>

<div class="grid2" style="margin-top:12px;">
          <div class="kv">
            <div class="k">Airthings</div>
            {% set air = st.get('airthings') or {} %}
            <div class="v">
              <span class="badge {{ (air.get('level') or 'info')|lower }}">{{ (air.get('state') or 'UNKNOWN')|human_state }}</span>
              {% if air.get('mac') %}<div class="muted" style="margin-top:6px;">Address: <code>{{ air.get('mac') }}</code></div>{% endif %}
              {% if air.get('read') and air.get('read').get('short_term') is not none %}
                <div class="muted" style="margin-top:6px;">Latest radon: <code>{{ air.get('read').get('short_term') }}</code> / <code>{{ air.get('read').get('long_term') }}</code> pCi/L (short / long)</div>
              {% endif %}
              {% if (st.get('meta') or {}).get('last_radon_reading_local') %}
                <div class="muted" style="margin-top:6px;">Last read: {{ (st.get('meta') or {}).get('last_radon_reading_local')|fmt_ts }}</div>
              {% endif %}
              {% if air.get('last_error') %}
                <div class="muted" style="margin-top:6px;">Err: {{ air.get('last_error') }}</div>
              {% endif %}
            </div>
          </div>

          <div class="kv">
            <div class="k">Shelly / Fan</div>
            {% set sh = st.get('shelly') or {} %}
            <div class="v">
              <span class="badge {{ (sh.get('level') or 'info')|lower }}">{{ (sh.get('state') or 'UNKNOWN')|human_state }}</span>
              {% set sh_addr = sh.get('ip') or sh.get('ip_addr') or sh.get('host') or sh.get('addr') or sh.get('mac') %}
              {% if sh_addr %}<div class="muted" style="margin-top:6px;">Address: <code>{{ sh_addr }}</code></div>{% endif %}
              {% if sh.get('relay') is not none %}<div class="muted" style="margin-top:6px;">Relay: <code>{{ sh.get('relay') }}</code></div>{% endif %}
              {% if sh.get('last_error') %}<div class="muted" style="margin-top:6px;">Err: {{ sh.get('last_error') }}</div>{% endif %}
            </div>
          </div>
        </div>

        <div class="grid2" style="margin-top:12px;">
          <div class="kv">
            <div class="k">Chart</div>
            {% set ch = st.get('chart') or {} %}
            <div class="v">
              <span class="badge {{ (ch.get('level') or 'info')|lower }}">{{ (ch.get('state') or 'UNKNOWN')|human_state }}</span>
              {% if ch.get('last_error') %}<div class="muted" style="margin-top:6px;">Err: {{ ch.get('last_error') }}</div>{% endif %}
            </div>
          </div>
</div>

        <div class="grid2" style="margin-top:12px;">
          <div class="kv">
            <div class="k">Radon thresholds</div>
            <div class="v"><code>{{ radon_on }}</code> / <code>{{ radon_off }}</code> pCi/L</div>
          </div>
          <div class="kv">
            <div class="k">Execution frequency</div>
            <div class="v">{{ exec_freq_label }}</div>
          </div>
          <div class="kv">
            <div class="k">Site Report</div>
            <div class="v">{{ site_report_label }}</div>
          </div>
        </div>
      </div>

      <div class="footer">
        <span class="muted">Smart Radon Fan</span>
      </div>

      <script>
      (function () {

        function updateClock() {
          const el = document.getElementById("statusClock");
          if (!el) return;

          const now = new Date();
          const pad = (n) => String(n).padStart(2, "0");

          const ts =
            pad(now.getMonth() + 1) + "/" +
            pad(now.getDate()) + "/" +
            now.getFullYear() + " " +
            pad(now.getHours()) + ":" +
            pad(now.getMinutes()) + ":" +
            pad(now.getSeconds());

          el.textContent = ts;
        }

        document.addEventListener("DOMContentLoaded", () => {
          updateClock();
          setTimeout(() => setInterval(updateClock, 1000),
            1000 - (new Date().getMilliseconds()));
        });

      })();
      </script>
      
  </body>

</html>
"""


# ---------------------------
# HTML: setup + success + error
# ---------------------------

INDEX_HTML = """
<!doctype html>
<html>
  <head>
    <title>RadonBox Wi-Fi Setup</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial; margin: 18px; line-height: 1.45; }
    label { display:block; margin-top:12px; font-weight:800; }

    input, select {
      width:100%;
      padding:10px;
      border-radius:10px;
      border:1px solid #ccc;
      margin-top:6px;
      box-sizing: border-box;
    }

    button { margin-top:14px; padding:12px 14px; border-radius:10px; border:1px solid #0a66c2; background:#0a66c2; color:#ffffff; font-weight:900; width:100%; }
    .muted { color:#666; }
    code { background:#f3f3f3; padding:2px 6px; border-radius:6px; }
.pw-wrap { position: relative; width: 100%; }
.pw-wrap input { padding-right: 58px; }

.pw-toggle {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  width: 36px;
  height: 36px;
  border: none;
  background: transparent;
  padding: 0;
  margin: 0;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2;
  color: #444;
  -webkit-tap-highlight-color: transparent;
}
.pw-toggle:focus { outline: none; }
.pw-toggle svg { width: 20px; height: 20px; display: block; }

  </style>
  </head>
  <body>
    <h2 style="margin:0 0 8px 0;">RadonBox Wi-Fi Setup</h2>
    <div class="muted">
      You are connected to <b>RadonBox-Setup</b>.
    </div>

    <form method="post" action="/wifi">

      <label>Home Wi-Fi name (SSID)
        <input type="text" name="ssid" required>
      </label>

      <label>Home Wi-Fi password
        <div class="pw-wrap">
          <input id="psk" type="password" name="psk" required autocomplete="current-password" autocapitalize="none" spellcheck="false">
          <button type="button" class="pw-toggle" aria-label="Show password" aria-pressed="false" onclick="togglePw()">
            <svg class="pw-eye" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"></path>
              <circle cx="12" cy="12" r="3"></circle>
            </svg>
          </button>
        </div>
      </label>

      <label>Shelly plug address (optional)
        <input type="text" name="shelly_host" placeholder="e.g. ShellyPlugUSG4-XXXXXXXXXXXX.local or 192.168.1.10">
        <div class="muted" style="margin-top:6px;">
          Leave blank to auto-discover the Shelly plug on your home network.
        </div>
      </label>

      <button type="submit" style="padding:14px 18px; font-size:16px;">Connect</button>
    </form>

    <p class="muted" style="margin-top:14px;">
      After you tap <b>Connect</b>, RadonBox will switch to your home Wi-Fi and this setup page will disconnect.
      You’ll reopen the status page using the access URL shown on the next screen.
    </p>

    <script>
      function togglePw() {
        const el = document.getElementById("psk");
        const btn = document.querySelector(".pw-toggle");
        if (!el || !btn) return;

        const showing = (el.type === "text");
        el.type = showing ? "password" : "text";

        btn.setAttribute("aria-pressed", showing ? "false" : "true");
        btn.setAttribute("aria-label", showing ? "Show password" : "Hide password");

        btn.innerHTML = showing ? `<svg class="pw-eye" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"></path>
              <circle cx="12" cy="12" r="3"></circle>
            </svg>` : `<svg class="pw-eye-off" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a21.8 21.8 0 0 1 5.06-6.94"></path>
              <path d="M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a21.8 21.8 0 0 1-2.44 3.94"></path>
              <path d="M14.12 14.12a3 3 0 0 1-4.24-4.24"></path>
              <path d="M1 1l22 22"></path>
            </svg>`;
      }
    </script>

  </body>
</html>
"""


ERROR_HTML = """
<!doctype html>
<html>
  <head>
    <title>RadonBox Error</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
      body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial; margin: 18px; color:#b00020; }
      a { color: #0645ad; }
    </style>
  </head>
  <body>
    <h2>Onboarding Error</h2>
    <p>RadonBox could not connect to the Wi-Fi network with the credentials provided.</p>
    <p><a href="/">Back to setup</a></p>
  </body>
</html>
"""


# ---------------------------
# Beta7 AP-mode UI (Setup | Logs)
# ---------------------------

AP_TABS_CSS = """
<link rel="stylesheet" href="/static/portal.css">
"""

AP_SETUP_HTML = r"""


<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>RadonBox Setup</title>
    {css}
    <style>
      /* Copy button feedback */
      #copyBtn.copied { background: #eef6ff; border-color: #cfe4ff; }
    </style>
  </head>
  <body>
    <div class="topbar">
      <div class="brand">Smart Radon Fan</div>
      <div class="muted">AP Mode</div>
    </div>

    <div class="wrap">
      <div class="tabs">
        <a class="tab active" href="/onboard">Setup</a>
        <a class="tab" href="/onboard/logs">Logs</a>
      </div>

      <div class="card">
        <div class="row">
          <div><span class="pill">RadonBox-Setup</span></div>
          
        </div>

        <form method="POST" action="/wifi">
          <label>Wi‑Fi Network (SSID)</label>
          <input name="ssid" autocomplete="off" placeholder="MyHomeNetwork" value="{ssid}" required />

          <label>Wi‑Fi Password</label>
          <div style="display:flex; gap:10px; align-items:center;">
  <input id="wifi_password" name="psk" type="password" autocomplete="off" placeholder="••••••••" value="{psk}" required style="flex:1;" />
  <button type="button" class="btn secondary" style="padding:10px 12px; min-width:44px;" onclick="togglePw()" aria-label="Show or hide password"><span id="pw_eye">👁️</span></button>
</div>


           <label>Shelly IP / Hostname (for a specific smart plug use)</label>
          <input name="shelly_host" autocomplete="off" placeholder="192.168.1.50 or shellyplug.local" value="{shelly_host}" />

          <div style="margin-top:12px;">
            <button type="submit" style="padding:14px 18px; font-size:16px;">Connect</button>
          </div>
        </form>
      </div>

      <div class="card">
        <div class="row" style="align-items:center;">
          <div><b>Managed Connection</b></div>
          <div style="text-align:right"><span id="connBadge" class="pill warn">Checking…</span></div>
        </div>
        <div class="kv" style="margin-top:10px;">
          <div class="muted">Connected to:</div><div id="ssid">—</div>
          <div class="muted">Managed IP:</div>
          <div>
            <span id="ip">—</span>
            <button id="copyBtn" class="ghost" style="margin-left:10px; padding:6px 10px;" onclick="copyIp(); return false;">Copy</button>
          </div>
        </div>
        <div class="muted" style="margin-top:10px; font-size:13px;">
          Tip: After onboarding, switch your phone back to your home Wi‑Fi and enter the Managed IP in your browser.
        </div>
      </div>
    </div>

    <script>
      async function refreshState() {
        try {
          const r = await fetch("/api/onboard/state", {cache:"no-store"});
          const j = await r.json();
          document.getElementById("ssid").textContent = j.connected_ssid || "—";
          document.getElementById("ip").textContent = j.managed_ip || "—";
          const ok = !!j.managed_ip;
          const badge = document.getElementById("connBadge");
          if (ok) {
            badge.textContent = "Connected";
            badge.className = "pill ok";
          } else {
            badge.textContent = "Not connected";
            badge.className = "pill warn";
          }
        } catch (e) {}
      }
      function _copyText(text) {
  try {
    // iOS/Safari often blocks navigator.clipboard on http; use execCommand fallback.
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.top = "-1000px";
    ta.style.left = "-1000px";
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    if (ok) return true;
  } catch (e) {}
  // Best-effort modern path
  try { navigator.clipboard.writeText(text); return true; } catch (e) {}
  return false;
}
function copyIp() {
  const ip = document.getElementById("ip").textContent.trim();
  if (!ip || ip === "—") return;
  const url = ip + ":8080/status";
  const ok = _copyText(url);
  const btn = document.getElementById("copyBtn");
  if (btn) {
    const prev = btn.textContent;
    btn.textContent = ok ? "Copied!" : "Copy";
    if (ok) btn.classList.add("copied");
    setTimeout(() => {
      btn.textContent = prev;
      btn.classList.remove("copied");
    }, 1200);
  }
}

refreshState();
      setInterval(refreshState, 3000);
    </script>
  <script>
function togglePw() {
  const pw = document.getElementById('wifi_password');
  const eye = document.getElementById('pw_eye');
  if (!pw || !eye) return;
  const isHidden = (pw.type === 'password');
  pw.type = isHidden ? 'text' : 'password';
  eye.textContent = isHidden ? '🙈' : '👁️';
}
</script>
</body>
</html>


"""

AP_LOGS_HTML = """
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>RadonBox Logs</title>
    {css}
  </head>
  <body>
    <div class="topbar">
      <div class="brand">Smart Radon Fan</div>
      <div class="muted">AP Mode</div>
    </div>

    <div class="wrap">
      <div class="tabs">
        <a class="tab" href="/onboard">Setup</a>
        <a class="tab active" href="/onboard/logs">Logs</a>
      </div>

      <div class="card">
        <div class="row" style="align-items:center;">
          <div><b>Onboard Log</b></div>
          <div style="text-align:right; display:flex; gap:8px; justify-content:flex-end; flex-wrap:wrap;">
          </div>
        </div>
        <div class="muted" style="margin-top:8px;">Live view of {logpath}</div>
        <div style="margin-top:10px;">
          <textarea id="log" readonly spellcheck="false"></textarea>
        </div>
      </div>
    </div>

    <script>
      async function fetchLog() {
        const r = await fetch("/api/onboard/log", {cache:"no-store"});
        return await r.text();
      }
      async function refresh() {
        try {
          const t = await fetchLog();
          const el = document.getElementById("log");
          const atBottom = (el.scrollTop + el.clientHeight + 40) >= el.scrollHeight;
          el.value = t;
          if (atBottom) el.scrollTop = el.scrollHeight;
        } catch (e) {}
      }
      refresh();
      setInterval(refresh, 3000);
    </script>
  </body>
</html>
"""


# ---------------------------
# Managed-mode tabbed layout
# ---------------------------

MANAGED_TABS_CSS = AP_TABS_CSS  # reuse same visual system

MANAGED_SETUP_HTML = r"""
<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Smart Radon Fan</title>
    {css}
  </head>
  <body>
    <div class="topbar">
      <div class="brand">Smart Radon Fan</div>
      <div class="muted">Managed Mode</div>
    </div>

    <div class="wrap">
      <div class="tabs">
        <a class="tab" href="/status">Status</a>
        <a class="tab active" href="/setup">Setup</a>
        <a class="tab" href="/radon-chart.png">Chart</a>
        <a class="tab" href="/support">Support</a>
      </div>

      <div class="card">
        <div class="row" style="align-items:center;">
          <div><b>System Settings</b></div>
        </div>

        {banner}

        <form method="POST" action="/setup" style="margin-top:10px;">
          <label>Runs per day</label>
          <select name="execution_frequency">
            <option value="1" {freq1}>1/day (noon)</option>
            <option value="2" {freq2}>2/day (noon + midnight)</option>
          </select>

          <label>Radon ON threshold (pCi/L)</label>
          <input name="radon_on_threshold" inputmode="decimal" value="{on_thr}" />

          <label>Radon OFF threshold (pCi/L)</label>
          <input name="radon_off_threshold" inputmode="decimal" value="{off_thr}" />


          <hr style="margin:16px 0; border:none; border-top:1px solid #e5e7eb;" />
          
          <!-- Site Report: label above checkbox (matches threshold layout) -->
          <label style="margin-top:0;">Enable Site Report</label>
          <div style="margin-top:6px;">
            <input
              id="site_report_enabled"
              type="checkbox"
              name="site_report_enabled"
              value="1"
              {site_enabled_checked}
              style="margin:0; width:auto;"
            />
          </div>

          <div class="muted" style="margin-top:6px; font-size:13px;">
            Regularly sends a small status snapshot.
          </div>
          
          <label style="margin-top:12px;">Site Report Frequency</label>
          <select name="site_report_frequency">
            <option value="daily" {sr_daily}>Daily</option>
            <option value="weekly" {sr_weekly}>Weekly</option>
            <option value="monthly" {sr_monthly}>Monthly</option>
          </select>

          <div style="margin-top:12px;">
            <button type="submit" style="padding:12px 18px; font-size:16px;">Save</button>
          </div>
        </form>
      </div>

      <div class="card">
        <div class="row" style="align-items:center;">
          <div><b>Recovery</b></div>
          <div class="muted" style="text-align:left">Always available</div>
        </div>
        <div class="muted" style="margin-top:8px; font-size:13px;">
          If Wi‑Fi onboarding fails, join <b>RadonBox‑Setup</b> and go to <b>192.168.4.1:8080</b> for Setup/Logs.
        </div>
      </div>

      <div class="card">
        <div class="row" style="align-items:center;">
          <div><b>Factory Reset and Shutdown</b></div>
        </div>
        <div class="muted" style="margin-top:8px; font-size:13px;">
          Clears logs and charts, then safely powers off the RadonBox. When power is restored, it will restart in factory-fresh Setup mode.
        </div>
        <form method="post" action="/factory-reset-shutdown"
              onsubmit="return confirm('Factory Reset and Shutdown will clear logs/charts and power off now. Continue?');">
          <div class="actions" style="margin-top:12px;">
            <button type="submit" class="danger">Factory Reset &amp; Shutdown</button>
          </div>
        </form>
      </div>
    </div>
  </body>
</html>
"""
# ---------------------------
# Setup / Support / Factory (unchanged from your current)
# ---------------------------

SYSTEM_HTML = """
<!doctype html>
<html>
  <head>
    <title>RadonBox Setup</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
      body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial; margin: 18px; line-height: 1.45; max-width: 860px; }
      .card { border:1px solid #ddd; border-radius:14px; padding:14px; }
      label { display:block; margin-top:12px; font-weight:800; }
      input, select {
        width:100%;
        padding:10px;
        border-radius:10px;
        border:1px solid #ccc;
        margin-top:6px;
        box-sizing: border-box;   /* prevents overlap from padding/border */
      }

      button { margin-top:14px; padding:12px 14px; border-radius:10px; border:1px solid #0a66c2; background:#0a66c2; color:#fff; font-weight:900; }
      .danger { background:#b00020; border-color:#b00020; }

      .muted { color:#666; }
      code { background:#f3f3f3; padding:2px 6px; border-radius:6px; }
      .row { margin-top: 10px; }
      a { margin-right: 12px; }
      .ok { color:#0a7a2f; font-weight:800; }
      .warn { color:#8a5a00; font-weight:800; }
      .err { color:#b00020; font-weight:800; }

      /* Two-column form grid (inputs only) */
      .grid { display:grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
      .grid > div { min-width: 0; }
      
      .grid .full { grid-column: 1 / -1; }
      @media (max-width: 740px) { .grid { grid-template-columns: 1fr; } }

      /* Left-rail blocks for secondary controls + actions */
      .stack { margin-top: 12px; max-width: 420px; }
      .actions { margin-top: 18px; max-width: 420px; }
      .actions button { width: 100%; }
      .hint {
        margin-top: 6px;
        color: #666;
        text-align: left;
      }
    </style>
  </head>
  <body>
    <div class="card">
      <h2 style="margin:0 0 8px 0;">Setup</h2>

      {{ nav|safe }}

    <div class="muted">Hostname: <code>{{ params.hostname }}</code> · Mode: <code>{{ mode }}</code></div>

      <form method="post" action="/setup">
        <div class="grid">
          <div>
            <label>Execution Frequency
              <select name="execution_frequency">
                <option value="1" {% if params.execution_frequency == 1 %}selected{% endif %}>
                  1 — daily at noon
                </option>
                <option value="2" {% if params.execution_frequency == 2 %}selected{% endif %}>
                  2 — daily at noon + midnight
                </option>
              </select>
            </label>
          </div>

          <div></div>

          <div>
            <label>Radon Level ON Threshold (pCi/L)
              <input type="number" step="0.01" min="0" name="radon_on_threshold" value="{{ params.radon_on_threshold }}">
            </label>
          </div>

          <div>
            <label>Radon Level OFF Threshold (pCi/L)
              <input type="number" step="0.01" min="0" name="radon_off_threshold" value="{{ params.radon_off_threshold }}">
            </label>
          </div>

          <div class="hint full">
            A wider difference (ON − OFF) can reduce fan cycling.
          </div>
        </div>

        <!-- Placeholder kept, but aligned on the left rail -->
        <div class="stack">
          <label>Evening Fan Off (placeholder)
            <select name="evening_fan_off" disabled>
              <option selected>NO</option>
            </select>
          </label>
        </div>

        <div class="actions">
          <button type="submit">Save &amp; Go to Status</button>
          <div class="muted row">Changes take effect immediately for scheduling and on the next radon run for thresholds.</div>
        </div>
      </form>

      <hr style="margin:18px 0; border:none; border-top:1px solid #eee;">

      <form method="post" action="/factory-reset" onsubmit="return confirm('Factory reset will reboot into Setup Mode. Continue?');">
        <div class="actions">
          <button type="submit" class="danger">Factory Reset</button>
        </div>
        <div class="muted row">Erases Wi-Fi and system settings, then reboots into <b>RadonBox-Setup</b> mode.</div>
      </form>

      {% if msg %}
        <p class="row ok">✅ {{ msg }}</p>
      {% endif %}
      {% if err %}
        <p class="row err">❌ {{ err }}</p>
      {% endif %}
    </div>
  </body>
</html>
"""

# ---------------------------
# Factory settings (Beta4)
# ---------------------------

FACTORY_CRON = "/etc/cron.d/radonbox"
FACTORY_DEFAULTS = {
    "execution_frequency": 2,
    "radon_on_threshold": 4.0,
    "radon_off_threshold": 2.0,
}

def _parse_kv_conf(path: str) -> dict:
    out = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    except FileNotFoundError:
        return {}
    except Exception as e:
        log(f"[factory] Failed reading {path}: {e!r}")
        return {}
    return out

def factory_threshold_defaults():
    d = _parse_kv_conf(
        "/opt/radonbox/current/radon-min/radon-factory-defaults.conf"
    )
    return (
        d.get("RADON_ON_THRESHOLD", "4.0"),
        d.get("RADON_OFF_THRESHOLD", "2.0"),
    )

def _upsert_kv_conf(path: str, updates: dict) -> None:
    """
    Update keys in a simple KEY=VALUE file, preserving comments/unknown keys.
    Creates the file if missing.
    """
    lines = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except FileNotFoundError:
        lines = ["# RadonBox device config\n"]
    except Exception as e:
        log(f"[factory] Failed opening {path} for update: {e!r}")
        lines = ["# RadonBox device config\n"]

    remaining = dict(updates)

    new_lines = []
    for raw in lines:
        m = re.match(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$', raw)
        if not m:
            new_lines.append(raw)
            continue
        k = m.group(1).strip()
        if k in remaining:
            new_lines.append(f"{k}={remaining.pop(k)}\n")
        else:
            new_lines.append(raw)

    for k, v in remaining.items():
        new_lines.append(f"{k}={v}\n")

    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.writelines(new_lines)

def read_factory_settings() -> dict:
    conf = _parse_kv_conf(RADON_CONFIG)
    params = dict(FACTORY_DEFAULTS)

    try:
        if conf.get("RADON_EXECUTION_FREQUENCY"):
            params["execution_frequency"] = int(conf["RADON_EXECUTION_FREQUENCY"])
    except Exception:
        pass

    try:
        if conf.get("RADON_ON_THRESHOLD"):
            params["radon_on_threshold"] = float(conf["RADON_ON_THRESHOLD"])
    except Exception:
        pass

    try:
        if conf.get("RADON_OFF_THRESHOLD"):
            params["radon_off_threshold"] = float(conf["RADON_OFF_THRESHOLD"])
    except Exception:
        pass

    # Always show current hostname
    params["hostname"] = get_pi_hostname()
    params["evening_fan_off"] = "NO"
    return params

def write_factory_settings(execution_frequency: int, on_thr: float, off_thr: float) -> None:
    _upsert_kv_conf(RADON_CONFIG, {
        "RADON_EXECUTION_FREQUENCY": str(execution_frequency),
        "RADON_ON_THRESHOLD": f"{on_thr:.2f}",
        "RADON_OFF_THRESHOLD": f"{off_thr:.2f}",
    })

def apply_schedule(execution_frequency: int) -> None:
    """
    execution_frequency:
      1 -> noon
      2 -> noon + midnight

    Writes:
      - /etc/cron.d/radonbox (authoritative, deterministic)

    Also performs a one-time cleanup of any legacy root-crontab RadonBox schedule
    lines to prevent double-execution (some older betas wrote both locations).
    """
    freq = 1 if execution_frequency != 2 else 2

    # 1) /etc/cron.d (authoritative)
    cron_lines = [
        "# RadonBox schedule (managed by portal)\n",
        "SHELL=/bin/bash\n",
        "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n",
        "\n",
        f"0 12 * * * root {RUN_RADON} >/dev/null 2>&1\n",
    ]
    if freq == 2:
        cron_lines.append(f"0 0 * * * root {RUN_RADON} >/dev/null 2>&1\n")

    with open(FACTORY_CRON, "w", encoding="utf-8") as f:
        f.writelines(cron_lines)
    # Best-effort nudge cron to reload
    try:
        run_cmd(["systemctl", "restart", "cron"], timeout=20)
    except Exception:
        pass
    # 2) Clean up any legacy root-crontab schedule entries (do NOT add new ones)
    _cleanup_root_crontab_radon_schedule()


def apply_site_report_schedule(enabled: str, freq: str) -> None:
    """Write/remove Site-Report schedule in /etc/cron.d.

    Runs at 1:00pm local time to avoid the noon radon reading.
    enabled: '1' or '0'
    freq: daily|weekly|monthly
    """
    en = str(enabled or "").strip().lower() in ("1", "true", "on", "yes")
    freq = (freq or "").strip().lower()
    if freq not in ("daily", "weekly", "monthly"):
        freq = "weekly"

    # Ensure log dir exists
    try:
        os.makedirs(os.path.dirname(SITE_REPORT_LOG), exist_ok=True)
    except Exception:
        pass

    if not en:
        # Remove schedule if present
        try:
            if os.path.exists(SITE_REPORT_CRON):
                os.remove(SITE_REPORT_CRON)
        except Exception:
            pass
        return

    # Cron times:
    #  - daily:   13:00 every day
    #  - weekly:  13:00 every Monday
    #  - monthly: 13:00 on day 1 of month
    if freq == "daily":
        spec = "0 13 * * *"
    elif freq == "monthly":
        spec = "0 13 1 * *"
    else:
        spec = "0 13 * * 1"

    cron_lines = [
        "# RadonBox Site-Report schedule (managed by portal)\n",
        "SHELL=/bin/bash\n",
        "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n",
        "\n",
        f"{spec} root {REPORT_SITE} >>{SITE_REPORT_LOG} 2>&1\n",
    ]
    try:
        with open(SITE_REPORT_CRON, "w", encoding="utf-8") as f:
            f.writelines(cron_lines)
        os.chmod(SITE_REPORT_CRON, 0o644)
    except Exception as e:
        log(f"[site-report] WARNING: failed writing schedule: {e!r}")

def trigger_initial_site_report() -> None:
    """Fire a one-time Site Report (non-blocking) for installer verification.

    Called only on OFF->ON transition in Managed Setup.
    """
    try:
        os.makedirs(os.path.dirname(SITE_REPORT_TRIGGER_LOG), exist_ok=True)
    except Exception:
        pass

    try:
        if not os.path.exists(SITE_REPORT_SCRIPT):
            try:
                with open(SITE_REPORT_TRIGGER_LOG, "a") as lf:
                    lf.write(f"[site-report-trigger] ERROR: missing script {SITE_REPORT_SCRIPT}\n")
            except Exception:
                pass
            return

        with open(SITE_REPORT_TRIGGER_LOG, "a") as lf:
            lf.write("[site-report-trigger] Launching initial report-site run\n")
            lf.flush()
            subprocess.Popen(
                ["/usr/bin/python3", SITE_REPORT_SCRIPT, "--force"],
                stdout=lf,
                stderr=lf,
                close_fds=True,
            )
    except Exception as e:
        try:
            with open(SITE_REPORT_TRIGGER_LOG, "a") as lf:
                lf.write(f"[site-report-trigger] EXCEPTION: {e!r}\n")
        except Exception:
            pass




def _cleanup_root_crontab_radon_schedule() -> None:
    """
    Ensure root's crontab does NOT schedule run-radon.sh.

    Authoritative scheduling is in /etc/cron.d/radonbox.

    This removes:
      - the delimited RadonBox block (BEGIN/END), if present
      - any stray lines containing RUN_RADON (belt & suspenders)

    It intentionally does NOT touch unrelated entries (e.g., your nightly 03:00 reboot).
    """
    BEGIN = "# RadonBox schedule (managed by portal)"
    END = "# End RadonBox schedule"

    rc, out, _ = run_cmd(["crontab", "-l"], timeout=10)
    existing = out if rc == 0 else ""

    keep = []
    in_block = False
    for line in existing.splitlines():
        s = line.strip()

        # Remove the whole delimited block
        if s == BEGIN:
            in_block = True
            continue
        if s == END:
            in_block = False
            continue
        if in_block:
            continue

        # Also remove any stray run-radon lines (legacy/manual)
        if RUN_RADON in line:
            continue

        keep.append(line)

    # Avoid trailing blank spam; preserve other cron content exactly
    new_lines = [l for l in keep if l.strip() != ""]
    content = ("\n".join(new_lines).rstrip() + "\n") if new_lines else ""

    tmp = "/tmp/radonbox-root-crontab.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(content)
        run_cmd(["crontab", tmp], timeout=10)
    except Exception as e:
        log(f"[cron] WARNING: failed cleaning root crontab: {e!r}")



# Routes
# ---------------------------

@app.route("/api/update/check")
def api_update_check():
    latest_url = (request.args.get("latest_url") or LATEST_URL_DEFAULT).strip()

    if not _is_safe_latest_url(latest_url):
        return jsonify({"ok": False, "error": "Blocked: latest_url not allowed"}), 400

    running = _read_running_version() or "unknown"
    try:
        j = _read_latest_json(latest_url)
    except Exception as e:
        return jsonify({"ok": False, "running": running, "error": str(e)}), 500

    latest_ver = str(j.get("version") or "").strip() or "unknown"
    update_available = (running != "unknown" and latest_ver != "unknown" and running != latest_ver)

    return jsonify({
        "ok": True,
        "running": running,
        "latest": latest_ver,
        "update_available": update_available,
        "notes": j.get("notes", ""),
        "bundle_url": j.get("bundle_url", ""),
        "sig_url": j.get("sig_url", ""),
    })


@app.route("/api/update/stage", methods=["POST"])
def api_update_stage():
    # allow override from UI, but validate it strictly
    latest_url = (request.form.get("latest_url") or LATEST_URL_DEFAULT).strip()

    if not _is_safe_latest_url(latest_url):
        return jsonify({"ok": False, "error": "Blocked: latest_url not allowed"}), 400

    # Stage update using your existing script
    rc, out = _run_cmd(
        ["/usr/local/sbin/radonbox-update.sh", latest_url],
        timeout_sec=180,
    )

    # If you already have write_update_status()/log helpers, you can call them here.
    # But returning output is enough for now.
    return jsonify({
        "ok": (rc == 0),
        "rc": rc,
        "output": out[-8000:],  # keep response bounded
    })


@app.route("/", methods=["GET"])
def index():
    # Beta7: route AP clients to the AP onboarding UI; others to managed Status.
    if is_ap_request():
        return redirect('/onboard')
    return redirect('/status')


@app.route("/onboard", methods=["GET"])
def ap_onboard_setup():
    if not is_ap_request():
        return redirect("/status")
    last = load_last_onboard()
    html = _html_subst(
        AP_SETUP_HTML,
        css=AP_TABS_CSS,
        ssid=(last.get("ssid") or ""),
        psk=(last.get("psk") or ""),
        notify_email=(last.get("notify_email") or ""),
        shelly_host=(last.get("shelly_host") or ""),
    )
    return render_template_string(html)

@app.route("/onboard/logs", methods=["GET"])
def ap_onboard_logs():
    if not is_ap_request():
        return redirect("/status")
    html = _html_subst(AP_LOGS_HTML, css=AP_TABS_CSS, logpath=ONBOARD_LOG)
    return render_template_string(html)

@app.route("/api/onboard/state", methods=["GET"])
def api_onboard_state():
    ifname = get_sta_if()
    return jsonify({
        "ok": True,
        "sta_if": ifname,
        "connected_ssid": get_sta_ssid(ifname),
        "managed_ip": get_iface_ipv4(ifname),
    })

@app.route("/api/onboard/log", methods=["GET"])
def api_onboard_log():
    tail = request.args.get("tail")
    try:
        with open(ONBOARD_LOG, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        if tail:
            try:
                n = int(tail)
                if n > 0:
                    lines = lines[-n:]
            except Exception:
                pass
        resp = make_response("".join(lines))
        resp.headers["Content-Type"] = "text/plain; charset=utf-8"
        return resp
    except FileNotFoundError:
        return make_response("", 200)
    except Exception as e:
        return make_response(f"Error reading log: {e}\n", 500)



@app.route("/wifi", methods=["POST"])
def wifi():
    log("===== NEW /wifi SUBMISSION =====")
    try:
        ssid = (request.form.get("ssid") or "").strip()
        psk = (request.form.get("psk") or "").strip()
        notify_email = (request.form.get("notify_email") or "").strip()
        log(f"[onboard] notify_email normalized={notify_email!r}")

        site_report_enabled = "1" if (request.form.get("site_report_enabled") in ("1","on","true","yes")) else "0"
        log(f"[onboard] site_report_enabled={site_report_enabled!r}")

        shelly_host = (request.form.get("shelly_host") or "").strip()

        # Beta7: persist last submission for convenience (no UI retry button)
        save_last_onboard(ssid, psk, shelly_host, notify_email, site_report_enabled)

        # Hostname is auto-generated (no user input)
        req_hostname = default_unique_hostname()
        log(f"[wifi] Using auto hostname {req_hostname!r}")
        apply_hostname(req_hostname)

        hostname_now = get_pi_hostname()
        log(f"[wifi] hostname_now={hostname_now!r} ssid={ssid!r}")

        def _bg_onboard():
            try:
                # Pause before beginning switch from AP to Managed
                # To give the user time to view the Success page -- 
                # From the return render_template_string, below
                time.sleep(15) 
                ok = try_onboard(ssid, psk, shelly_host=shelly_host, notify_email=notify_email, site_report_enabled=site_report_enabled)
                log(f"[wifi/_bg_onboard] try_onboard ok={ok}")
            except Exception as e:
                log(f"[wifi/_bg_onboard] EXCEPTION: {e!r}")

        threading.Thread(target=_bg_onboard, daemon=True).start()
        # Note: The threading.Thread initiates _bg_onboard
        # Which has a time.sleep and the return to Success happens immediately
        return redirect("/onboard?connected=1")

    except Exception as e:
        log(f"[wifi] EXCEPTION: {e!r}")
        return "Internal error during onboarding", 500





@app.route("/api/status", methods=["GET"])
def api_status():
    return read_device_status()



@app.route("/chart")
def chart_redirect():
    # Compatibility route: some pages link to /chart; chart is served as /radon-chart.png
    return redirect("/radon-chart.png", code=302)

@app.route("/status", methods=["GET"])
def status_page():
    try:
        cfg = read_kv_conf(RADON_CONFIG)

        # Execution frequency label for display
        exec_raw = (cfg.get("RADON_EXECUTION_FREQUENCY") or "1")
        exec_label = exec_raw
        try:
            f = int(str(exec_raw).strip())
            if f == 1:
                exec_label = "1 — daily at noon"
            elif f == 2:
                exec_label = "2 — daily at noon + midnight"
            else:
                exec_label = str(f)
        except Exception:
            pass

        # Site report label for display
        sr_en = (cfg.get(SRF_SITE_REPORT_ENABLED_KEY) or "0").strip().lower() in ("1","true","on","yes")
        sr_freq = (cfg.get(SRF_SITE_REPORT_FREQ_KEY) or "weekly").strip().lower()
        if sr_freq not in ("daily","weekly","monthly"):
            sr_freq = "weekly"
        site_report_label = "Off" if not sr_en else sr_freq.title() + " (1:00pm)"

        app_version = read_app_version()
        st = read_device_status()

        # RadonBox address (Managed: STA IPv4; AP: wlan0 IPv4)
        sta_if = get_sta_if()
        rb_ip = ""
        try:
            rb_ip = get_iface_ipv4("wlan0") if is_ap_request() else get_iface_ipv4(sta_if)
        except Exception:
            rb_ip = ""
        if not rb_ip:
            try:
                rb_ip = (request.host or "").split(":")[0]
            except Exception:
                rb_ip = ""
        rb_state = "CONNECTED" if rb_ip else "UNKNOWN"
        rb_level = "ok" if rb_state == "CONNECTED" else "warn"

        return render_template_string(
            STATUS_HTML,
            msg=request.args.get("msg",""),
            css=AP_TABS_CSS,
            active_tab="status",
            page_title="RadonBox Status",
            hostname=get_pi_hostname(),
            mode=("ap" if is_ap_request() else "managed"),
            radon_on=(cfg.get("RADON_ON_THRESHOLD") or "2.0"),
            radon_off=(cfg.get("RADON_OFF_THRESHOLD") or "1.5"),
            exec_freq_label=exec_label,
            site_report_label=site_report_label,
            app_version=app_version,
            st=st,
            rb_ip=rb_ip,
            rb_state=rb_state,
            rb_level=rb_level,
        )
    except Exception as e:
        try:
            import traceback
            log("[status] EXCEPTION rendering /status:")
            log(traceback.format_exc())
        except Exception:
            pass
        return (
            "<h2>Internal Error</h2>"
            "<p>The Status page hit an exception. See /var/log/radonbox/onboard.log for traceback.</p>"
            f"<pre>{str(e)}</pre>",
            500,
        )


@app.route("/system", methods=["GET", "POST"])
def system_redirect():
    # Back-compat: old URL now points to Setup.
    # Use 307 for POST so the browser preserves method and form data.
    code = 307 if request.method == "POST" else 302
    return redirect("/setup", code=code)


@app.route("/setup", methods=["GET", "POST"])
def setup_page():
    msg = ""
    err = ""

    if request.method == "POST":
        # Hostname + Evening Fan Off are placeholders for Beta4 (not editable here)
        try:
            # Site-Report OFF->ON transition detection (Managed mode)
            prev_cfg = read_kv_conf(RADON_CONFIG)
            prev_sr_enabled_raw = (prev_cfg.get(SRF_SITE_REPORT_ENABLED_KEY) or "0").strip().lower()
            prev_sr_enabled = prev_sr_enabled_raw in ("1", "true", "on", "yes")

            exec_freq = int((request.form.get("execution_frequency") or "1").strip())
            if exec_freq not in (1, 2):
                raise ValueError("execution_frequency must be 1 or 2")

            on_thr = float((request.form.get("radon_on_threshold") or "2.0").strip())
            off_thr = float((request.form.get("radon_off_threshold") or "1.5").strip())

            if on_thr <= 0 or off_thr < 0:
                raise ValueError("thresholds must be non-negative, and ON must be > 0")
            if off_thr >= on_thr:
                raise ValueError("OFF threshold must be less than ON threshold")

            write_factory_settings(exec_freq, on_thr, off_thr)
            apply_schedule(exec_freq)

            # ---- Site Report (Managed-mode only) ----
            sr_enabled = "1" if (request.form.get("site_report_enabled") in ("1", "on", "true", "yes")) else "0"
            sr_freq = (request.form.get("site_report_frequency") or "weekly").strip().lower()
            if sr_freq not in ("daily", "weekly", "monthly"):
                raise ValueError("site_report_frequency must be daily, weekly, or monthly")

            set_kv_conf_value(RADON_CONFIG, SRF_SITE_REPORT_ENABLED_KEY, sr_enabled)
            set_kv_conf_value(RADON_CONFIG, SRF_SITE_REPORT_FREQ_KEY, sr_freq)
            apply_site_report_schedule(sr_enabled, sr_freq)
            # Fire an initial report only when transitioning from OFF -> ON
            if (not prev_sr_enabled) and (str(sr_enabled).strip() == "1"):
                trigger_initial_site_report()


            # UX: after a successful save, go to Status so the installer
            # can immediately verify the active configuration.
            return redirect("/status", code=302)

        except Exception as e:
            err = str(e)

    params = read_factory_settings()
    cfg = read_kv_conf(RADON_CONFIG)
    sr_enabled = (cfg.get(SRF_SITE_REPORT_ENABLED_KEY) or "0").strip()
    sr_freq = (cfg.get(SRF_SITE_REPORT_FREQ_KEY) or "weekly").strip().lower()
    if sr_freq not in ("daily","weekly","monthly"):
        sr_freq = "weekly"
    # Reflect posted values even if save failed (so installer sees what they entered)
    if request.method == "POST":
        try:
            params["execution_frequency"] = int((request.form.get("execution_frequency") or params["execution_frequency"]))
        except Exception:
            pass
        try:
            params["radon_on_threshold"] = float((request.form.get("radon_on_threshold") or params["radon_on_threshold"]))
        except Exception:
            pass
        try:
            params["radon_off_threshold"] = float((request.form.get("radon_off_threshold") or params["radon_off_threshold"]))
        except Exception:
            pass

    banner = ""
    if err:
        banner = f'<div class="muted" style="margin-top:10px; color:#b91c1c;"><b>Error:</b> {err}</div>'
    elif msg:
        banner = f'<div class="muted" style="margin-top:10px; color:#065f46;"><b>{msg}</b></div>'

    html = _html_subst(
        MANAGED_SETUP_HTML,
        css=MANAGED_TABS_CSS,
        banner=banner,
        freq1=("selected" if int(params.get("execution_frequency", 1)) == 1 else ""),
        freq2=("selected" if int(params.get("execution_frequency", 1)) == 2 else ""),
        on_thr=str(params.get("radon_on_threshold", 2.0)),
        off_thr=str(params.get("radon_off_threshold", 1.5)),
        site_enabled_checked=("checked" if str(sr_enabled).strip() in ("1","true","on","yes") else ""),
        sr_daily=("selected" if sr_freq=="daily" else ""),
        sr_weekly=("selected" if sr_freq=="weekly" else ""),
        sr_monthly=("selected" if sr_freq=="monthly" else ""),
    )
    return render_template_string(html)


@app.route("/support", methods=["GET"])
def support():
    current = read_app_version()
    st = read_update_status()

    # If the staged status is for the same version we're already running,
    # reflect that clearly in the UI to avoid confusion.
    if st and st.get("version") == current and st.get("state") in ("READY", "OK", "UP_TO_DATE"):
        st["state"] = "UP_TO_DATE"
        st["message"] = "Already running this version. No update needed."

    return render_template(
        "support.html",
        css=AP_TABS_CSS,
        active_tab="support",
        page_title="RadonBox Support",
        managed_ip=(get_iface_ipv4("wlan1") or get_iface_ipv4("wlan0") or ""),
        nav=NAV_HTML,
        app_version=current,
        latest_url=LATEST_URL_DEFAULT,
        update_status=st,
        update_log_tail=tail_file(UPDATE_LOG_PATH, 40),
    )

@app.route("/support/stage", methods=["POST"])
def support_stage():
    latest_url = request.form.get("latest_url", LATEST_URL_DEFAULT)
    latest_url = (latest_url or "").strip()
    if not (latest_url.startswith("https://www.smartradonfan.com/updates/") or
            latest_url.startswith("https://smartradonfan.com/updates/")):
        return jsonify({"ok": False, "error": "Invalid update source"}), 400

    # Immediate UI feedback on first click
    write_update_status({
        "state": "STARTING",
        "message": "Starting update check/install...",
        "latest_url": latest_url,
        "time": now_iso(),
        "version": "",
    })

    # Run updater in a separate transient systemd unit so restarting radon-portal
    # during activation does NOT kill the updater (different cgroup).
    try:
        unit = f"radonbox-update-{int(time.time())}"
        subprocess.Popen(
            ["sudo", "/usr/bin/systemd-run",
             "--unit", unit,
             "--collect",
             "--no-block",
             UPDATER_PATH, latest_url],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            start_new_session=True,
        )
    except Exception as e:
        write_update_status({
            "state": "ERROR",
            "message": f"Failed to start updater: {e}",
            "latest_url": latest_url,
            "time": now_iso(),
            "version": "",
        })

    return redirect("/support")


@app.post("/factory-reset")
def factory_reset():
    try:
        subprocess.Popen(
            ["/usr/bin/sudo",
             "/opt/radonbox/current/radon-min/radon-reset.sh",
             "--reboot"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )

    except Exception as e:
        log(f"Factory reset spawn failed: {e!r}")
        return "Error initiating factory reset", 500

    return """
    <html><body>
      <h2>Factory Reset in Progress</h2>
      <p>Your RadonBox is restarting into <b>Setup Mode</b>.</p>
      <p>In about a minute, look for the Wi-Fi network <b>RadonBox-Setup</b>.</p>
    </body></html>
    """



@app.post("/factory-reset-shutdown")
def factory_reset_shutdown():
    """Factory reset (clear logs/charts/etc.) and then power off."""
    try:
        # Run reset then poweroff in a detached background shell so the HTTP request can return immediately.
        cmd = (
            "/opt/radonbox/current/radon-min/radon-reset.sh; "
            "/usr/sbin/shutdown --poweroff now"
        )
        subprocess.Popen(
            ["/usr/bin/sudo", "/bin/bash", "-lc", cmd],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except Exception as e:
        log(f"Factory reset+shutdown spawn failed: {e!r}")
        return "Error initiating factory reset + shutdown", 500

    return """
    <html><body>
      <h2>Factory Reset + Shutdown in Progress</h2>
      <p>Logs and charts are being cleared, then the RadonBox will power off.</p>
      <p>When you restore power, it will restart in <b>Setup Mode</b> with a clean, from-factory state.</p>
    </body></html>
    """
@app.route("/radon-chart.png")
def radon_chart_png():
    deadline = time.time() + 6.0
    min_size = 5000  # bytes; prevents serving a partial/empty PNG

    while time.time() < deadline:
        try:
            st = os.stat(CHART_PATH)
            if st.st_size >= min_size:
                resp = send_file(CHART_PATH, mimetype="image/png")
                resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
                resp.headers["Pragma"] = "no-cache"
                resp.headers["Expires"] = "0"
                return resp
        except FileNotFoundError:
            pass
        time.sleep(0.10)

    return (
        "<html><body><h3>Chart is being generated</h3>"
        "<p>Please refresh in a moment.</p>"
        "</body></html>",
        404,
    )

    resp = make_response(send_file(CHART_PATH, mimetype="image/png"))
    # Avoid browsers caching a previous 404 or stale PNG
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp

@app.post("/site-report-test")
def site_report_test():
    import subprocess
    try:
        cmd = ["/usr/bin/python3",
               "/opt/radonbox/current/bin/site-report.py",
               "--force"]
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=25)
        output = (p.stdout or "") + "\n" + (p.stderr or "")
        return jsonify({
            "ok": p.returncode == 0,
            "rc": p.returncode,
            "output": output[-2000:]
        })
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500


if __name__ == "__main__":
    mode = get_boot_mode()
    log("=== RadonBox portal starting ===")
    log(f"Boot mode: {mode}")

    if mode == "ap":
        status_patch({
            "summary": {"state": "SETUP_MODE", "level": "warn", "text": "Setup mode — enter Wi-Fi credentials at /"},
            "wifi": {"state": "AP_MODE", "level": "warn"},
            "meta": {"generated_local": now_iso()},
        })

    app.run(host="0.0.0.0", port=8080, debug=False)
