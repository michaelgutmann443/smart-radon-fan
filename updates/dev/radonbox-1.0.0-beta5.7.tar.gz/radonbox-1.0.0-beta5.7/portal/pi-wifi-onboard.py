#!/usr/bin/env python3
"""
RadonBox Wi-Fi onboarding portal (Beta3 - FIXED)

Fixes:
- /status no longer 500s (STATUS_HTML defined once)
- Removes duplicate SUCCESS_HTML blocks
- Keeps /system using templates/system.html (as in your working setup)
- Keeps factory reset endpoint
- Keeps radon-chart endpoint

Design note:
- /wifi returns a "ready" page immediately so the installer can screenshot
  before AP is torn down. The actual AP->managed transition runs in a short-
  lived background thread (2s delay). This is the minimal mechanism required
  to show the page reliably before Wi-Fi flips.
"""

import os
import time
import socket
import subprocess
import re
import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from flask import Flask, request, render_template, render_template_string, send_file, redirect, jsonify
from urllib.parse import urlparse

# ---------------------------
# Paths / constants
# ---------------------------

BOOT_FLAG = "/etc/radonbox/boot-mode"
ONBOARD_LOG = "/tmp/radon-onboard-debug.log"

RADON_DIR = "/opt/radonbox/current/radon-min"

STATUS_UPDATER = "/opt/radonbox/current/radon-min/radon-status-update.py"
RADON_DEVICES_INIT = "/opt/radonbox/current/radon-min/radon-devices-init.sh"
RUN_RADON = "/opt/radonbox/current/radon-min/run-radon.sh"

DEVICE_STATUS_JSON = "/etc/radonbox/device-status.json"

RB_FLAG = os.path.join(RADON_DIR, "rb-flag.sh")
RB_HOSTNAME_FILE = "/boot/rb-hostname"

RADON_CONFIG = "/etc/radonbox/radon-config.conf"
CHART_PATH = os.path.join(RADON_DIR, "radon-chart.png")

LATEST_URL_DEFAULT = "https://www.smartradonfan.com/updates/dev/latest.json"


# Ensure Flask finds templates/system.html (your WorkingDirectory is RADON_DIR)
app = Flask(__name__)


# ---------------------------
# Logging / helpers
# ---------------------------

UPDATE_STATUS_PATH = "/var/lib/radonbox/update-status.json"
UPDATE_LOG_PATH = "/var/log/radonbox/update.log"
UPDATER_PATH = "/usr/local/sbin/radonbox-update.sh"
LAST_READING_PATH = "/var/lib/radonbox/last-radon-reading.json"

def _is_safe_latest_url(url: str) -> bool:
    """Allow only your update manifests (prevents command injection / SSRF)."""
    try:
        u = urlparse(url.strip())
    except Exception:
        return False
    if u.scheme != "https":
        return False
    host = (u.netloc or "").lower()
    if host not in ("www.smartradonfan.com", "smartradonfan.com"):
        return False
    # Restrict to your update area
    return u.path.startswith("/updates/") and u.path.endswith(".json")

def _run_cmd(cmd: list[str], timeout_sec: int = 120) -> tuple[int, str]:
    """Run a command and return (rc, combined_output)."""
    p = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout_sec,
    )
    out = (p.stdout or "") + (("\n" + p.stderr) if p.stderr else "")
    return p.returncode, out

def _read_latest_json(url: str) -> dict:
    """Fetch latest.json via curl and parse minimal fields without extra deps."""
    rc, out = _run_cmd(["/usr/bin/curl", "-fsSL", url], timeout_sec=20)
    if rc != 0:
        raise RuntimeError("Failed to fetch latest.json")
    # Use a tiny, safe parse (file is small + controlled). Prefer json if already imported.
    import json
    return json.loads(out)

def _read_running_version() -> str:
    # You likely already have read_app_version(); use it if present
    try:
        return read_app_version()
    except Exception:
        return ""

def read_update_status():
    try:
        with open(UPDATE_STATUS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {"state":"NONE","message":"No update activity yet"}
    except Exception as e:
        return {"state":"ERROR","message":f"Failed to read status: {e}"}



def write_update_status(obj: dict) -> None:
    """Best-effort write of update status json for UI freshness."""
    try:
        os.makedirs(os.path.dirname(UPDATE_STATUS_PATH), exist_ok=True)
        with open(UPDATE_STATUS_PATH, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2)
    except Exception:
        pass
def tail_file(path: str, lines: int = 30) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            data = f.readlines()
        return "".join(data[-lines:])
    except FileNotFoundError:
        return "(no log yet)"
    except Exception as e:
        return f"(failed to read log: {e})"

def read_app_version() -> str:
    """
    Returns the current SmartRadonFan/RadonBox software version string.
    Looks in the product-grade location first, then falls back to radon-min.
    """
    candidates = [
        Path("/opt/radonbox/current/VERSION"),                 # future product-grade layout
        Path("/home/boris/radon-min/VERSION"),                 # current dev layout
        Path(os.path.expanduser("~/radon-min/VERSION")),       # fallback
    ]
    for p in candidates:
        try:
            if p.is_file():
                v = p.read_text(encoding="utf-8").strip()
                if v:
                    return v
        except Exception:
            pass
    return "unknown"

def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")

def log(msg: str) -> None:
    ts = time.strftime("[%Y-%m-%d %H:%M:%S]")
    line = f"{ts} {msg}"
    try:
        with open(ONBOARD_LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass
    print(line, flush=True)


def run_cmd(cmd, timeout=30):
    cmd_str = " ".join(cmd)
    log(f"[run_cmd] exec: {cmd_str} (timeout={timeout}s)")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if proc.stdout:
            for line in proc.stdout.splitlines():
                log(f"[run_cmd] stdout: {line}")
        if proc.stderr:
            for line in proc.stderr.splitlines():
                log(f"[run_cmd] stderr: {line}")
        log(f"[run_cmd] rc={proc.returncode}")
        return proc.returncode, proc.stdout, proc.stderr
    except subprocess.TimeoutExpired as e:
        log(f"[run_cmd] TIMEOUT: {cmd_str}")
        return 124, "", f"TimeoutExpired: {e}"
    except Exception as e:
        log(f"[run_cmd] EXCEPTION {cmd_str}: {e!r}")
        return 1, "", str(e)

def status_patch(patch: dict) -> None:
    """Best-effort device-status update (never throws)."""
    try:
        if os.path.exists(STATUS_UPDATER):
            subprocess.run(
                [STATUS_UPDATER, json.dumps(patch)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
            )
    except Exception:
        pass


# ---------------------------
# Boot mode / hostname helpers
# ---------------------------

def default_unique_hostname(prefix="radonbox"):
    """
    Generate a stable, collision-resistant hostname based on wlan0 MAC.
    Example: radonbox-2b45
    """
    try:
        with open("/sys/class/net/wlan0/address") as f:
            mac = f.read().strip().lower().replace(":", "")
        suffix = mac[-4:]
        return f"{prefix}-{suffix}"
    except Exception:
        # Absolute fallback — still valid
        return prefix

def get_boot_mode() -> str:
    try:
        with open(BOOT_FLAG, "r", encoding="utf-8") as f:
            mode = f.read().strip().lower()
            if mode in ("ap", "managed"):
                return mode
    except FileNotFoundError:
        pass
    return "ap"


def set_boot_mode(mode: str) -> None:
    mode = (mode or "").strip().lower()
    if mode not in ("ap", "managed"):
        log(f"[set_boot_mode] invalid mode requested: {mode}")
        return
    log(f"[set_boot_mode] setting boot mode to {mode!r}")
    run_cmd([os.path.join(RADON_DIR, "rb-flag.sh"), mode], timeout=10)


def normalize_hostname(s: str) -> str:
    return (s or "").strip().lower()


def is_valid_hostname(h: str) -> bool:
    if not (1 <= len(h) <= 63):
        return False
    if h.startswith("-") or h.endswith("-"):
        return False
    return re.fullmatch(r"[a-z0-9-]+", h) is not None


def apply_hostname(new_hostname: str) -> bool:
    """
    Persist + apply hostname immediately.
    Note: Avahi may still rename if there is a conflict on the LAN.
    """
    try:
        with open(RB_HOSTNAME_FILE, "w", encoding="utf-8") as f:
            f.write(new_hostname + "\n")

        rc, _, err = run_cmd(["/usr/bin/hostnamectl", "set-hostname", new_hostname], timeout=10)
        if rc != 0:
            log(f"[hostname] WARNING: hostnamectl failed rc={rc}: {err}")

        # Keep /etc/hosts consistent for 127.0.1.1
        hosts_path = "/etc/hosts"
        try:
            with open(hosts_path, "r", encoding="utf-8") as f:
                lines = f.read().splitlines()
        except FileNotFoundError:
            lines = []

        new_lines = []
        replaced = False
        for line in lines:
            if line.strip().startswith("127.0.1.1"):
                new_lines.append(f"127.0.1.1\t{new_hostname}")
                replaced = True
            else:
                new_lines.append(line)
        if not replaced:
            new_lines.append(f"127.0.1.1\t{new_hostname}")

        with open(hosts_path, "w", encoding="utf-8") as f:
            f.write("\n".join(new_lines).rstrip() + "\n")

        log(f"[hostname] Applied hostname: {new_hostname}")
        return True
    except Exception as e:
        log(f"[hostname] ERROR applying hostname '{new_hostname}': {e!r}")
        return False


def get_pi_hostname() -> str:
    try:
        name = socket.gethostname().strip()
        return name or "radonbox"
    except Exception:
        return "radonbox"


import re
import subprocess

def get_wlan0_ipv4() -> str:
    """
    Best-effort: returns the current wlan0 IPv4 address (e.g., 192.168.1.58),
    or "" if not available.
    """
    try:
        out = subprocess.check_output(
            ["/usr/sbin/ip", "-4", "addr", "show", "dev", "wlan0"],
            text=True,
            stderr=subprocess.DEVNULL,
        )
        m = re.search(r"\binet\s+(\d+\.\d+\.\d+\.\d+)\b", out)
        return m.group(1) if m else ""
    except Exception:
        return ""


# ---------------------------
# Config helpers
# ---------------------------

def read_kv_conf(path: str) -> dict:
    d = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                d[k.strip()] = v.strip()
    except FileNotFoundError:
        return {}
    except Exception as e:
        log(f"[conf] WARNING: failed reading {path}: {e!r}")
        return {}
    return d


def set_kv_conf_value(path: str, key: str, value: str) -> None:
    """Set or remove a KEY=VALUE line in a simple kv config file.
    Preserves other lines and comments. Writes atomically.
    If value is empty, removes the key.
    """
    value = (value or "").strip()
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.read().splitlines()
    except FileNotFoundError:
        lines = []

    out = []
    found = False
    for raw in lines:
        if raw.strip().startswith(f"{key}="):
            found = True
            if value:
                out.append(f"{key}={value}")
            # else: drop line
        else:
            out.append(raw)

    if (not found) and value:
        if out and out[-1].strip() != "":
            out.append("")
        out.append(f"{key}={value}")

    tmp = f"{path}.tmp"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(tmp, "w", encoding="utf-8") as f:
        f.write("\n".join(out).rstrip() + "\n")
    os.replace(tmp, path)


def is_blank_device_config() -> bool:
    cfg = read_kv_conf(RADON_CONFIG)
    for k in ("SHELLY_HOST", "AIR_MAC", "SHELLY_SWITCH_ID"):
        if not cfg.get(k):
            return True
    return False


# ---------------------------
# Wi-Fi onboarding logic
# ---------------------------

def wait_for_wifi_ssid(target_ssid: str, timeout: int = 60) -> bool:
    target_ssid = (target_ssid or "").strip()
    if not target_ssid:
        return False

    deadline = time.time() + timeout
    log(f"[wait_for_wifi_ssid] waiting up to {timeout}s for SSID={target_ssid!r}")
    while time.time() < deadline:
        rc, out, _ = run_cmd(["nmcli", "-t", "-f", "ACTIVE,SSID", "dev", "wifi"], timeout=10)
        if rc == 0 and out:
            for line in out.splitlines():
                parts = line.split(":", 1)
                if len(parts) == 2 and parts[0] == "yes" and parts[1] == target_ssid:
                    log(f"[wait_for_wifi_ssid] Connected to SSID={target_ssid!r}")
                    return True
        time.sleep(3)

    log("[wait_for_wifi_ssid] timed out waiting for Wi-Fi connection")
    return False


def try_onboard(ssid: str, psk: str, shelly_host: str = "") -> bool:
    ssid = (ssid or "").strip()
    psk = (psk or "").strip()

    if not ssid or not psk:
        status_patch({"summary": {"state": "ERROR", "level": "error", "text": "Missing SSID or password"}})
        return False

    status_patch({
        "summary": {"state": "CONNECTING_WIFI", "level": "warn", "text": f"Connecting to Wi-Fi '{ssid}'..."},
        "wifi": {"state": "CONNECTING", "level": "warn", "ssid": ssid, "last_attempt_local": now_iso()},
        "meta": {"generated_local": now_iso()},
    })

    # Tear down AP services
    run_cmd(["systemctl", "stop", "hostapd", "dnsmasq"], timeout=30)

    # Bring up NetworkManager + connect
    run_cmd(["systemctl", "enable", "NetworkManager"], timeout=30)
    run_cmd(["systemctl", "restart", "NetworkManager"], timeout=60)

    run_cmd(["nmcli", "dev", "set", "wlan0", "managed", "yes"], timeout=20)
    run_cmd(["nmcli", "radio", "wifi", "on"], timeout=20)

    run_cmd(["nmcli", "dev", "wifi", "rescan"], timeout=20)
    run_cmd(["nmcli", "dev", "wifi", "connect", ssid, "password", psk, "ifname", "wlan0"], timeout=60)

    if not wait_for_wifi_ssid(ssid, timeout=60):
        status_patch({
            "summary": {"state": "ERROR", "level": "error", "text": f"Failed to connect to Wi-Fi '{ssid}'"},
            "wifi": {"state": "ERROR", "level": "error", "ssid": ssid},
            "meta": {"generated_local": now_iso()},
        })
        return False

    status_patch({
        "summary": {"state": "WIFI_CONNECTED", "level": "ok", "text": f"Connected to Wi-Fi '{ssid}'"},
        "wifi": {"state": "CONNECTED", "level": "ok", "ssid": ssid, "last_ok_local": now_iso()},
        "meta": {"generated_local": now_iso()},
    })

    # Make next boot managed
    set_boot_mode("managed")

    # Devices init only if config is blank

    # If installer provided a Shelly address/IP, prefer it.
    # We pre-seed SHELLY_HOST so radon-devices-init.sh will use it (and fall back to discovery if unreachable).
    shelly_host = (shelly_host or "").strip()
    if shelly_host:
        try:
            log(f"[onboard] Pre-seeding SHELLY_HOST={shelly_host!r} into {RADON_CONFIG}")
            set_kv_conf_value(RADON_CONFIG, "SHELLY_HOST", shelly_host)
            # Clear switch id so init can repopulate it for the selected device if needed.
            set_kv_conf_value(RADON_CONFIG, "SHELLY_SWITCH_ID", "")
        except Exception as e:
            log(f"[onboard] WARNING: failed pre-seeding SHELLY_HOST: {e!r}")
    if os.path.exists(RADON_DEVICES_INIT) and is_blank_device_config():
        status_patch({"summary": {"state": "DISCOVERING_DEVICES", "level": "warn", "text": "Initializing devices..."}})
        run_cmd(["/usr/bin/bash", RADON_DEVICES_INIT], timeout=300)

    # First run to generate chart/status promptly (best-effort)
    #if os.path.exists(RUN_RADON):
    #    status_patch({"summary": {"state": "FIRST_RUN", "level": "warn", "text": "Running first radon cycle..."}})
    #    run_cmd([RUN_RADON], timeout=300)

    status_patch({"summary": {"state": "POST_INSTALL", "level": "ok", "text": "Install complete — open /status"}})
    return True


# ---------------------------
# Status endpoints
# ---------------------------

def read_device_status() -> dict:
    try:
        with open(DEVICE_STATUS_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)

        # UX consistency: if the radon meter is still being discovered, don't show Chart=READY
        # from a previous run at the same time. (The chart file may exist from earlier, but it
        # shouldn't be presented as "ready" until we have a validated meter / first read.)
        air = data.get("airthings") or {}
        if not isinstance(air, dict):
            air = {}
        air_state = (air.get("state") or "").upper()
        read_obj = air.get("read") or {}
        if not isinstance(read_obj, dict):
            read_obj = {}
        last_ok = (air.get("last_ok_local") or read_obj.get("last_ok_local") or "").strip()
        summary_state = ((data.get("summary") or {}).get("state") or "").upper()
        chart = data.get("chart") or {}
        chart_state = (chart.get("state") or "").upper()
        if chart_state == "READY":
            # Only show READY when we have at least one successful read on this boot/installation.
            if ("DISCOVER" in summary_state) or (air_state in {"DISCOVERING", "NOT_FOUND", "UNKNOWN"}) or (air_state != "READ_OK" and not last_ok):
                chart = dict(chart)  # shallow copy
                chart["state"] = "NOT_READY"
                chart.setdefault("level", "warn")
                chart.setdefault("last_error", None)
                data["chart"] = chart

        # --- last radon reading timestamp (for Status "Updated" line) ---
        try:
            meta = data.get("meta") or {}
            if not isinstance(meta, dict):
                meta = {}
            air = data.get("airthings") or {}
            if not isinstance(air, dict):
                air = {}
            last_local = (
                air.get("last_ok_local")
                or air.get("last_read_local")
                or air.get("last_ok_time_local")
                or air.get("last_reading_local")
            )
            if not last_local:
                # Try persisted value from previous runs
                try:
                    with open(LAST_READING_PATH, "r", encoding="utf-8") as f:
                        saved = json.load(f)
                    if isinstance(saved, dict):
                        last_local = saved.get("time")
                except FileNotFoundError:
                    pass
                except Exception:
                    pass

            if last_local:
                meta["last_radon_reading_local"] = str(last_local)
                data["meta"] = meta
                # Persist for robustness (so UI can still show something if airthings keys change)
                try:
                    os.makedirs(os.path.dirname(LAST_READING_PATH), exist_ok=True)
                    with open(LAST_READING_PATH, "w", encoding="utf-8") as f:
                        json.dump({"time": str(last_local)}, f)
                except Exception:
                    pass
        except Exception:
            pass

        return data
    except Exception:
        return {}
    except FileNotFoundError:
        return {
            "summary": {"state": "SETUP_MODE", "level": "warn", "text": "Setup mode — enter Wi-Fi credentials at /"},
            "wifi": {"state": "AP_MODE", "level": "warn"},
            "shelly": {"state": "UNKNOWN", "level": "info"},
            "airthings": {"state": "UNKNOWN", "level": "info"},
            "chart": {"state": "NOT_READY", "level": "info", "path": CHART_PATH},
            "runtime": {"state": "IDLE", "level": "info"},
            "meta": {"generated_local": now_iso()},
        }
    except Exception as e:
        return {"summary": {"state": "ERROR", "level": "error", "text": f"Failed to read status: {e!r}"}}

NAV_HTML = """
<div class="row" style="margin-top:10px;">
  <a href="/status">Status</a>
  <a href="/setup">Setup</a>
  <a href="/radon-chart.png">Chart</a>
  <a href="/support">Support</a>
</div>
"""

STATUS_HTML = """
<!doctype html><html><head><title>RadonBox Status</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial; margin: 18px; line-height: 1.45; }
  .card { border:1px solid #ddd; border-radius:14px; padding:14px; max-width:860px; }
  .row { margin-top: 10px; }
  .k { font-weight: 800; }
  code { background:#f3f3f3; padding:2px 6px; border-radius:6px; }
  .ok { color:#0a7a2f; font-weight:800; }
  .warn { color:#8a5a00; font-weight:800; }
  .err { color:#b00020; font-weight:800; }
  .muted { color:#666; }
  a { margin-right: 12px; }
</style>
</head>
<body>
  <div class="card">
    <h2 style="margin:0 0 8px 0;">Status</h2>

    {{ nav|safe }}

    <div class="muted">
      Hostname: <code>{{ hostname }}</code> ·
      Mode: <code>{{ mode }}</code>
      Version: <code>{{ app_version }}</code>
    </div>

    <!-- NEW: System Configuration (read-only) -->
    <div style="margin-top:10px;">
      <div class="muted" style="font-weight:600; margin-bottom:4px;">
        System Configuration
      </div>
      <div class="muted">
        Fan ON level: <code>{{ radon_on }}</code> pCi/L ·
        Fan OFF level: <code>{{ radon_off }}</code> pCi/L ·<br>
        Run frequency: <code>{{ exec_freq_label }}</code>
      </div>
    </div>


    
<div id="main" class="row">Loading…</div>
    <div class="row muted">Updated: <code id="ts"></code></div>


    <div class="row" style="padding:10px; border:1px solid #eee; border-radius:12px;">
      <div class="muted" style="font-weight:800; margin-bottom:6px;">Device Discovery</div>
      <form method="post" action="/status/devices-retry" style="display:inline;">
        <button type="submit">Re-run device discovery</button>
      </form>
      <div class="muted" style="margin-top:6px;">
        Use this if the RadonMeter is not found.
      </div>
      {% if request.args.get("msg") %}
        <div class="muted" style="margin-top:8px;"><b>{{ request.args.get("msg") }}</b></div>
      {% endif %}
    </div>

  </div>
  <script>
    function cls(level) {
      if (level === "ok") return "ok";
      if (level === "error") return "err";
      return "warn";
    }

    // Render one line of status. For Chart, color is driven by state:
    //   READY -> green, NOT_READY -> brown/gold, ERROR -> red
    function line(label, obj) {
      const state = (obj && obj.state) ? String(obj.state).toUpperCase() : "";
      const level = (obj && obj.level) ? String(obj.level) : "info";
      const text  = (obj && obj.text) ? obj.text : (state ? state : "—");

      let css = cls(level);

      if (label === "Chart") {
        if (state === "READY") css = "ok";
        else if (state === "ERROR") css = "err";
        else css = "warn"; // NOT_READY (or anything else)
      }

      return `<div class="row"><span class="k">${label}:</span> <span class="${css}">${text}</span></div>`;
    }
async function tick() {
      const r = await fetch("/api/status", { cache: "no-store" });
      const j = await r.json();

      document.getElementById("main").innerHTML =
        line("Overall", j.summary) +
        line("Wi-Fi", j.wifi) +
        line("SmartPlug", j.shelly) +
        line("RadonMeter", j.airthings) +
        '<div style="margin-left:16px;font-size:0.9em">' +
        line("Battery", (j.airthings && j.airthings.battery) ? j.airthings.battery : null) +
        '</div>' +
        line("Chart", j.chart) +
        line("Runtime", j.runtime);

      const now = new Date();

      const latestRadon =
        (j.airthings && j.airthings.read && j.airthings.read.last_ok_local) ||
        (j.airthings && j.airthings.read && j.airthings.read.last_attempt_local) ||
        j.updated_local ||
        "";

      let latestFmt = "";
      if (latestRadon) {
        const d = new Date(latestRadon);
        if (!isNaN(d)) {
          latestFmt = d.toLocaleString();
        } else {
          latestFmt = latestRadon;
        }
      }

      document.getElementById("ts").textContent =
        now.toLocaleString() +
        (latestFmt ? (" · Latest radon reading: " + latestFmt) : "");
    }

    tick();
    setInterval(tick, 1500);
  </script>
</body>
</html>"""


# ---------------------------
# HTML: setup + success + error (concise)
# ---------------------------

INDEX_HTML = """
<!doctype html>
<html>
  <head>
    <title>RadonBox Wi-Fi Setup</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial; margin: 18px; line-height: 1.45; }
    label { display:block; margin-top:12px; font-weight:800; }

    input, select {
      width:100%;
      padding:10px;
      border-radius:10px;
      border:1px solid #ccc;
      margin-top:6px;
      box-sizing: border-box;   /* IMPORTANT: prevents overflow */
    }

    button { margin-top:14px; padding:12px 14px; border-radius:10px; border:1px solid #0a66c2; background:#0a66c2; color:#ffffff; font-weight:900; width:100%; }
    .muted { color:#666; }
    code { background:#f3f3f3; padding:2px 6px; border-radius:6px; }
    a { margin-right: 12px; }

    /* NEW: two-column row support (prevents overlap) */
    .row {
      display: flex;
      gap: 16px;
      align-items: flex-start;
      flex-wrap: wrap;          /* allows stacking on narrow screens */
    }
    .row > div {
      flex: 1 1 320px;          /* two columns when wide, stack when narrow */
      min-width: 0;             /* IMPORTANT: allows flex items to shrink */
    }
  </style>
  </head>
  <body>
    <h2 style="margin:0 0 8px 0;">RadonBox Wi-Fi Setup</h2>
    <div class="muted">
      You are connected to <b>RadonBox-Setup</b>.
    </div>

    <form method="post" action="/wifi">

      <label>Home Wi-Fi name (SSID)
        <input type="text" name="ssid" required>
      </label>

      <label>Home Wi-Fi password
        <input type="password" name="psk" required>
      </label>
      <label>Shelly plug address (optional)
        <input type="text" name="shelly_host" placeholder="e.g. ShellyPlugUSG4-XXXXXXXXXXXX.local or 192.168.1.10">
        <div class="muted" style="margin-top:6px;">
          Leave blank to auto-discover the Shelly plug on your home network.
        </div>
      </label>


      <button type="submit">Connect</button>
    </form>

    <p class="muted" style="margin-top:14px;">
      After you tap <b>Connect</b>, RadonBox will switch to your home Wi-Fi and this setup page will disconnect.
      You’ll reopen the status page using the access URL shown on the next screen.
    </p>
  </body>
</html>
"""

SUCCESS_HTML = """
<!doctype html>
<html>
  <head>
    <title>RadonBox Ready</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
      body {
        font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
        margin: 18px;
        line-height: 1.45;
        max-width: 720px;
      }
      h2 { margin: 0 0 8px 0; }
      .box {
        border: 1px solid #ddd;
        border-radius: 14px;
        padding: 14px;
        margin-top: 12px;
      }
      code {
        background: #f3f3f3;
        padding: 2px 6px;
        border-radius: 6px;
      }
      .muted { color: #666; }
    </style>
  </head>
  <body>
    <h2>RadonBox is ready ✅</h2>
    <div class="muted">Take a screenshot of this page now.</div>

    <div class="box">
      <div><b>Device name:</b> <code>{{ hostname }}</code></div>

      <div style="margin-top:12px;"><b>Preferred access:</b></div>
      <div><code>http://{{ hostname }}.local:8080/status</code></div>
      <div><code>http://{{ hostname }}.local:8080/setup</code></div>
      <div><code>http://{{ hostname }}.local:8080/radon-chart.png</code></div>

      {% if ip %}
      <div style="margin-top:12px;"><b>Fallback (always works):</b></div>
      <div><code>http://{{ ip }}:8080/status</code></div>
      <div><code>http://{{ ip }}:8080/setup</code></div>
      <div><code>http://{{ ip }}:8080/radon-chart.png</code></div>
      {% endif %}
    </div>

    <p class="muted" style="margin-top:14px;">
      If the <code>.local</code> address does not open on your phone or laptop,
      use the IP “Fallback” links above.
    </p>

    <p class="muted">
      Next: reconnect your phone to your normal home Wi-Fi after
      <b>RadonBox-Setup</b> disconnects.
    </p>
  </body>
</html>
"""

ERROR_HTML = """
<!doctype html>
<html>
  <head>
    <title>RadonBox Error</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
      body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial; margin: 18px; color:#b00020; }
      a { color: #0645ad; }
    </style>
  </head>
  <body>
    <h2>Onboarding Error</h2>
    <p>RadonBox could not connect to the Wi-Fi network with the credentials provided.</p>
    <p><a href="/">Back to setup</a></p>
  </body>
</html>
"""


# ---------------------------

SYSTEM_HTML = """
<!doctype html>
<html>
  <head>
    <title>RadonBox Setup</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
      body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial; margin: 18px; line-height: 1.45; max-width: 860px; }
      .card { border:1px solid #ddd; border-radius:14px; padding:14px; }
      label { display:block; margin-top:12px; font-weight:800; }
      input, select {
        width:100%;
        padding:10px;
        border-radius:10px;
        border:1px solid #ccc;
        margin-top:6px;
        box-sizing: border-box;   /* prevents overlap from padding/border */
      }

      button { margin-top:14px; padding:12px 14px; border-radius:10px; border:1px solid #0a66c2; background:#0a66c2; color:#fff; font-weight:900; }
      .danger { background:#b00020; border-color:#b00020; }

      .muted { color:#666; }
      code { background:#f3f3f3; padding:2px 6px; border-radius:6px; }
      .row { margin-top: 10px; }
      a { margin-right: 12px; }
      .ok { color:#0a7a2f; font-weight:800; }
      .warn { color:#8a5a00; font-weight:800; }
      .err { color:#b00020; font-weight:800; }

      /* Two-column form grid (inputs only) */
      .grid { display:grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
      .grid > div { min-width: 0; }
      
      .grid .full { grid-column: 1 / -1; }
      @media (max-width: 740px) { .grid { grid-template-columns: 1fr; } }

      /* Left-rail blocks for secondary controls + actions */
      .stack { margin-top: 12px; max-width: 420px; }
      .actions { margin-top: 18px; max-width: 420px; }
      .actions button { width: 100%; }
      .hint {
        margin-top: 6px;
        color: #666;
        text-align: left;
      }
    </style>
  </head>
  <body>
    <div class="card">
      <h2 style="margin:0 0 8px 0;">Setup</h2>

      {{ nav|safe }}

    <div class="muted">Hostname: <code>{{ params.hostname }}</code> · Mode: <code>{{ mode }}</code></div>

      <form method="post" action="/setup">
        <div class="grid">
          <div>
            <label>Execution Frequency
              <select name="execution_frequency">
                <option value="1" {% if params.execution_frequency == 1 %}selected{% endif %}>
                  1 — daily at noon
                </option>
                <option value="2" {% if params.execution_frequency == 2 %}selected{% endif %}>
                  2 — daily at noon + midnight
                </option>
              </select>
            </label>
          </div>

          <div></div>

          <div>
            <label>Radon Level ON Threshold (pCi/L)
              <input type="number" step="0.01" min="0" name="radon_on_threshold" value="{{ params.radon_on_threshold }}">
            </label>
          </div>

          <div>
            <label>Radon Level OFF Threshold (pCi/L)
              <input type="number" step="0.01" min="0" name="radon_off_threshold" value="{{ params.radon_off_threshold }}">
            </label>
          </div>

          <div class="hint full">
            A wider difference (ON − OFF) can reduce fan cycling.
          </div>
        </div>

        <!-- Placeholder kept, but aligned on the left rail -->
        <div class="stack">
          <label>Evening Fan Off (placeholder)
            <select name="evening_fan_off" disabled>
              <option selected>NO</option>
            </select>
          </label>
        </div>

        <div class="actions">
          <button type="submit">Save &amp; Go to Status</button>
          <div class="muted row">Changes take effect immediately for scheduling and on the next radon run for thresholds.</div>
        </div>
      </form>

      <hr style="margin:18px 0; border:none; border-top:1px solid #eee;">

      <form method="post" action="/factory-reset" onsubmit="return confirm('Factory reset will reboot into Setup Mode. Continue?');">
        <div class="actions">
          <button type="submit" class="danger">Factory Reset</button>
        </div>
        <div class="muted row">Erases Wi-Fi and system settings, then reboots into <b>RadonBox-Setup</b> mode.</div>
      </form>

      {% if msg %}
        <p class="row ok">✅ {{ msg }}</p>
      {% endif %}
      {% if err %}
        <p class="row err">❌ {{ err }}</p>
      {% endif %}
    </div>
  </body>
</html>
"""

SUPPORT_HTML = """
<!doctype html>
<html>
<head>
  <title>RadonBox Support</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
      margin: 18px;
      line-height: 1.45;
    }
    .card {
      border:1px solid #ddd;
      border-radius:14px;
      padding:14px;
      max-width:860px;
    }
    h2 { margin:0 0 8px 0; }
    .muted { color:#666; }
    code {
      background:#f3f3f3;
      padding:2px 6px;
      border-radius:6px;
    }
    button {
      margin-top:10px;
      padding:10px 14px;
      border-radius:10px;
      border:1px solid #0a66c2;
      background:#0a66c2;
      color:#fff;
      font-weight:800;
      cursor:pointer;
    }
    pre {
      background:#f7f7f7;
      border:1px solid #ddd;
      border-radius:10px;
      padding:10px;
      overflow-x:auto;
      white-space:pre-wrap;
      word-break:break-word;
      margin-top:6px;
    }
    a { margin-right:12px; }
  </style>
</head>
<body>
  <div class="card">
    <h2>Support</h2>

    {{ nav|safe }}

    <div class="muted" style="margin-top:6px;">
      Current Version: <code>{{ app_version }}</code>
    </div>

    <div style="margin-top:14px;">
      <form method="post" action="/support/stage">
        <input type="hidden" name="latest_url" value="{{ latest_url }}">
        <button type="submit">Check &amp; Install Software Update</button>
      </form>
      <div class="muted" style="margin-top:6px;">
        Downloads, verifies, installs, and activates the latest software. The portal will briefly restart during activation.
      </div>
    </div>

    <hr style="margin:16px 0; border:none; border-top:1px solid #eee;">

    <div>
      <div class="muted" style="font-weight:600;">Update Status</div>
      <pre>{{ update_status | tojson(indent=2) }}</pre>
    </div>

    <div style="margin-top:12px;">
      <div class="muted" style="font-weight:600;">Update Log (tail)</div>
      <pre>{{ update_log_tail }}</pre>
    </div>

  </div>
<script>
(function () {
  try {
    const pre = document.querySelector("pre");
    if (!pre) return;

    const txt = pre.textContent || "";
    if (!txt.includes('"state"')) return;

    const m = txt.match(/"state"\\s*:\\s*"([^"]+)"/);

    if (!m) return;

    const state = m[1];

    const busyStates = [
      "STARTING",
      "CHECKING",
      "DOWNLOADING",
      "VERIFYING",
      "UNPACKING",
      "STAGING",
      "VALIDATING",
      "ACTIVATING"
    ];

    if (busyStates.includes(state)) {
      setTimeout(() => { location.reload(); }, 4000);
    }
  } catch (e) {}
})();
</script>
</body>
</html>
"""

# ---------------------------
# Factory settings (Beta4)
# ---------------------------

FACTORY_CRON = "/etc/cron.d/radonbox"
FACTORY_DEFAULTS = {
    "execution_frequency": 1,
    "radon_on_threshold": 2.0,
    "radon_off_threshold": 1.5,
}

def _parse_kv_conf(path: str) -> dict:
    out = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    except FileNotFoundError:
        return {}
    except Exception as e:
        log(f"[factory] Failed reading {path}: {e!r}")
        return {}
    return out

def _upsert_kv_conf(path: str, updates: dict) -> None:
    """
    Update keys in a simple KEY=VALUE file, preserving comments/unknown keys.
    Creates the file if missing.
    """
    lines = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except FileNotFoundError:
        lines = ["# RadonBox device config\n"]
    except Exception as e:
        log(f"[factory] Failed opening {path} for update: {e!r}")
        lines = ["# RadonBox device config\n"]

    remaining = dict(updates)

    new_lines = []
    for raw in lines:
        m = re.match(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$', raw)
        if not m:
            new_lines.append(raw)
            continue
        k = m.group(1).strip()
        if k in remaining:
            new_lines.append(f"{k}={remaining.pop(k)}\n")
        else:
            new_lines.append(raw)

    for k, v in remaining.items():
        new_lines.append(f"{k}={v}\n")

    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.writelines(new_lines)

def read_factory_settings() -> dict:
    conf = _parse_kv_conf(RADON_CONFIG)
    params = dict(FACTORY_DEFAULTS)

    try:
        if conf.get("RADON_EXECUTION_FREQUENCY"):
            params["execution_frequency"] = int(conf["RADON_EXECUTION_FREQUENCY"])
    except Exception:
        pass

    try:
        if conf.get("RADON_ON_THRESHOLD"):
            params["radon_on_threshold"] = float(conf["RADON_ON_THRESHOLD"])
    except Exception:
        pass

    try:
        if conf.get("RADON_OFF_THRESHOLD"):
            params["radon_off_threshold"] = float(conf["RADON_OFF_THRESHOLD"])
    except Exception:
        pass

    # Always show current hostname
    params["hostname"] = get_pi_hostname()
    params["evening_fan_off"] = "NO"
    return params

def write_factory_settings(execution_frequency: int, on_thr: float, off_thr: float) -> None:
    _upsert_kv_conf(RADON_CONFIG, {
        "RADON_EXECUTION_FREQUENCY": str(execution_frequency),
        "RADON_ON_THRESHOLD": f"{on_thr:.2f}",
        "RADON_OFF_THRESHOLD": f"{off_thr:.2f}",
    })

def apply_schedule(execution_frequency: int) -> None:
    """
    execution_frequency:
      1 -> noon
      2 -> noon + midnight

    Writes:
      - /etc/cron.d/radonbox (authoritative, deterministic)

    Also performs a one-time cleanup of any legacy root-crontab RadonBox schedule
    lines to prevent double-execution (some older betas wrote both locations).
    """
    freq = 1 if execution_frequency != 2 else 2

    # 1) /etc/cron.d (authoritative)
    cron_lines = [
        "# RadonBox schedule (managed by portal)\n",
        "SHELL=/bin/bash\n",
        "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n",
        "\n",
        f"0 12 * * * root {RUN_RADON} >/dev/null 2>&1\n",
    ]
    if freq == 2:
        cron_lines.append(f"0 0 * * * root {RUN_RADON} >/dev/null 2>&1\n")

    with open(FACTORY_CRON, "w", encoding="utf-8") as f:
        f.writelines(cron_lines)
    # Best-effort nudge cron to reload
    try:
        run_cmd(["systemctl", "restart", "cron"], timeout=20)
    except Exception:
        pass
    # 2) Clean up any legacy root-crontab schedule entries (do NOT add new ones)
    _cleanup_root_crontab_radon_schedule()


def _cleanup_root_crontab_radon_schedule() -> None:
    """
    Ensure root's crontab does NOT schedule run-radon.sh.

    Authoritative scheduling is in /etc/cron.d/radonbox.

    This removes:
      - the delimited RadonBox block (BEGIN/END), if present
      - any stray lines containing RUN_RADON (belt & suspenders)

    It intentionally does NOT touch unrelated entries (e.g., your nightly 03:00 reboot).
    """
    BEGIN = "# RadonBox schedule (managed by portal)"
    END = "# End RadonBox schedule"

    rc, out, _ = run_cmd(["crontab", "-l"], timeout=10)
    existing = out if rc == 0 else ""

    keep = []
    in_block = False
    for line in existing.splitlines():
        s = line.strip()

        # Remove the whole delimited block
        if s == BEGIN:
            in_block = True
            continue
        if s == END:
            in_block = False
            continue
        if in_block:
            continue

        # Also remove any stray run-radon lines (legacy/manual)
        if RUN_RADON in line:
            continue

        keep.append(line)

    # Avoid trailing blank spam; preserve other cron content exactly
    new_lines = [l for l in keep if l.strip() != ""]
    content = ("\n".join(new_lines).rstrip() + "\n") if new_lines else ""

    tmp = "/tmp/radonbox-root-crontab.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(content)
        run_cmd(["crontab", tmp], timeout=10)
    except Exception as e:
        log(f"[cron] WARNING: failed cleaning root crontab: {e!r}")



# Routes
# ---------------------------

@app.route("/api/update/check")
def api_update_check():
    latest_url = (request.args.get("latest_url") or LATEST_URL_DEFAULT).strip()

    if not _is_safe_latest_url(latest_url):
        return jsonify({"ok": False, "error": "Blocked: latest_url not allowed"}), 400

    running = _read_running_version() or "unknown"
    try:
        j = _read_latest_json(latest_url)
    except Exception as e:
        return jsonify({"ok": False, "running": running, "error": str(e)}), 500

    latest_ver = str(j.get("version") or "").strip() or "unknown"
    update_available = (running != "unknown" and latest_ver != "unknown" and running != latest_ver)

    return jsonify({
        "ok": True,
        "running": running,
        "latest": latest_ver,
        "update_available": update_available,
        "notes": j.get("notes", ""),
        "bundle_url": j.get("bundle_url", ""),
        "sig_url": j.get("sig_url", ""),
    })


@app.route("/api/update/stage", methods=["POST"])
def api_update_stage():
    # allow override from UI, but validate it strictly
    latest_url = (request.form.get("latest_url") or LATEST_URL_DEFAULT).strip()

    if not _is_safe_latest_url(latest_url):
        return jsonify({"ok": False, "error": "Blocked: latest_url not allowed"}), 400

    # Stage update using your existing script
    rc, out = _run_cmd(
        ["/usr/local/sbin/radonbox-update.sh", latest_url],
        timeout_sec=180,
    )

    # If you already have write_update_status()/log helpers, you can call them here.
    # But returning output is enough for now.
    return jsonify({
        "ok": (rc == 0),
        "rc": rc,
        "output": out[-8000:],  # keep response bounded
    })


@app.route("/", methods=["GET"])
def index():
    return render_template_string(INDEX_HTML)


@app.route("/wifi", methods=["POST"])
def wifi():
    log("===== NEW /wifi SUBMISSION =====")
    try:
        ssid = (request.form.get("ssid") or "").strip()
        psk = (request.form.get("psk") or "").strip()
        shelly_host = (request.form.get("shelly_host") or "").strip()

        # Hostname is auto-generated (no user input)
        req_hostname = default_unique_hostname()
        log(f"[wifi] Using auto hostname {req_hostname!r}")
        apply_hostname(req_hostname)

        hostname_now = get_pi_hostname()
        log(f"[wifi] hostname_now={hostname_now!r} ssid={ssid!r}")

        def _bg_onboard():
            try:
                time.sleep(2)
                ok = try_onboard(ssid, psk, shelly_host=shelly_host)
                log(f"[wifi/_bg_onboard] try_onboard ok={ok}")
            except Exception as e:
                log(f"[wifi/_bg_onboard] EXCEPTION: {e!r}")

        threading.Thread(target=_bg_onboard, daemon=True).start()
        return render_template_string(
            SUCCESS_HTML,
            hostname=req_hostname,
            ip=get_wlan0_ipv4(),
        ), 200

    except Exception as e:
        log(f"[wifi] EXCEPTION: {e!r}")
        return "Internal error during onboarding", 500



@app.route("/status/devices-retry", methods=["POST"])
def status_devices_retry():
    """
    Deterministic manual action exposed in /status:
    Re-run radon-devices-init.sh to repopulate /etc/radonbox/radon-config.conf.
    """
    msg = ""
    try:
        if not os.path.exists(RADON_DEVICES_INIT):
            msg = "radon-devices-init.sh not found"
        else:
            status_patch({"summary": {"state": "DISCOVERING_DEVICES", "level": "warn", "text": "Running device discovery..."}})
            rc, out, err = run_cmd(["/usr/bin/bash", RADON_DEVICES_INIT], timeout=300)
            conf = _parse_kv_conf(RADON_CONFIG)
            air = (conf.get("AIR_MAC") or "").strip()
            shelly = (conf.get("SHELLY_HOST") or "").strip()
            if rc == 0 and air:
                msg = f"Device discovery OK. AIR_MAC={air}" + (f" SHELLY_HOST={shelly}" if shelly else "")
            else:
                missing = [k for k in ("SHELLY_HOST","AIR_MAC","SHELLY_SWITCH_ID") if not (conf.get(k) or "").strip()]
                msg = ("Device discovery incomplete: missing " + ",".join(missing)) if missing else "Device discovery finished (check logs if issues persist)"
    except Exception as e:
        msg = f"Device discovery failed: {e!r}"
    try:
        return redirect("/status?msg=" + str(msg).replace(" ", "%20"))
    except Exception:
        return redirect("/status")


@app.route("/api/status", methods=["GET"])
def api_status():
    return read_device_status()


@app.route("/status", methods=["GET"])
def status_page():
    cfg = read_kv_conf(RADON_CONFIG)

    # Execution frequency label for display
    exec_raw = (cfg.get("RADON_EXECUTION_FREQUENCY") or "1")
    exec_label = exec_raw
    try:
        f = int(str(exec_raw).strip())
        if f == 1:
            exec_label = "1 — daily at noon"
        elif f == 2:
            exec_label = "2 — daily at noon + midnight"
        else:
            exec_label = str(f)
    except Exception:
        pass

    app_version = read_app_version()

    return render_template_string(
        STATUS_HTML,
	nav=NAV_HTML,
        hostname=get_pi_hostname(),
        mode=get_boot_mode(),
        radon_on=(cfg.get("RADON_ON_THRESHOLD") or "2.0"),
        radon_off=(cfg.get("RADON_OFF_THRESHOLD") or "1.5"),
        exec_freq_label=exec_label,
        app_version=read_app_version(),
    )


@app.route("/system", methods=["GET", "POST"])
def system_redirect():
    # Back-compat: old URL now points to Setup.
    # Use 307 for POST so the browser preserves method and form data.
    code = 307 if request.method == "POST" else 302
    return redirect("/setup", code=code)


@app.route("/setup", methods=["GET", "POST"])
def setup_page():
    msg = ""
    err = ""

    if request.method == "POST":
        # Hostname + Evening Fan Off are placeholders for Beta4 (not editable here)
        try:
            exec_freq = int((request.form.get("execution_frequency") or "1").strip())
            if exec_freq not in (1, 2):
                raise ValueError("execution_frequency must be 1 or 2")

            on_thr = float((request.form.get("radon_on_threshold") or "2.0").strip())
            off_thr = float((request.form.get("radon_off_threshold") or "1.5").strip())

            if on_thr <= 0 or off_thr < 0:
                raise ValueError("thresholds must be non-negative, and ON must be > 0")
            if off_thr >= on_thr:
                raise ValueError("OFF threshold must be less than ON threshold")

            write_factory_settings(exec_freq, on_thr, off_thr)
            apply_schedule(exec_freq)

            # UX: after a successful save, go to Status so the installer
            # can immediately verify the active configuration.
            return redirect("/status", code=302)

        except Exception as e:
            err = str(e)

    params = read_factory_settings()
    # Reflect posted values even if save failed (so installer sees what they entered)
    if request.method == "POST":
        try:
            params["execution_frequency"] = int((request.form.get("execution_frequency") or params["execution_frequency"]))
        except Exception:
            pass
        try:
            params["radon_on_threshold"] = float((request.form.get("radon_on_threshold") or params["radon_on_threshold"]))
        except Exception:
            pass
        try:
            params["radon_off_threshold"] = float((request.form.get("radon_off_threshold") or params["radon_off_threshold"]))
        except Exception:
            pass

    return render_template_string(SYSTEM_HTML, nav=NAV_HTML, params=params, mode=get_boot_mode(), msg=msg, err=err)


@app.route("/support", methods=["GET"])
def support():
    current = read_app_version()
    st = read_update_status()

    # If the staged status is for the same version we're already running,
    # reflect that clearly in the UI to avoid confusion.
    if st and st.get("version") == current and st.get("state") in ("READY", "OK", "UP_TO_DATE"):
        st["state"] = "UP_TO_DATE"
        st["message"] = "Already running this version. No update needed."

    return render_template_string(
        SUPPORT_HTML,
        nav=NAV_HTML,
        app_version=current,
        latest_url=LATEST_URL_DEFAULT,
        update_status=st,
        update_log_tail=tail_file(UPDATE_LOG_PATH, 40),
    )


@app.route("/support/stage", methods=["POST"])
def support_stage():
    latest_url = request.form.get("latest_url", LATEST_URL_DEFAULT)
    latest_url = (latest_url or "").strip()
    if not (latest_url.startswith("https://www.smartradonfan.com/updates/") or
            latest_url.startswith("https://smartradonfan.com/updates/")):
        return jsonify({"ok": False, "error": "Invalid update source"}), 400

    # Immediate UI feedback on first click
    write_update_status({
        "state": "STARTING",
        "message": "Starting update check/install...",
        "latest_url": latest_url,
        "time": now_iso(),
        "version": "",
    })

    # Run updater in a separate transient systemd unit so restarting radon-portal
    # during activation does NOT kill the updater (different cgroup).
    try:
        unit = f"radonbox-update-{int(time.time())}"
        subprocess.Popen(
            ["sudo", "/usr/bin/systemd-run",
             "--unit", unit,
             "--collect",
             "--no-block",
             UPDATER_PATH, latest_url],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            start_new_session=True,
        )
    except Exception as e:
        write_update_status({
            "state": "ERROR",
            "message": f"Failed to start updater: {e}",
            "latest_url": latest_url,
            "time": now_iso(),
            "version": "",
        })

    return redirect("/support")
@app.post("/factory-reset")
def factory_reset():
    try:
        subprocess.Popen(
            ["/usr/local/sbin/radon-factory-reset.sh"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except Exception as e:
        log(f"Factory reset spawn failed: {e!r}")
        return "Error initiating factory reset", 500

    return """
    <html><body>
      <h2>Factory Reset in Progress</h2>
      <p>Your RadonBox is restarting into <b>Setup Mode</b>.</p>
      <p>In about 1–2 minutes, look for the Wi-Fi network <b>RadonBox-Setup</b>.</p>
    </body></html>
    """


@app.route("/radon-chart.png")
def radon_chart_png():
    if not os.path.exists(CHART_PATH):
        return (
            "<html><body><h3>No radon chart yet</h3>"
            "<p>Once run-radon.sh has run at least once, refresh this page.</p>"
            "</body></html>",
            404,
        )
    return send_file(CHART_PATH, mimetype="image/png")


if __name__ == "__main__":
    mode = get_boot_mode()
    log("=== RadonBox portal starting ===")
    log(f"Boot mode: {mode}")

    if mode == "ap":
        status_patch({
            "summary": {"state": "SETUP_MODE", "level": "warn", "text": "Setup mode — enter Wi-Fi credentials at /"},
            "wifi": {"state": "AP_MODE", "level": "warn"},
            "meta": {"generated_local": now_iso()},
        })

    app.run(host="0.0.0.0", port=8080, debug=False)
