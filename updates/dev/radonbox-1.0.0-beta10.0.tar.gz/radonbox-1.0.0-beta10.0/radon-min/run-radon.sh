#!/usr/bin/env bash
#
#
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "[run-radon] ERROR: must be run as root (use sudo)" >&2
  exit 1
fi

# Base directory = the directory this script lives in (product-grade)
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG="$BASE/radon-log.txt"
CHART="$BASE/radon-chart.png"
CONFIG="/etc/radonbox/radon-config.conf"

# Use the release's status updater (not /usr/local/bin legacy)
STATUS_UPDATER="$BASE/radon-status-update.py"

trim_log_if_needed() {
  local LOG_PATH="$1"
  local MAX_LINES=8000

  mkdir -p "$(dirname "$LOG_PATH")"
  if [ ! -f "$LOG_PATH" ]; then
    : > "$LOG_PATH"
    chmod 664 "$LOG_PATH" 2>/dev/null || true
    return 0
  fi

  local LINE_COUNT
  LINE_COUNT=$(wc -l < "$LOG_PATH" 2>/dev/null || echo 0)

  if [ "$LINE_COUNT" -le "$MAX_LINES" ]; then
    return 0
  fi

  tail -n "$MAX_LINES" "$LOG_PATH" > "${LOG_PATH}.tmp"
  mv -f "${LOG_PATH}.tmp" "$LOG_PATH"
  chmod 664 "$LOG_PATH" 2>/dev/null || true
}

status_patch() {
  # usage: status_patch '{"summary":{...}}'
  [[ -x "$STATUS_UPDATER" ]] || return 0
  timeout 15s "$STATUS_UPDATER" "$1" >/dev/null 2>&1 || true
}

# Return last NON-EMPTY value for KEY= from CONFIG
get_cfg() {
  local key="$1"
  [[ -f "$CONFIG" ]] || { echo ""; return 0; }
  grep -E "^${key}=" "$CONFIG" 2>/dev/null \
    | sed -E "s/^${key}=//" \
    | tr -d '\r' \
    | awk 'NF{v=$0} END{print v}'
}

# ---- single-instance lock (skip if already running) ----
LOCKDIR="/run/radonbox"
LOCKFILE="$LOCKDIR/run-radon.lock"
mkdir -p "$LOCKDIR"
chmod 755 "$LOCKDIR" 2>/dev/null || true

exec 9>"$LOCKFILE"
if ! flock -n 9; then
  # already running — exit quietly
  exit 0
fi

mkdir -p "$BASE"
cd "$BASE"

trim_log_if_needed "$LOG"

now_iso="$(date -Is)"
echo
echo "[run-radon] ===== run-radon.sh start @ ${now_iso} =====" | tee -a "$LOG"

status_patch '{
  "chart":{"state":"READY","level":"ok","path":"'"$CHART"'","last_error":null},
  "runtime":{"state":"IDLE","level":"ok","last_run_local":"'"$(date -Is)"'","last_error":null}}'

CONF="/etc/radonbox/radon-config.conf"

echo "[run-radon] Loading device config from $CONF" | tee -a "$LOG"

if [[ ! -f "$CONF" ]]; then
  echo "[run-radon] ERROR: missing $CONF" | tee -a "$LOG"
  exit 1
fi

bad_line=$(grep -En "^[A-Za-z_][A-Za-z0-9_]*=[^\"'#[:space:]]+[[:space:]]+[^\"'#[:space:]]+" "$CONF" | head -n1 || true)
if [[ -n "$bad_line" ]]; then
  echo "[run-radon] ERROR: unquoted config value with spaces in $CONF: $bad_line" | tee -a "$LOG"
  exit 1
fi

# Export variables defined in the config file
set -a
# shellcheck disable=SC1090
source "$CONF"
set +a

echo "[run-radon] Loaded config: SHELLY_HOST='${SHELLY_HOST:-}' AIR_MAC='${AIR_MAC:-}' SHELLY_SWITCH_ID='${SHELLY_SWITCH_ID:-}' RADON_ON_THRESHOLD='${RADON_ON_THRESHOLD:-}' RADON_OFF_THRESHOLD='${RADON_OFF_THRESHOLD:-}'" | tee -a "$LOG"

env | grep -E '^(SHELLY_HOST|AIR_MAC|SHELLY_SWITCH_ID|RADON_ON_THRESHOLD|RADON_OFF_THRESHOLD)=' | tee -a "$LOG" || true

echo "[run-radon] Running radon-automation.py..." | tee -a "$LOG"
status_patch '{
  "runtime":{"state":"READING_RADON","level":"warn"}
}'

if ! /usr/bin/python3 -u "$BASE/radon-automation.py" 2>&1 | tee -a "$LOG"; then
  echo "[run-radon] ERROR: radon-automation.py failed. Exiting." | tee -a "$LOG"
  status_patch '{
    "runtime":{"state":"ERROR","level":"error","last_error":"radon-automation.py failed"},
    "summary":{"state":"ERROR","level":"error","text":"Radon read failed — will retry on next scheduled run"}
  }'
  exit 1
fi

echo "[run-radon] radon-automation.py completed successfully." | tee -a "$LOG"
status_patch '{
  "runtime":{"state":"RADON_AUTOMATION_OK","level":"ok","last_error":null}
}'

# If we got a successful radon read, Airthings is no longer "discovering".
# Promote Airthings status to OK to avoid stale install-phase state lingering.
status_patch '{
  "airthings":{
    "state":"OK",
    "level":"ok",
    "mac":"'"${AIR_MAC:-}"'",
    "last_error":null
  }
}'

echo "[run-radon] Generating chart from $LOG -> $CHART ..." | tee -a "$LOG"
if /usr/bin/python3 "$BASE/generate-radon-chart.py" --log "$LOG" --output "$CHART"; then
  echo "[$(date -Is)] Chart updated: ${CHART}" | tee -a "$LOG"
  status_patch '{
    "chart":{"state":"READY","level":"ok","path":"'"$CHART"'","last_error":null},
    "runtime":{"state":"IDLE","level":"ok","last_run_local":"'"$(date -Is)"'","last_error":null}}'
else
  echo "[run-radon] WARNING: generate-radon-chart.py failed." | tee -a "$LOG"
  status_patch '{
    "chart":{"state":"ERROR","level":"warn","path":"'"$CHART"'","last_error":"generate-radon-chart.py failed"},
    "runtime":{"state":"IDLE","level":"warn","last_run_local":"'"$(date -Is)"'","last_error":"generate-radon-chart.py failed"}}'
fi

chmod 664 "$LOG" "$CHART" 2>/dev/null || true

now_iso="$(date -Is)"
echo "[$now_iso] Run complete." | tee -a "$LOG"
echo "[run-radon] ===== run-radon.sh end @ ${now_iso} =====" | tee -a "$LOG"
echo
