#!/bin/bash
set -e

##############################################################################
# TAILSCALE BETA SUPPORT AUTH KEY
#
# Leave blank ("") to disable automatic Tailscale enrollment on prepared SDs.
# For Beta SD builds, paste the current reusable Tailscale auth key between
# the quotes below, for example:
#
# TAILSCALE_AUTH_KEY="tskey-auth-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
#
# The prepared SD will keep this auth key file but will NOT keep any cloned
# Tailscale machine identity.
##############################################################################

TAILSCALE_AUTH_KEY="tskey-auth-kFEzUUAb4Z11CNTRL-GATjmRVGaCP1ePoUCU6xBPzDRJHuTASd"

echo "[image-prepare] Starting golden image prep..."

echo "[image-prepare] Running radon-reset.sh..."
sudo /opt/radonbox/current/radon-min/radon-reset.sh

echo "[image-prepare] Removing device identity..."
sudo rm -f /etc/radonbox/device-identity.json

echo "[image-prepare] Removing install-date.txt..."
sudo rm -f /etc/radonbox/install-date.txt

echo "[image-prepare] Cleaning logs..."
sudo rm -rf /var/log/radonbox/*
sudo rm -rf /var/log/srf-site-report/*

echo "[image-prepare] Clearing temp/state files..."
sudo rm -f /var/lock/run-radon.lock
sudo rm -f /tmp/*radon*


echo "[image-prepare] Removing Tailscale machine identity..."
# Do not run 'tailscale logout' during image preparation: it can block while
# contacting the Tailscale control plane. For SD cloning, the essential step is
# to stop tailscaled and remove the local machine identity state.
sudo systemctl stop tailscaled 2>/dev/null || true
sudo rm -f /var/lib/tailscale/tailscaled.state

echo "[image-prepare] Configuring optional Tailscale Beta support auth key..."
if [ -n "$TAILSCALE_AUTH_KEY" ]; then
    if [[ "$TAILSCALE_AUTH_KEY" == tskey-* ]]; then
        sudo mkdir -p /etc/radonbox
        echo "$TAILSCALE_AUTH_KEY" | sudo tee /etc/radonbox/tailscale-auth-key >/dev/null
        sudo chown root:root /etc/radonbox/tailscale-auth-key
        sudo chmod 600 /etc/radonbox/tailscale-auth-key
        echo "[image-prepare] Installed /etc/radonbox/tailscale-auth-key"
    else
        echo "[image-prepare] WARNING: TAILSCALE_AUTH_KEY is non-empty but does not look like a Tailscale key."
        echo "[image-prepare] Removing /etc/radonbox/tailscale-auth-key to avoid installing an invalid key."
        sudo rm -f /etc/radonbox/tailscale-auth-key
    fi
else
    echo "[image-prepare] No TAILSCALE_AUTH_KEY specified; removing any existing auth key file."
    sudo rm -f /etc/radonbox/tailscale-auth-key
fi


echo "[image-prepare] Done. Powering down..."
sudo shutdown -h now