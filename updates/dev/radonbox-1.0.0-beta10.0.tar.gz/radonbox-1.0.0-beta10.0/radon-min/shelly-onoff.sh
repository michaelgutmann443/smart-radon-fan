#!/bin/bash
# shelly-onoff.sh
# Usage: sudo ./shelly-onoff.sh <SHELLY_IP> <ON|OFF>

IP="$1"
STATE="$(echo "$2" | tr '[:lower:]' '[:upper:]')"

if [ -z "$IP" ] || [[ "$STATE" != "ON" && "$STATE" != "OFF" ]]; then
  echo "Usage: $0 <SHELLY_IP> <ON|OFF>"
  exit 1
fi

if [ "$STATE" = "ON" ]; then
  JSON='{"id":0,"on":true}'
else
  JSON='{"id":0,"on":false}'
fi

echo "Forcing Shelly $IP $STATE..."

curl -s --max-time 5 \
  -X POST "http://$IP/rpc/Switch.Set" \
  -H "Content-Type: application/json" \
  -d "$JSON"

echo
echo "Verifying..."
curl -s --max-time 5 "http://$IP/rpc/Switch.GetStatus?id=0"
echo