#!/usr/bin/env python3
"""
Boris generate-radon-chart.py

Log format (CSV lines written by radon-automation.py):
    legacy: timestamp_iso,short_pci,long_pci,fan_state,install_flag,reason
    current: timestamp_iso,short_pci,it_pci_or_blank,airthings_lt_pci,fan_state,install_flag,reason
    beta10: timestamp_iso,short_pci,it_pci_or_blank,airthings_lt_pci,fan_state,install_flag,fan_verified,reason
"""

import os
import sys
import csv
from datetime import datetime, timedelta

import matplotlib.pyplot as plt
import matplotlib.dates as mdates

CONFIG_PATH = "/etc/radonbox/radon-config.conf"

def _read_kv_conf(path: str) -> dict:
    kv = {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for raw in f:
                s = raw.strip()
                if not s or s.startswith('#') or '=' not in s:
                    continue
                k, v = s.split('=', 1)
                kv[k.strip()] = v.strip()
    except FileNotFoundError:
        return {}
    except Exception:
        return {}
    return kv

def _normalize_dt(dt: datetime) -> datetime:
    # Ensure offset-aware datetimes are converted to local naive for subtraction/plotting.
    if getattr(dt, 'tzinfo', None) is not None and dt.tzinfo is not None:
        try:
            return dt.astimezone().replace(tzinfo=None)
        except Exception:
            return dt.replace(tzinfo=None)
    return dt

def _parse_dt(val: str) -> datetime | None:
    if not val:
        return None
    v = str(val).strip()
    try:
        # Epoch seconds?
        if v.replace('.', '', 1).isdigit():
            return datetime.fromtimestamp(float(v))
    except Exception:
        pass
    try:
        dt = datetime.fromisoformat(v)
        return _normalize_dt(dt)
    except Exception:
        return None

def _get_settling_info() -> tuple[datetime | None, datetime | None, float | None]:
    kv = _read_kv_conf(CONFIG_PATH)
    install_dt = None
    if kv.get('INSTALL_ISO'):
        install_dt = _parse_dt(kv.get('INSTALL_ISO', ''))
    if install_dt is None and kv.get('INSTALL_TS'):
        install_dt = _parse_dt(kv.get('INSTALL_TS', ''))
    if install_dt is None:
        return None, None, None

    valid_dt = None
    if kv.get('RADON_VALID_AFTER_TS'):
        valid_dt = _parse_dt(kv.get('RADON_VALID_AFTER_TS', ''))
    if valid_dt is None:
        try:
            settle_s = int(str(kv.get('RADON_SETTLE_SECONDS', '86400')).strip() or '86400')
        except Exception:
            settle_s = 86400
        valid_dt = install_dt + timedelta(seconds=settle_s)

    install_dt = _normalize_dt(install_dt)
    valid_dt = _normalize_dt(valid_dt)
    try:
        dur_h = max(0.0, (valid_dt - install_dt).total_seconds() / 3600.0)
    except Exception:
        dur_h = None
    return install_dt, valid_dt, dur_h

# Defaults
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_FILE_DEFAULT = os.path.join(SCRIPT_DIR, "radon-log.txt")
OUT_PNG = os.path.join(SCRIPT_DIR, "radon-chart.png")


CONFIG_PATHS = [
    "/etc/radonbox/radon-config.conf",
    os.path.expanduser("~/radon-config.conf"),
]

def load_thresholds(cli_on=None, cli_off=None):
    """
    Load ON/OFF thresholds in priority order:
      1. Explicit CLI args --on-threshold / --off-threshold
         This is the preferred DO/viewer path because each device has its
         own thresholds from the site-report/database row.
      2. Environment variables RADON_ON_THRESHOLD / RADON_OFF_THRESHOLD
      3. Local radon-config.conf files, useful on the Pi
      4. Safe legacy defaults
    """
    if cli_on is not None and cli_off is not None:
        return float(cli_on), float(cli_off)

    # Env overrides win (useful for testing and DO subprocess calls)
    env_on = os.getenv("RADON_ON_THRESHOLD")
    env_off = os.getenv("RADON_OFF_THRESHOLD")
    if env_on and env_off:
        return float(env_on), float(env_off)

    # Parse radon-config.conf key=value
    for path in CONFIG_PATHS:
        try:
            with open(path, "r", encoding="utf-8") as f:
                kv = {}
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, v = [x.strip() for x in line.split("=", 1)]
                    kv[k] = v
            # Use the same keys radon-automation uses (adjust if your names differ)
            on = float(kv.get("RADON_ON_THRESHOLD", kv.get("RADON_ON_PCI", "3.6")))
            off = float(kv.get("RADON_OFF_THRESHOLD", kv.get("RADON_OFF_PCI", "2.0")))
            return on, off
        except FileNotFoundError:
            continue
        except Exception:
            # If config is malformed, fall through to defaults
            break

    return 3.6, 2.0

RADON_ON_THRESHOLD, RADON_OFF_THRESHOLD = load_thresholds()


def load_it_window_days():
    env_days = os.getenv("IT_WINDOW_DAYS")
    if env_days:
        try:
            return max(1, int(env_days))
        except Exception:
            pass

    for path in CONFIG_PATHS:
        try:
            with open(path, "r", encoding="utf-8") as f:
                kv = {}
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, v = [x.strip() for x in line.split("=", 1)]
                    kv[k] = v
            return max(1, int(kv.get("IT_WINDOW_DAYS", "7")))
        except FileNotFoundError:
            continue
        except Exception:
            break

    return 7

IT_WINDOW_DAYS = load_it_window_days()



def _float_or_none(value):
    s = str(value).strip()
    return None if s == "" else float(s)


def _parse_structured_row(row):
    """
    Parse one structured radon-log CSV row.

    Returns (ts, st, it, lt, fan, install, fan_verified), or None when the row
    is not one of the supported structured formats.
    """
    if len(row) == 6:
        # Legacy format: timestamp, ST, LT, fan, install, reason
        ts_str, st_str, legacy_second_str, fan_str, install_str, _reason = row
        return (
            datetime.fromisoformat(ts_str),
            _float_or_none(st_str),
            _float_or_none(legacy_second_str),  # fallback for old logs
            None,
            int(fan_str),
            int(install_str),
            True,
        )

    if len(row) == 7:
        # Current format: timestamp, ST, IT_or_blank, LT, fan, install, reason
        ts_str, st_str, it_str, lt_str, fan_str, install_str, _reason = row
        return (
            datetime.fromisoformat(ts_str),
            _float_or_none(st_str),
            _float_or_none(it_str),
            _float_or_none(lt_str),
            int(fan_str),
            int(install_str),
            True,
        )

    if len(row) == 8:
        # Beta10 format: timestamp, ST, IT_or_blank, LT, fan, install, fan_verified, reason
        ts_str, st_str, it_str, lt_str, fan_str, install_str, fan_verified_str, _reason = row
        return (
            datetime.fromisoformat(ts_str),
            _float_or_none(st_str),
            _float_or_none(it_str),
            _float_or_none(lt_str),
            int(fan_str),
            int(install_str),
            str(fan_verified_str).strip().lower() in ("1", "true", "yes", "on", "verified"),
        )

    return None



def parse_log(path):
    """
    Supports:
      old: timestamp,ST,LT,fan,install,reason
      current: timestamp,ST,IT_or_blank,AirthingsLT,fan,install,reason
      beta10: timestamp,ST,IT_or_blank,AirthingsLT,fan,install,fan_verified,reason

    Notes:
      - ST is always displayed exactly as logged.
      - Viewer/Pi-side averages are computed only from validated ST daily-average values.
      - Airthings LT is parsed for backward compatibility but is not used or displayed.
      - fan_verified defaults to True for legacy/current rows.
    """
    times = []
    sts = []
    its = []
    lts = []
    fans = []
    install_flags = []
    fan_verified = []

    try:
        with open(path, "r", encoding="utf-8") as f:
            reader = csv.reader(f)
            for row in reader:
                try:
                    parsed = _parse_structured_row(row)
                except Exception:
                    parsed = None
                if parsed is None:
                    continue

                ts, st_val, it_val, lt_val, fan_val, install_val, fan_verified_val = parsed
                times.append(ts)
                sts.append(st_val)
                its.append(it_val)
                lts.append(lt_val)
                fans.append(fan_val)
                install_flags.append(install_val)
                fan_verified.append(fan_verified_val)

    except FileNotFoundError:
        print(f"Log file not found: {path}")
        return [], [], [], [], [], [], []

    return times, sts, its, lts, fans, install_flags, fan_verified

def trim_by_days(times, sts, its, lts, fans, install_flags, fan_verified, days_back):
    """
    Keep only points within the last `days_back` days from the most recent timestamp.
    If days_back is None or <= 0, return the data unchanged.
    """
    if not times or days_back is None or days_back <= 0:
        return times, sts, its, lts, fans, install_flags, fan_verified

    latest = max(times)
    cutoff = latest - timedelta(days=days_back)

    zipped = list(zip(times, sts, its, lts, fans, install_flags, fan_verified))
    trimmed = [
        (t, st, it, lt, f, inst, fv)
        for (t, st, it, lt, f, inst, fv) in zipped
        if t >= cutoff
    ]

    if not trimmed:
        # Nothing newer than cutoff; keep just the last point so chart isn't empty
        t_last = latest
        st_last = sts[-1]
        it_last = its[-1]
        lt_last = lts[-1]
        f_last = fans[-1]
        inst_last = install_flags[-1]
        fv_last = fan_verified[-1]
        return [t_last], [st_last], [it_last], [lt_last], [f_last], [inst_last], [fv_last]

    t2, st2, it2, lt2, f2, inst2, fv2 = zip(*trimmed)
    return list(t2), list(st2), list(it2), list(lt2), list(f2), list(inst2), list(fv2)




def _daily_st_points(times, sts):
    """
    Collapse logged ST readings to one validated daily-average value per calendar day.

    The Pi may report more than once per day. Since the ST value is itself the
    Airthings daily average, we keep the latest logged ST value for each date so
    a 4/day reporting schedule does not overweight that date in 7- or 30-day
    averages.
    """
    by_day = {}
    for t, st in sorted(zip(times, sts), key=lambda x: x[0]):
        if st is None:
            continue
        try:
            st_val = float(st)
        except Exception:
            continue
        by_day[t.date()] = (t, st_val)

    return [by_day[d] for d in sorted(by_day.keys())]


def _rolling_daily_avg_from_st(times, sts, window_days):
    """
    Return (timestamp, average) pairs for rolling averages computed only from
    validated daily ST values. A value is returned only after a full window is
    available.
    """
    pts = _daily_st_points(times, sts)
    if len(pts) < window_days:
        return []

    out = []
    vals = [v for _t, v in pts]
    for i in range(window_days - 1, len(pts)):
        window_vals = vals[i - window_days + 1:i + 1]
        avg = sum(window_vals) / window_days
        out.append((pts[i][0], avg))
    return out


def _latest_daily_avg_from_st(times, sts, window_days):
    """
    Return latest N-day average from validated daily ST values, or None when
    fewer than N distinct daily readings are available.
    """
    pts = _daily_st_points(times, sts)
    if len(pts) < window_days:
        return None
    vals = [v for _t, v in pts[-window_days:]]
    return sum(vals) / window_days


def _fmt_avg(val):
    return "N/A" if val is None else f"{val:.2f}"


def _latest_valid_value(vals):
    for v in reversed(vals):
        if v is None:
            continue
        try:
            return float(v)
        except Exception:
            continue
    return None


def _missing_airthings_marker_positions(times, sts):
    """
    Return (timestamp, y) positions for Airthings-unavailable markers.

    Consecutive/manual test failures can occur only minutes apart on a multi-day
    chart and otherwise draw directly on top of each other. Keep every event,
    but stack nearby markers slightly above the baseline so repeated failures
    remain visible without fabricating a radon measurement.
    """
    missing = [t for t, st in zip(times, sts) if st is None]
    if not missing:
        return [], []

    xs = []
    ys = []
    cluster_start = None
    cluster_index = 0
    # Treat failures within 90 minutes as visually overlapping on typical 14/30d charts.
    cluster_window = timedelta(minutes=90)

    for t in missing:
        if cluster_start is None or (t - cluster_start) > cluster_window:
            cluster_start = t
            cluster_index = 0
        else:
            cluster_index += 1

        xs.append(t)
        # Baseline grey X is not a measurement; small stacking just separates
        # repeated unavailable events.
        ys.append(0.0 + min(cluster_index, 4) * 0.08)

    return xs, ys



def make_chart(times, sts, its, lts, fans, install_flags, fan_verified, out_png):
    if not times:
        print("No structured data found in log; chart not generated.")
        return

    # Sort by time and keep LT aligned with the rest of the series.
    data = sorted(zip(times, sts, its, lts, fans, install_flags, fan_verified), key=lambda t: t[0])
    times, sts, its, lts, fans, install_flags, fan_verified = zip(*data)

    fig, ax1 = plt.subplots(figsize=(14, 5))

    # --- Radon lines (left Y axis) ---
    # ST=None means the run completed but Airthings did not produce a valid reading.
    # Do not fabricate a 0.0 pCi/L value. Matplotlib breaks the red line at None.
    latest_daily = _latest_valid_value(sts)
    ax1.plot(
        times,
        sts,
        "o-",
        linewidth=2,
        markersize=6,
        color="red",
        label=f"Daily: {_fmt_avg(latest_daily)}",
    )

    missing_airthings_times, missing_airthings_ys = _missing_airthings_marker_positions(times, sts)
    if missing_airthings_times:
        ax1.plot(
            missing_airthings_times,
            missing_airthings_ys,
            linestyle="None",
            marker="x",
            markersize=7,
            color="#777777",
            label="Airthings Unavailable",
            zorder=8,
        )

    # Plot 7-day average computed only from validated Airthings daily-average ST values.
    # Requires 7 distinct daily ST readings; otherwise it is shown as N/A in the legend.
    avg_7_latest = _latest_daily_avg_from_st(times, sts, 7)
    avg_30_latest = _latest_daily_avg_from_st(times, sts, 30)
    st_7_pairs = _rolling_daily_avg_from_st(times, sts, 7)

    if st_7_pairs:
        st_7_times = [t for t, _avg in st_7_pairs]
        st_7_vals = [_avg for _t, _avg in st_7_pairs]
        ax1.plot(
            st_7_times,
            st_7_vals,
            "s-",
            linewidth=2,
            markersize=6,
            color="orange",
            label=f"7-Day Avg: {_fmt_avg(avg_7_latest)}",
        )

    ax1.set_ylabel("Radon (pCi/L)", color="maroon")
    ax1.tick_params(axis="y", labelcolor="maroon")

    # Threshold lines
    ax1.axhline(
        RADON_ON_THRESHOLD,
        color="green",
        linestyle="--",
        linewidth=1,
        label=f"ON Threshold {RADON_ON_THRESHOLD}"
    )
    ax1.axhline(
        RADON_OFF_THRESHOLD,
        color="purple",
        linestyle="--",
        linewidth=1,
        label=f"OFF Threshold {RADON_OFF_THRESHOLD}"
    )

    # --- Fan state (right Y axis) ---
    ax2 = ax1.twinx()

    # Verified fan state is blue. Unverified fan state is dark grey.
    # This lets valid Airthings readings continue to appear on the chart even
    # when the Shelly/control path is unreachable.
    fan_verified = [bool(v) for v in fan_verified]
    has_unverified_fan = any(not v for v in fan_verified)

    ax2.step(
        times,
        fans,
        where="post",
        linewidth=2,
        color="blue",
        label="Fan State",
    )

    if has_unverified_fan:
        # Overlay the unverified intervals in dark grey.
        for i, verified in enumerate(fan_verified):
            if verified:
                continue

            t0 = times[i]
            t1 = times[i + 1] if i + 1 < len(times) else times[i]
            y = fans[i]

            # Horizontal interval; if this is the last/current point, show a marker.
            ax2.plot(
                [t0, t1],
                [y, y],
                linewidth=3,
                color="#444444",
                solid_capstyle="butt",
                label=("Fan State Unverified" if i == next((j for j, v in enumerate(fan_verified) if not v), i) else None),
            )
            ax2.plot([t0], [y], marker="o", color="#444444", markersize=5)

            # If the prior verified value differs, draw a grey vertical transition
            # at the unverified timestamp to make the state change visible.
            if i > 0 and fans[i - 1] != fans[i]:
                ax2.plot([t0, t0], [fans[i - 1], fans[i]], linewidth=3, color="#444444")

    ax2.set_ylim(-0.1, 1.1)
    ax2.set_ylabel("Fan State", color=("#444444" if has_unverified_fan and not fan_verified[-1] else "blue"))
    ax2.tick_params(axis="y", labelcolor=("#444444" if has_unverified_fan and not fan_verified[-1] else "blue"))
    ax2.set_yticks([])  # no numeric ticks; we use big ON/OFF labels instead

    # Big ON / OFF labels on the right edge (like chumbajr)
    edge_color = "#444444" if has_unverified_fan and not fan_verified[-1] else "blue"
    ax2.text(
        1.02,
        1.0,
        "ON",
        color=edge_color,
        transform=ax2.transAxes,
        va="center",
        ha="left",
    )
    ax2.text(
        1.02,
        0.0,
        "OFF",
        color=edge_color,
        transform=ax2.transAxes,
        va="center",
        ha="left",
    )

    # --- X-axis formatting (chumbajr-style auto scale) ---
    ax1.set_xlabel("Time")
    ax1.set_title("Radon Mitigation Automation")

    # Settling info label (only while still settling)
    try:
        install_dt, valid_dt, dur_h = _get_settling_info()
        if install_dt is not None and valid_dt is not None:
            latest_t = times[-1]
            if latest_t < valid_dt:
                msg = f"Settling: readings valid after {valid_dt.strftime('%Y-%m-%d %H:%M')}"
                if dur_h is not None:
                    msg += f" (~{dur_h:.0f}h after install)"
                # Draw on ax2 (twin axis) so it stays above the fan line
                ax2.text(
                    0.5,
                    0.92,
                    msg,
                    transform=ax2.transAxes,
                    ha='center',
                    va='center',
                    fontsize=10,
                    zorder=50,
                    bbox=dict(boxstyle='round', facecolor='white', edgecolor='black', alpha=1.0),
                )
    except Exception:
        pass

    locator = mdates.AutoDateLocator()
    formatter = mdates.ConciseDateFormatter(locator)
    ax1.xaxis.set_major_locator(locator)
    ax1.xaxis.set_major_formatter(formatter)
    fig.autofmt_xdate()

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()

    # Force legend order on all charts, including first/installation-day charts
    # where 7-Day Avg is not yet plotted:
    # Daily, 7-Day Avg, 30-Day Avg, ON Threshold, OFF Threshold, Fan State
    ordered_labels = []
    ordered_lines = []

    def _add(label_text, line_obj):
        ordered_labels.append(label_text)
        ordered_lines.append(line_obj)

    label_map = dict(zip(labels1, lines1))

    for lbl in labels1:
        if lbl.startswith("Daily:"):
            _add(lbl, label_map[lbl])
            break

    seven_found = False
    for lbl in labels1:
        if lbl.startswith("7-Day Avg:"):
            _add(lbl, label_map[lbl])
            seven_found = True
            break

    if not seven_found:
        _add("7-Day Avg: N/A", plt.Line2D([], [], linestyle=""))

    _add(f"30-Day Avg: {_fmt_avg(avg_30_latest)}", plt.Line2D([], [], linestyle=""))

    for lbl in labels1:
        if lbl.startswith("ON Threshold"):
            _add(lbl, label_map[lbl])
            break

    for lbl in labels1:
        if lbl.startswith("OFF Threshold"):
            _add(lbl, label_map[lbl])
            break

    for lbl, line in zip(labels2, lines2):
        if lbl == "Fan State":
            _add(lbl, line)
            break

    for lbl, line in zip(labels2, lines2):
        if lbl == "Fan State Unverified":
            _add(lbl, line)
            break

    ax1.legend(ordered_lines, ordered_labels, loc="upper left")

    # --- Installation-day callout ---
    try:
        install_banner_hours = float(os.getenv("INSTALL_BANNER_HOURS", "24"))
    except Exception:
        install_banner_hours = 24.0

    show_install_banner = False
    try:
        install_dt, _valid_dt, _dur_h = _get_settling_info()
    except Exception:
        install_dt = None

    if install_dt is not None:
        latest_t = times[-1]
        show_install_banner = latest_t < (install_dt + timedelta(hours=install_banner_hours))

    if show_install_banner:
        ax1.text(
            0.5,
            0.5,
            "INSTALLATION DAY\nFan forced ON",
            transform=ax1.transAxes,
            ha="center",
            va="center",
            fontsize=14,
            bbox=dict(
                boxstyle="round",
                facecolor="white",
                edgecolor="black",
                alpha=0.85,
            ),
        )
    fig.tight_layout()
    out_dir = os.path.dirname(os.path.abspath(out_png))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
    print(f"Chart written to {out_png}")



def main():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--log", default=LOG_FILE_DEFAULT, help="Path to radon log file")
    parser.add_argument("--output", default=OUT_PNG, help="Output chart PNG path")
    parser.add_argument("--days-back", type=int, default=None, help="Trim to the most recent N days before plotting")
    parser.add_argument("--on-threshold", type=float, default=None, help="Radon ON threshold to draw on chart; preferred for DO/viewer per-device charts")
    parser.add_argument("--off-threshold", type=float, default=None, help="Radon OFF threshold to draw on chart; preferred for DO/viewer per-device charts")
    args = parser.parse_args()

    global RADON_ON_THRESHOLD, RADON_OFF_THRESHOLD
    RADON_ON_THRESHOLD, RADON_OFF_THRESHOLD = load_thresholds(args.on_threshold, args.off_threshold)

    times, sts, its, lts, fans, install_flags, fan_verified = parse_log(args.log)
    times, sts, its, lts, fans, install_flags, fan_verified = trim_by_days(
        times, sts, its, lts, fans, install_flags, fan_verified, args.days_back
    )

    make_chart(times, sts, its, lts, fans, install_flags, fan_verified, args.output)


if __name__ == "__main__":
    main()
